/* SPDX-License-Identifier: GPL-3.0-only */
/* Fast LSDj swap (0.9.98-dev.6): the web page rewrites the LSDj slot's flash sectors, only the ones that
   differ, over the link (firmware/lsdj_link.h ops 0x08..0x0B), instead of installing the whole firmware.

   The slot is whole 4 KiB flash sectors after all the code (tools/build.py, app.ld .lsdj_slot), so no sector
   written here holds code. The app area is stored encrypted with the chip key (the SFC cipher, as the update
   loader writes it: vendor/felucca/firmware/loader/ldr_core.c ldr_sfc, counted from flash 0x4000); the page
   sends plain bytes and this encrypts them.

   Power cuts: the boot code does not check the app area (the SLOT TEST), and at power on the firmware checks
   the slot (src/lsdj_slot.h: header CRC, data CRC) and shows the add-your-LSDj screen for one that does not
   check out. So:
     1. Before anything is erased, BEGIN proves the key: the slot's first sector, encrypted here from its plain
        (XIP) view, must equal its raw flash bytes. Else status 4, nothing changed.
     2. The header sector (slot sector 0) is erased before any other sector changes: from then on, a cut
        boots to the add-your-LSDj screen.
     3. The header sector is written last (END), its first 256 bytes (the header) last of all.
   So the FM-1 always starts: with the new LSDj, or with no LSDj (the page then swaps again, or installs).

   Ops (data as decoded bytes; lsdj_link.h packs and unpacks the pairs). Once BEGIN has changed a sector, the
   FM-1 restarts at the end (END, or LSDJ_SWAP_TIMEOUT_MS without a request): LSDj ran from the old slot.
     INFO  u8 first          -> u32 capacity, u8 sectors, u8 first, then the CRC32 of each plain sector from
                                first (at most LSDJ_SWAP_SUMS)
     BEGIN u32 crc32, u8 count   crc32: the whole new slot's (capacity bytes); count: the sectors the page will
                                send (1..sectors, for the progress bar); stores the songs, pauses LSDj, checks the key
     WRITE u8 sector, u8 part, 128 bytes   parts 0..31 in order (the last one again is fine); the 32nd writes
                                the sector (status 4: flash error, the page sends the sector again).
                                Sector 0 (the header) is kept until END and must come last.
     END                     writes sector 0 (status 4: flash error, the page sends END again), checks the
                                whole slot against BEGIN's CRC (status 3 if not), then restarts. Nothing
                                sent: LSDj just carries on.
   Status: 0 ok, 1 bad request, 2 wrong state, 3 crc mismatch, 4 flash error (lsdj_link.h).
   Pure logic, the hardware through lsdj_swap_io_t: tests/lsdj_swap.c. */
#pragma once
#include <stdint.h>

#define LSDJ_SWAP_SECTOR     4096u
#define LSDJ_SWAP_PART       128u
#define LSDJ_SWAP_PARTS      (LSDJ_SWAP_SECTOR / LSDJ_SWAP_PART)
#define LSDJ_SWAP_SUMS       30u        /* CRCs an INFO reply carries (6 + 120 bytes: under the link's 128) */
#define LSDJ_SWAP_TIMEOUT_MS 30000u   /* (a browser tab in the background runs its timers late) */
#define LSDJ_SWAP_RESTART_MS 300u       /* END's reply leaves first */
#define LSDJ_SWAP_APP_LO     0x4000u    /* the cipher counts from here (flash = XIP 0x02000000) */
#define LSDJ_SWAP_APP_HI     0x93000u   /* the encrypted app area ends here */

enum { LSDJ_SWAP_INFO = 0, LSDJ_SWAP_BEGIN, LSDJ_SWAP_WRITE, LSDJ_SWAP_END };
enum { LSDJ_SWAP_OK = 0, LSDJ_SWAP_BAD = 1, LSDJ_SWAP_STATE = 2, LSDJ_SWAP_CRC = 3, LSDJ_SWAP_FLASH = 4 };

typedef struct {
    int (*key)(uint32_t *key);                                 /* the chip key, 0 = ok */
    int (*read)(uint32_t off, uint8_t *p, uint32_t n);         /* raw flash, 0 = ok */
    int (*erase)(uint32_t off);                                /* one 4 KiB sector of the slot, 0 = ok */
    int (*prog)(uint32_t off, const uint8_t *p, uint32_t n);   /* within one 256-byte page of the slot, 0 = ok */
    int (*begin)(void);                                        /* store the songs, pause LSDj: 0 = ok */
    void (*resume)(void);                                      /* nothing changed: LSDj carries on */
    void (*restart)(void);                                     /* start the FM-1 again (never returns) */
    void (*progress)(uint32_t done, uint32_t total);           /* sectors written of those sent; may be NULL */
} lsdj_swap_io_t;

typedef struct {
    const volatile uint8_t *plain;   /* the slot as the CPU reads it (XIP, decrypted) */
    uint32_t flash;                  /* its flash offset (a sector boundary) */
    uint32_t sectors;                /* its size in sectors */
    uint8_t *buf;                    /* LSDJ_SWAP_SECTOR bytes of RAM */
    uint32_t key, crc, last_ms, restart_at, written, count;
    uint8_t on, changed, hdr_gone, hdr_ready, restart, sec, part;
} lsdj_swap_t;

/* 1 if the slot is one this can rewrite: whole sectors, inside the encrypted app area. */
static int lsdj_swap_init(lsdj_swap_t *s, const volatile uint8_t *plain, uint32_t flash, uint32_t capacity, uint8_t *buf) {
    s->plain = plain; s->flash = flash; s->buf = buf; s->on = 0; s->restart = 0;
    s->sectors = capacity / LSDJ_SWAP_SECTOR;
    if (!buf || flash % LSDJ_SWAP_SECTOR || capacity % LSDJ_SWAP_SECTOR || !s->sectors || s->sectors > 255u ||
        flash < LSDJ_SWAP_APP_LO || flash > LSDJ_SWAP_APP_HI || capacity > LSDJ_SWAP_APP_HI - flash) { s->sectors = 0; return 0; }
    return 1;
}

/* The SFC cipher (ldr_core.c ldr_sfc): per 32-byte block, key ^ (offset from the app area >> 2), a CRC16 LFSR. */
static void lsdj_swap_sfc(uint8_t *p, uint32_t n, uint32_t base_off, uint32_t key) {
    for (uint32_t i = 0; i < n; i += 32u) {
        uint32_t k = key ^ ((base_off + i) >> 2);
        for (uint32_t j = 0; j < 32u && i + j < n; j++) {
            p[i + j] ^= (uint8_t)k;
            k = ((k << 1) ^ (k & 0x8000u ? 0x1021u : 0u)) & 0xFFFFu;
        }
    }
}

static uint32_t lsdj_swap_crc32(uint32_t crc, const volatile uint8_t *p, uint32_t n) {   /* IEEE, as lsdj_slot_crc32 */
    crc = ~crc;
    while (n--) {
        crc ^= *p++;
        for (unsigned k = 0; k < 8; k++) crc = (crc >> 1) ^ (0xEDB88320u & (0u - (crc & 1u)));
    }
    return ~crc;
}
static uint32_t lsdj_swap_rd32(const uint8_t *p) { return p[0] | (uint32_t)p[1] << 8 | (uint32_t)p[2] << 16 | (uint32_t)p[3] << 24; }
static uint32_t lsdj_swap_wr32(uint8_t *o, uint32_t n, uint32_t v) {
    o[n] = (uint8_t)v; o[n + 1] = (uint8_t)(v >> 8); o[n + 2] = (uint8_t)(v >> 16); o[n + 3] = (uint8_t)(v >> 24);
    return n + 4;
}

/* raw flash at off == p (n a multiple of 64) */
static int lsdj_swap_same(const lsdj_swap_io_t *io, uint32_t off, const uint8_t *p, uint32_t n) {
    uint8_t b[64];
    for (uint32_t i = 0; i < n; i += 64u) {
        if (io->read(off + i, b, 64u)) return 0;
        for (unsigned j = 0; j < 64u; j++) if (b[j] != p[i + j]) return 0;
    }
    return 1;
}
static int lsdj_swap_blank(const lsdj_swap_io_t *io, uint32_t off) {
    uint8_t b[64];
    for (uint32_t i = 0; i < LSDJ_SWAP_SECTOR; i += 64u) {
        if (io->read(off + i, b, 64u)) return 0;
        for (unsigned j = 0; j < 64u; j++) if (b[j] != 0xFFu) return 0;
    }
    return 1;
}

/* Sector k (s->buf, plain) encrypted and written, read back; the header's page (k 0, page 0) last. 0 = ok. */
static int lsdj_swap_put(lsdj_swap_t *s, const lsdj_swap_io_t *io, uint32_t k) {
    uint32_t off = s->flash + k * LSDJ_SWAP_SECTOR;
    lsdj_swap_sfc(s->buf, LSDJ_SWAP_SECTOR, off - LSDJ_SWAP_APP_LO, s->key);
    for (unsigned tries = 0; tries < 2u; tries++) {
        int bad = io->erase(off) || !lsdj_swap_blank(io, off);
        for (uint32_t pg = 1; !bad && pg <= LSDJ_SWAP_SECTOR / 256u; pg++) {
            uint32_t at = (pg % (LSDJ_SWAP_SECTOR / 256u)) * 256u;   /* pages 1..15, then 0 */
            bad = io->prog(off + at, s->buf + at, 256u) != 0;
        }
        if (!bad && lsdj_swap_same(io, off, s->buf, LSDJ_SWAP_SECTOR)) {
            lsdj_swap_sfc(s->buf, LSDJ_SWAP_SECTOR, off - LSDJ_SWAP_APP_LO, s->key);   /* plain again */
            return 0;
        }
    }
    lsdj_swap_sfc(s->buf, LSDJ_SWAP_SECTOR, off - LSDJ_SWAP_APP_LO, s->key);
    return -1;
}

static void lsdj_swap_finish(lsdj_swap_t *s, const lsdj_swap_io_t *io, uint32_t now_ms) {
    s->on = 0;
    if (s->changed) { s->restart = 1; s->restart_at = now_ms + LSDJ_SWAP_RESTART_MS; }
    else io->resume();
}

/* One request: op LSDJ_SWAP_*, d / dn its bytes; reply bytes to out (at most 128), their count to *on. */
static int lsdj_swap_op(lsdj_swap_t *s, const lsdj_swap_io_t *io, unsigned op, const uint8_t *d, uint32_t dn,
                        uint32_t now_ms, uint8_t *out, uint32_t *on) {
    *on = 0;
    if (!s->sectors) return LSDJ_SWAP_BAD;
    if (s->restart) return LSDJ_SWAP_STATE;
    switch (op) {
    case LSDJ_SWAP_INFO: {
        if (dn != 1u) return LSDJ_SWAP_BAD;
        uint32_t first = d[0], n = 0;
        if (first > s->sectors) return LSDJ_SWAP_BAD;
        if (s->on) return LSDJ_SWAP_STATE;   /* (sums of a slot half written mean nothing) */
        n = lsdj_swap_wr32(out, n, s->sectors * LSDJ_SWAP_SECTOR);
        out[n++] = (uint8_t)s->sectors; out[n++] = (uint8_t)first;
        for (uint32_t k = first; k < s->sectors && k < first + LSDJ_SWAP_SUMS; k++)
            n = lsdj_swap_wr32(out, n, lsdj_swap_crc32(0, s->plain + k * LSDJ_SWAP_SECTOR, LSDJ_SWAP_SECTOR));
        *on = n;
        return LSDJ_SWAP_OK;
    }
    case LSDJ_SWAP_BEGIN: {
        if (dn != 5u || !d[4] || d[4] > s->sectors) return LSDJ_SWAP_BAD;
        if (s->on) return LSDJ_SWAP_STATE;
        uint32_t key;
        if (io->begin()) return LSDJ_SWAP_FLASH;   /* LSDj paused first: buf may be memory it draws in */
        int ok = !io->key(&key);
        if (ok) {                                                                 /* 1. prove the key */
            for (uint32_t i = 0; i < LSDJ_SWAP_SECTOR; i++) s->buf[i] = s->plain[i];
            lsdj_swap_sfc(s->buf, LSDJ_SWAP_SECTOR, s->flash - LSDJ_SWAP_APP_LO, key);
            ok = lsdj_swap_same(io, s->flash, s->buf, LSDJ_SWAP_SECTOR);
        }
        if (!ok) { io->resume(); return LSDJ_SWAP_FLASH; }                        /* nothing changed */
        s->key = key; s->crc = lsdj_swap_rd32(d); s->last_ms = now_ms;
        s->on = 1; s->changed = 0; s->hdr_gone = 0; s->hdr_ready = 0; s->sec = 0xFFu; s->part = 0; s->written = 0;
        s->count = d[4];
        return LSDJ_SWAP_OK;
    }
    case LSDJ_SWAP_WRITE: {
        if (dn != 2u + LSDJ_SWAP_PART) return LSDJ_SWAP_BAD;
        if (!s->on) return LSDJ_SWAP_STATE;
        uint32_t k = d[0], p = d[1];
        if (k >= s->sectors || p >= LSDJ_SWAP_PARTS) return LSDJ_SWAP_BAD;
        s->last_ms = now_ms;
        if (k == s->sec && p + 1u == s->part) return LSDJ_SWAP_OK;               /* the last part again */
        if (k == s->sec && p == LSDJ_SWAP_PARTS - 1u && s->part == 0) return LSDJ_SWAP_OK;   /* (its sector done) */
        if (s->hdr_ready) return LSDJ_SWAP_STATE;                                 /* sector 0 comes last */
        if (p == 0) { s->sec = (uint8_t)k; s->part = 0; }
        else if (k != s->sec || p != s->part) return LSDJ_SWAP_BAD;
        for (uint32_t i = 0; i < LSDJ_SWAP_PART; i++) s->buf[p * LSDJ_SWAP_PART + i] = d[2 + i];
        s->part = (uint8_t)(p + 1u);
        if (s->part < LSDJ_SWAP_PARTS) return LSDJ_SWAP_OK;
        s->part = 0;
        if (k == 0) { s->hdr_ready = 1; return LSDJ_SWAP_OK; }                  /* kept for END */
        s->changed = 1;   /* (from the first erase on, whatever happens: a restart, to the add-your-LSDj screen) */
        if (!s->hdr_gone) {                                                       /* 2. the header goes first */
            if (io->erase(s->flash) || !lsdj_swap_blank(io, s->flash)) { s->sec = 0xFFu; return LSDJ_SWAP_FLASH; }
            s->hdr_gone = 1;
        }
        if (lsdj_swap_put(s, io, k)) { s->sec = 0xFFu; return LSDJ_SWAP_FLASH; }   /* the page sends it again */
        s->written++;
        if (io->progress) io->progress(s->written, s->count);
        return LSDJ_SWAP_OK;
    }
    case LSDJ_SWAP_END: {
        if (dn) return LSDJ_SWAP_BAD;
        if (!s->on) return LSDJ_SWAP_STATE;
        if (!s->changed && !s->hdr_ready) { lsdj_swap_finish(s, io, now_ms); return LSDJ_SWAP_OK; }   /* nothing sent */
        if (!s->hdr_ready) return LSDJ_SWAP_STATE;
        s->changed = 1; s->last_ms = now_ms;
        if (lsdj_swap_put(s, io, 0)) return LSDJ_SWAP_FLASH;                      /* 3. the header last (END again) */
        int st = lsdj_swap_crc32(0, s->plain, s->sectors * LSDJ_SWAP_SECTOR) == s->crc ? LSDJ_SWAP_OK : LSDJ_SWAP_CRC;
        if (io->progress) io->progress(s->count, s->count);
        lsdj_swap_finish(s, io, now_ms);
        return st;
    }
    }
    return LSDJ_SWAP_BAD;
}

/* Every main loop: a swap the page left ends (a restart once anything changed); END's restart. */
static void lsdj_swap_poll(lsdj_swap_t *s, const lsdj_swap_io_t *io, uint32_t now_ms) {
    if (s->on && now_ms - s->last_ms > LSDJ_SWAP_TIMEOUT_MS) lsdj_swap_finish(s, io, now_ms);
    if (s->restart && (int32_t)(now_ms - s->restart_at) >= 0) io->restart();
}
