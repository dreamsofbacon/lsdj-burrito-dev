/* SPDX-License-Identifier: GPL-3.0-only */
/* Song row cue (ARP): hold ARP, K1 picks a song row (K2 by 16), let go: every
   playing channel goes to that row when its current phrase ends (the next bar),
   from the chain's first phrase, and the song carries on from there.
   How: LSDj moves to the next song row when a phrase ends at the end of its
   chain. Setting a channel's song row to N-1 and its place in the chain to the
   last (15) makes the current phrase end its chain, so LSDj goes to row N,
   phrase 1, by itself. Written at any point of the phrase, it lands on the
   phrase end (emulator: harness/cue_check3.sh). LSDj 9.3.9 addresses: song rows
   C200-C203, chain places C17C-C17F, the song table (256 rows x 4 chains, FF =
   none) at cartridge RAM 0x1290 - passed in by board.c.
   0.9.98-dev.16, a cue while stopped is where play starts (the DJ page's row map,
   Colin): it waits as the start row (ARP lit). The START that starts LSDj (a MIDI
   Start, or START by hand) waits until LSDj's song cursor row (C41E) holds the
   row - START plays from the cursor - and once LSDj plays the cursor goes back
   where it was (LSDj does not redraw it, so the screen never shows the move).
   Stop clears any cue: a MIDI Stop, LSDj stopping, the DJ layout's Stop key, or
   the same row cued again while stopped. Started some other way (no cursor
   address, or it was never moved): the old cue, the row at the next bar.
   Pure logic: tests/lsdj_cue.c. */
#pragma once
#include <stdint.h>

typedef struct {
    uint8_t held;      /* ARP down: choosing */
    uint8_t turned;    /* a knob moved since ARP went down */
    uint8_t row;       /* the row being chosen / cued */
    uint8_t pending;   /* let go after choosing: write it as soon as something plays */
    uint8_t waiting;   /* written: until a channel is on the row (ARP lit) */
    uint32_t waited;   /* frames since written */
    uint8_t start_set; /* stopped: a row cued, play starts on it */
    uint8_t start;     /* that row */
    uint8_t moved;     /* the song cursor set to it for START (cursor_was: where it was) */
    uint8_t cursor_was;
    uint8_t gate_wait; /* frames START has waited for the cursor */
    uint8_t was_playing;
} lsdj_cue_t;

static int lsdj_cue_first(const uint8_t playing[4]) { for (int c = 0; c < 4; c++) if (playing[c]) return c; return -1; }

/* ARP down: start from the row after the one playing (stopped: the start row cued, else 00). */
static void lsdj_cue_open(lsdj_cue_t *q, const uint8_t playing[4], const uint8_t song_rows[4]) {
    int c = lsdj_cue_first(playing);
    q->held = 1; q->turned = 0;
    q->row = c >= 0 ? (uint8_t)(song_rows[c] + 1u) : q->start_set ? q->start : 0u;
}
/* Stop: every cue cleared. Returns bit 0 if one was cleared, bit 1 if the song cursor goes back to *put
   (moved for a START that has not started LSDj, still where it was put). */
static int lsdj_cue_stop(lsdj_cue_t *q, uint8_t cursor_now, uint8_t *put) {
    int r = q->start_set || q->pending || q->waiting;
    if (q->start_set && q->moved && cursor_now == q->start && q->cursor_was != q->start) { *put = q->cursor_was; r |= 2; }
    q->start_set = q->moved = q->pending = q->waiting = 0;
    return r;
}
/* A cue from MIDI (program change n). Stopped with row n already the start row: cancelled (returns 1, and
   lsdj_cue_stop's bit 1 / *put); else cued (returns 0). */
static int lsdj_cue_pc(lsdj_cue_t *q, uint8_t row, int stopped, uint8_t cursor_now, uint8_t *put) {
    if (stopped && q->start_set && q->start == row) return lsdj_cue_stop(q, cursor_now, put) | 1;
    q->row = row; q->pending = 1; q->waiting = 0;
    return 0;
}
/* Once per frame, before lsdj_cue_frame: LSDj stopping clears the cues; a cue while stopped becomes the start
   row; once LSDj plays, the start row is done (the cursor back: returns 1 with *put) or, START not having moved
   the cursor, cued for the next bar. */
static int lsdj_cue_play(lsdj_cue_t *q, const uint8_t playing[4], uint8_t cursor_now, uint8_t *put) {
    int c0 = lsdj_cue_first(playing), r = 0;
    if (c0 < 0) {
        if (q->was_playing) { uint8_t p; (void)lsdj_cue_stop(q, cursor_now, &p); }
        if (q->pending) { q->pending = 0; q->start_set = 1; q->start = q->row; q->moved = 0; }
    } else if (q->start_set) {
        if (!q->moved) { q->row = q->start; q->pending = 1; q->waiting = 0; }
        else if (cursor_now == q->start && q->cursor_was != q->start) { *put = q->cursor_was; r = 1; }
        q->start_set = q->moved = 0;
    }
    q->was_playing = c0 >= 0;
    return r;
}
/* START is about to start LSDj (stopped). Returns bit 0 if START may go now, bit 1 to write *put into the song
   cursor row first (START then waits until the cursor reads it, up to 8 frames). No start row: at once. */
static int lsdj_cue_gate(lsdj_cue_t *q, uint8_t cursor_now, uint8_t *put) {
    if (!q->start_set) return 1;
    if (!q->moved) {
        q->moved = 1; q->cursor_was = cursor_now; q->gate_wait = 0;
        if (cursor_now == q->start) return 1;
        *put = q->start; return 2;
    }
    if (cursor_now == q->start || ++q->gate_wait > 8u) return 1;
    *put = q->start; return 2;   /* (again: a write dropped by a full queue) */
}
/* While held: K1 clicks move the row by 1, K2 clicks by 16 (wrapping 00..FF). */
static void lsdj_cue_turn(lsdj_cue_t *q, int fine, int coarse) {
    if (!q->held || (!fine && !coarse)) return;
    q->row = (uint8_t)(q->row + fine + 16 * coarse);
    q->turned = 1;
}
/* ARP up: cue the row if a knob was turned (a press alone only shows the row). */
static int lsdj_cue_release(lsdj_cue_t *q) {
    int cue = q->held && q->turned;
    q->held = 0;
    if (cue) { q->pending = 1; q->waiting = 0; }
    return cue;
}
/* Once per frame. When pending and something plays: the writes (addresses and
   values, up to 8) that cue it; returns how many (0: nothing to write now).
   Also ends `waiting` once a playing channel is on the row (or after ~4 s). */
static unsigned lsdj_cue_frame(lsdj_cue_t *q, const uint8_t playing[4], const uint8_t song_rows[4],
                               uint16_t song_row_addr, uint16_t chain_pos_addr, uint16_t addr[8], uint8_t val[8]) {
    int c0 = lsdj_cue_first(playing);
    if (q->waiting) {
        if ((c0 >= 0 && song_rows[c0] == q->row) || ++q->waited > 240u) q->waiting = 0;
    }
    if (!q->pending || c0 < 0) return 0;
    unsigned n = 0;
    for (unsigned c = 0; c < 4; c++) {
        if (!playing[c]) continue;
        addr[n] = (uint16_t)(song_row_addr + c); val[n++] = (uint8_t)(q->row - 1u);
        addr[n] = (uint16_t)(chain_pos_addr + c); val[n++] = 15u;
    }
    q->pending = 0; q->waiting = 1; q->waited = 0;
    return n;
}
static int lsdj_cue_lit(const lsdj_cue_t *q) { return q->held || q->pending || q->waiting || q->start_set; }

/* The pop-up while choosing (fields as lsdj_ov_bars_t): title "CUE ROW 08",
   per channel its chain on that row ("06", "--" for none) and a full bar if it
   has one; the bottom line what to do. song: the song table (row * 4 + channel). */
static void lsdj_cue_bars(const lsdj_cue_t *q, const uint8_t *song, char title[20], char big[20],
                          char label[4][7], char value[4][6], char caption[4][4], uint8_t level[4]) {
    static const char hex[] = "0123456789ABCDEF";
    static const char *const ch[4] = {"P1", "P2", "WV", "NS"};   /* 2 wide, as LSDj's columns */
    static const char t[] = "CUE ROW ";
    unsigned n = 0;
    for (const char *s = t; *s; s++) title[n++] = *s;
    title[n++] = hex[q->row >> 4]; title[n++] = hex[q->row & 15u]; title[n] = 0;
    for (unsigned c = 0; c < 4; c++) {
        uint8_t chain = song ? song[q->row * 4u + c] : 0xFFu;
        unsigned k = 0; for (const char *s = ch[c]; *s; s++) label[c][k++] = *s; label[c][k] = 0;
        if (chain == 0xFFu) { value[c][0] = '-'; value[c][1] = '-'; }
        else { value[c][0] = hex[chain >> 4]; value[c][1] = hex[chain & 15u]; }
        value[c][2] = 0; caption[c][0] = 0;
        level[c] = chain == 0xFFu ? 0u : 127u;
    }
    const char *b = q->turned ? "LET GO: CUE" : "K1 ROW K2 BY 16";
    n = 0; for (const char *s = b; *s; s++) big[n++] = *s; big[n] = 0;
}
