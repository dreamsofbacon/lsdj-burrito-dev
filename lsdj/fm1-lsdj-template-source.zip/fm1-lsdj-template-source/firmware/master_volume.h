/* SPDX-License-Identifier: GPL-3.0-only */
#pragma once
#include <stdint.h>
/* Felucca's quadratic 10-bit MASTER curve, with a bottom deadband. */
static inline uint32_t gb_master_gain(uint32_t raw){
    if(raw<=8)return 0;
    if(raw>1023)raw=1023;
    return (raw*raw)>>8;
}
/* S16 -> signed 24-bit DMA, with 6 dB of headroom at full MASTER. */
static inline int32_t gb_master_sample(int16_t sample,uint32_t gain){
    if(gain>4096)gain=4096;
    return (int32_t)sample*(int32_t)gain/32;
}
/* The web page's volume (VOLUME_SET 0..127: the DJ crossfader) as a gb_master_s16 gain: 127 = 4096, unchanged.
   USB AUDIO: FULL still follows it (never the MASTER knob), so the crossfader mixes the USB sound too. */
static inline uint32_t gb_page_gain(uint32_t level){
    if(level>127)level=127;
    return level*4096u/127u;
}
/* S16 at the same gain, as S16 (USB AUDIO: VOLUME); 4096 = unchanged. */
static inline int16_t gb_master_s16(int16_t sample,uint32_t gain){
    if(gain>4096)gain=4096;
    return (int16_t)((int32_t)sample*(int32_t)gain/4096);
}
