/* SPDX-License-Identifier: GPL-3.0-only */
/* The audio clock, measured (0.9.98): how many sound frames the DAC (I2S) takes a second, against the FM-1's own
   24 MHz timer and against the computer's USB frames (1 ms each, the host's clock). The emulator runs as fast as the
   DAC takes its sound, so this rate is what LSDj's tempo and pitch follow (nominal 44,100; Felucca measured about
   44,117.6). Shown on the CPU meter (GLO, every 4th second); the USB audio's converter and the emulator's rate are
   set from it.
     lsdj_clk_dac(c, now, frames)   audio interrupt: the 24 MHz time and the frames taken since boot
     lsdj_clk_usb(c, now, frame)    after usb_poll: the time and the USB frame number (11 bits); every call, it
                                    counts only changes; lsdj_clk_usb_lost(c) when the host is gone
     lsdj_clk_dac_mhz / lsdj_clk_host_mhz   the rate in mHz (0: not yet 10 s of data)
   Each source keeps its own 64-bit time (it calls often enough: the 32-bit timer wraps after 179 s), and its first
   and last point: the longer it runs, the finer the rate (the USB frame number is read to 1 ms: 1 ms over the run).
   Pure logic: tests/lsdj_clock.c. */
#pragma once
#include <stdint.h>

#define LSDJ_CLK_HZ 24000000u
#define LSDJ_CLK_MIN (10ull * LSDJ_CLK_HZ)      /* 10 s before a rate is given */

typedef struct {
    uint32_t last;                              /* the 32-bit time last seen */
    uint64_t t0, t1, n0, n1;                    /* 64-bit time and count: first point, last point */
    uint64_t t, n;                              /* now (unwrapped) */
    uint8_t started;
} lsdj_clk_src_t;
typedef struct { lsdj_clk_src_t dac, usb; uint16_t frame; uint8_t odd; } lsdj_clk_t;   /* odd: frame numbers in a row
                                                                                        that didn't fit the time */

/* n / d in 64 bits by shift and subtract: the firmware has no 64-bit division (no __udivdi3); a few
   times a second, from the main loop */
static uint64_t lsdj_clk_div(uint64_t n, uint64_t d) {
    uint64_t q = 0, r = 0;
    if (!d) return 0;
    for (int i = 63; i >= 0; i--) {
        r = r << 1 | ((n >> i) & 1u);
        if (r >= d) { r -= d; q |= 1ull << i; }
    }
    return q;
}
static void lsdj_clk_point(lsdj_clk_src_t *s, uint32_t now, uint64_t count) {
    if (!s->started) { s->started = 1; s->last = now; s->t = 0; s->t0 = s->t1 = 0; s->n0 = s->n1 = s->n = count; return; }
    s->t += (uint32_t)(now - s->last); s->last = now; s->n = count;
    s->t1 = s->t; s->n1 = count;
}
static void lsdj_clk_dac(lsdj_clk_t *c, uint32_t now, uint64_t frames) { lsdj_clk_point(&c->dac, now, frames); }
static void lsdj_clk_usb(lsdj_clk_t *c, uint32_t now, uint16_t frame) {
    frame &= 0x7FFu;
    if (!c->usb.started) { c->frame = frame; lsdj_clk_point(&c->usb, now, 0); return; }
    if (frame == c->frame) { c->usb.t += (uint32_t)(now - c->usb.last); c->usb.last = now; return; }   /* (keeps the time unwrapped) */
    /* a read that doesn't fit the time since the last (1 a ms, +-3) is a bad read of the frame number (the SIE
       answered 0 or late): left out. dev.12 counted them, and one such read in a few minutes put USB 0.75 % off
       (Colin's FM-1: 43790 for 44117). Three in a row: the host's numbering really moved (a reset): start again. */
    uint32_t got = (frame - c->frame) & 0x7FFu, ms = (uint32_t)(c->usb.t + (uint32_t)(now - c->usb.last) - c->usb.t1) / (LSDJ_CLK_HZ / 1000u);
    if (got + 3u < ms || got > ms + 3u) {
        c->usb.t += (uint32_t)(now - c->usb.last); c->usb.last = now;
        if (++c->odd >= 3u) { c->odd = 0; c->usb.started = 0; }
        return;
    }
    c->odd = 0;
    uint64_t n = c->usb.n + got;
    c->frame = frame;
    lsdj_clk_point(&c->usb, now, n);
}
static void lsdj_clk_usb_lost(lsdj_clk_t *c) { c->usb.started = 0; }
static uint64_t lsdj_clk_rate_mhz(const lsdj_clk_src_t *s) {   /* counts a second, in thousandths */
    uint64_t dt = s->t1 - s->t0;
    if (!s->started || dt < LSDJ_CLK_MIN) return 0;
    return lsdj_clk_div((s->n1 - s->n0) * 1000ull * LSDJ_CLK_HZ + dt / 2u, dt);
}
static uint64_t lsdj_clk_dac_mhz(const lsdj_clk_t *c) { return lsdj_clk_rate_mhz(&c->dac); }
/* the DAC's rate in the host's seconds: its rate over the USB frames' (1000 a host second) */
static uint64_t lsdj_clk_host_mhz(const lsdj_clk_t *c) {
    uint64_t d = lsdj_clk_rate_mhz(&c->dac), u = lsdj_clk_rate_mhz(&c->usb);
    return d && u ? lsdj_clk_div(d * 1000000ull + u / 2u, u) : 0;
}
/* "44117.65" from mHz (two decimals), into p; returns its end */
static char *lsdj_clk_put(char *p, uint64_t mhz) {
    uint32_t c = (uint32_t)lsdj_clk_div(mhz + 5u, 10u);   /* hundredths (32 bits: rates up to 42 MHz) */
    char t[24]; int n = 0; uint32_t w = c / 100u;
    do { t[n++] = (char)('0' + w % 10u); w /= 10u; } while (w);
    while (n) *p++ = t[--n];
    *p++ = '.'; *p++ = (char)('0' + (c / 10u) % 10u); *p++ = (char)('0' + c % 10u);
    return p;
}
/* the meter's two lines: "AUDIO 44117.65 HZ" / "USB   44117.60 HZ" (or "USB   -- (NO HOST)"), 19 characters at most */
static void lsdj_clk_lines(const lsdj_clk_t *c, char l1[20], char l2[20]) {
    uint64_t d = lsdj_clk_dac_mhz(c), h = lsdj_clk_host_mhz(c);
    char *p = l1; const char *s = "AUDIO ";
    while (*s) *p++ = *s++;
    if (d) { p = lsdj_clk_put(p, d); s = " HZ"; } else s = "--";
    while (*s) *p++ = *s++;
    *p = 0;
    p = l2; s = "USB   ";
    while (*s) *p++ = *s++;
    if (h) { p = lsdj_clk_put(p, h); s = " HZ"; } else s = c->usb.started ? "--" : "-- (NO HOST)";
    while (*s) *p++ = *s++;
    *p = 0;
}
