/* SPDX-License-Identifier: GPL-3.0-only */
/* A read stream for the web page (0.9.98-dev.14): the songs or the LSDj slot sent by themselves, straight from the
   USB interrupt, while nothing else waits to go out. A grab (the DJ crate: the songs, then the LSDj) read 128 or
   120 bytes a request, each sent as two bytes a byte, one request a main-loop pass: ~1m45s on Colin's FM-1. Here the
   bytes go 8 for 7 and no request waits for the main loop: as fast as USB takes them.

   lsdj_link.h READ_STREAM (op 0x3A) starts one; each frame is a STREAM_DATA message (op 0x3B, never asked):
     F0 7D 'G' 'S' 3B 00 what  off (u32 as pairs)  data  F7
   data: groups of 7 bytes, each as one byte of their high bits (bit k: byte k's) then the 7 low 7-bit parts;
   the last group may be shorter (its high byte, then its bytes). LSDJ_STREAM_BYTES bytes a frame (the last shorter).

   The USB interrupt (vendor/felucca/firmware/src/usb.c, FELUCCA_SX_STREAM) takes one packet at a time with
   lsdj_stream_next: a frame once begun goes out whole before any other SysEx or MIDI (a SysEx frame must not be
   split; a frame is ~2 ms of USB); between frames the others go first (yield: MIDI waiting; and the ring's replies
   whenever they wait, as the interrupt checks the ring first). It reads the songs (RAM) and the slot (flash, mapped:
   written only with interrupts off) as they are: the page checks them (CART_INFO's CRCs, INFO's songs CRC).
   No RAM but this struct (~160 bytes): the SysEx ring stays 64 packets. */
#ifndef LSDJ_STREAM_H
#define LSDJ_STREAM_H
#include <stdint.h>

#define LSDJ_STREAM_BYTES 112u                    /* 16 groups of 7 */
#define LSDJ_STREAM_OP    0x3Bu
#define LSDJ_STREAM_FRAME (6u + 1u + 8u + LSDJ_STREAM_BYTES / 7u * 8u + 1u)   /* 144 */

typedef struct {
    const volatile uint8_t *src;
    volatile uint32_t off, end;
    volatile uint8_t on, what;
    uint8_t fb[LSDJ_STREAM_FRAME];
    volatile uint8_t len, pos;                    /* the frame going out: fb[pos..len) */
} lsdj_stream_t;

/* (main loop, interrupts off around it) a new stream of src[off..end), or none (end <= off): the frame going out
   still finishes */
static void lsdj_stream_start(lsdj_stream_t *s, const volatile uint8_t *src, uint8_t what, uint32_t off, uint32_t end) {
    s->src = src; s->what = what; s->off = off; s->end = end; s->on = (uint8_t)(src && end > off);
}
static int lsdj_stream_mid(const lsdj_stream_t *s) { return s->pos < s->len; }
static int lsdj_stream_busy(const lsdj_stream_t *s) { return s->on || s->pos < s->len; }

static void lsdj_stream_frame(lsdj_stream_t *s) {
    uint32_t off = s->off, n = s->end - off, k = 0;
    if (n > LSDJ_STREAM_BYTES) n = LSDJ_STREAM_BYTES;
    uint8_t *f = s->fb;
    f[k++] = 0xf0; f[k++] = 0x7d; f[k++] = 'G'; f[k++] = 'S'; f[k++] = LSDJ_STREAM_OP; f[k++] = 0; f[k++] = s->what & 127u;
    for (unsigned b = 0; b < 4u; b++) { uint8_t v = (uint8_t)(off >> (8u * b)); f[k++] = v & 127u; f[k++] = v >> 7; }
    for (uint32_t g = 0; g < n; g += 7u) {
        uint32_t m = n - g < 7u ? n - g : 7u, hi = k++; uint8_t h = 0;
        for (uint32_t i = 0; i < m; i++) { uint8_t v = s->src[off + g + i]; h |= (uint8_t)((v >> 7) << i); f[k++] = v & 127u; }
        f[hi] = h;
    }
    f[k++] = 0xf7;
    s->len = (uint8_t)k; s->pos = 0;
    s->off = off + n;
    if (s->off >= s->end) s->on = 0;
}
/* (the USB interrupt) the next USB-MIDI packet (cable 0), or 0: nothing, or at a frame's end while yield */
static int lsdj_stream_next(lsdj_stream_t *s, uint32_t *pkt, int yield) {
    if (s->pos >= s->len) {
        if (!s->on || yield) return 0;
        lsdj_stream_frame(s);
    }
    uint32_t i = s->pos, left = s->len - i, k = left >= 3u ? 3u : left;
    uint32_t cin = k == 3u && i + 3u < s->len ? 4u : k == 3u ? 7u : 4u + k;   /* 4 continues; 5/6/7 end (as ota_wire_send) */
    *pkt = cin | (uint32_t)s->fb[i] << 8 | (k > 1u ? (uint32_t)s->fb[i + 1] << 16 : 0u) | (k > 2u ? (uint32_t)s->fb[i + 2] << 24 : 0u);
    s->pos = (uint8_t)(i + k);
    return 1;
}
#endif
