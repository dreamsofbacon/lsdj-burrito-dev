/* SPDX-License-Identifier: GPL-3.0-only */
/* Presets (0.9.98-dev.6): 8 slots on the FM-1, each everything a player sets: the effects (all 19 words, reverb and
   sends included), the settings word (theme, knobs, PLAY/REC ...), the MIDI options, the feature switches and the
   custom theme's 8 colours, with a name.

   On the FM-1: hold EDIT and press C4 D4 E4 F4 G4 A4 B4 C5 (slots 1..8) to load one; EDIT + SELECT (the button)
   opens the list, where a key saves everything now into that slot. The effects slide to the preset's values over
   PRESET GLIDE (lsdj_feat.h). Device housekeeping (AUTOSAVE, SCREEN RATE, BATTERY, PRESET GLIDE) stays as it is.
   The web page reads and writes the slots over the link (lsdj_link.h PRESET_*).

   The page (kept as the save store's block 32, lsdj_ftl.h; 0xFF to 4 KiB): a 16-byte head, then 8 slots of 128
   bytes (one link packet each). Little endian.
     head  u32 magic "FMPR", u8 version (1), u8 the current slot (0..7, 0xFF none), 10 bytes 0xFF
     slot  u8 used (LSDJ_PRESET_USED, else empty), u8 effects words (19), 12 bytes name (A-Z 0-9 and LSDj's
           punctuation, space padded), 2 bytes 0, 19 x u32 effects (lsdj_fx_ui.h lsdj_fx_pack), u32 settings
           (lsdj_settings.h), u32 MIDI (lsdj_midi.h), u32 feature switches (lsdj_feat.h), 8 x u16 custom theme
           (lsdj_theme.h lsdj_theme_to8), 8 bytes 0
   An erased page (all 0xFF) is a page with no presets.
   Pure logic: tests/lsdj_presets.c. */
#pragma once
#include <stdint.h>
#include <string.h>
#include "lsdj_fx.h"
#include "lsdj_feat.h"

#define LSDJ_PRESETS 8u
#define LSDJ_PRESET_BYTES 128u
#define LSDJ_PRESET_NAME 12u
#define LSDJ_PRESET_FX 19u                   /* = LSDJ_FX_WORDS */
#define LSDJ_PRESET_USED 0x50u               /* 'P' */
#define LSDJ_PRESETS_HEAD 16u
#define LSDJ_PRESETS_PAGE (LSDJ_PRESETS_HEAD + LSDJ_PRESETS * LSDJ_PRESET_BYTES)   /* 1040 */
#define LSDJ_PRESETS_MAGIC 0x52504D46u       /* "FMPR" */
#define LSDJ_PRESETS_VERSION 1u
#define LSDJ_PRESET_NONE 0xFFu
/* slot offsets */
enum { LSDJ_PS_USED = 0, LSDJ_PS_NFX = 1, LSDJ_PS_NAME = 2, LSDJ_PS_FX = 16, LSDJ_PS_SETTINGS = 92, LSDJ_PS_MIDI = 96,
       LSDJ_PS_FEAT = 100, LSDJ_PS_THEME = 104, LSDJ_PS_END = 120 };
/* the keys (bit k = key k, F3 = 0, as fm1_lsdj_input.h): the white keys C4 .. C5 */
static const uint8_t lsdj_preset_key[LSDJ_PRESETS] = {7u, 9u, 11u, 12u, 14u, 16u, 18u, 19u};

typedef struct {
    char name[LSDJ_PRESET_NAME + 1];         /* 0-terminated, no trailing spaces */
    uint32_t fx[LSDJ_PRESET_FX], settings, midi, feat;
    uint16_t theme[8];
} lsdj_preset_t;

static uint32_t lsdj_ps_rd32(const uint8_t *p) { return p[0] | (uint32_t)p[1] << 8 | (uint32_t)p[2] << 16 | (uint32_t)p[3] << 24; }
static void lsdj_ps_wr32(uint8_t *p, uint32_t v) { p[0] = (uint8_t)v; p[1] = (uint8_t)(v >> 8); p[2] = (uint8_t)(v >> 16); p[3] = (uint8_t)(v >> 24); }

/* A character a name may hold (LSDj's font: lsdj_native.h lsdj_nat_tile), lower case read as upper; else 0. */
static char lsdj_preset_char(char c) {
    if (c >= 'a' && c <= 'z') c = (char)(c - 32);
    if ((c >= 'A' && c <= 'Z') || (c >= '0' && c <= '9')) return c;
    for (const char *k = " -#?!.:=+/"; *k; k++) if (c == *k) return c;
    return 0;
}
/* The page has presets (its head is ours); an erased or foreign page has none. */
static int lsdj_presets_ok(const uint8_t *page) {
    return lsdj_ps_rd32(page) == LSDJ_PRESETS_MAGIC && page[4] == LSDJ_PRESETS_VERSION;
}
static const uint8_t *lsdj_preset_slot(const uint8_t *page, unsigned i) { return page + LSDJ_PRESETS_HEAD + (i % LSDJ_PRESETS) * LSDJ_PRESET_BYTES; }
static int lsdj_preset_used(const uint8_t *page, unsigned i) {
    return i < LSDJ_PRESETS && lsdj_presets_ok(page) && lsdj_preset_slot(page, i)[LSDJ_PS_USED] == LSDJ_PRESET_USED;
}
static unsigned lsdj_presets_current(const uint8_t *page) {
    return lsdj_presets_ok(page) && page[5] < LSDJ_PRESETS ? page[5] : LSDJ_PRESET_NONE;
}
/* An empty page with our head (the first preset kept on an erased page starts it). */
static void lsdj_presets_start(uint8_t *page) {
    memset(page, 0xFF, LSDJ_PRESETS_PAGE);
    lsdj_ps_wr32(page, LSDJ_PRESETS_MAGIC); page[4] = LSDJ_PRESETS_VERSION; page[5] = LSDJ_PRESET_NONE;
    for (unsigned i = 0; i < LSDJ_PRESETS; i++) memset(page + LSDJ_PRESETS_HEAD + i * LSDJ_PRESET_BYTES, 0, LSDJ_PRESET_BYTES);
}
static void lsdj_presets_set_current(uint8_t *page, unsigned i) {
    if (!lsdj_presets_ok(page)) lsdj_presets_start(page);
    page[5] = i < LSDJ_PRESETS ? (uint8_t)i : LSDJ_PRESET_NONE;
}
/* "PRESET 3": the name a preset gets when none is given. */
static void lsdj_preset_default_name(unsigned i, char name[LSDJ_PRESET_NAME + 1]) {
    memcpy(name, "PRESET ", 7); name[7] = (char)('1' + i % LSDJ_PRESETS); name[8] = 0;
}
/* A slot's 128 bytes as sent over the link (PRESET_PUT) are well formed: used and 19 words, a name of allowed
   characters (at least one not a space), zero fill. The words' values are checked where they are applied. An
   empty slot (used byte 0) is fine too: it clears the slot. 1 = ok. */
static int lsdj_preset_raw_ok(const uint8_t b[LSDJ_PRESET_BYTES]) {
    if (b[LSDJ_PS_USED] != LSDJ_PRESET_USED) {
        for (unsigned i = 0; i < LSDJ_PRESET_BYTES; i++) if (b[i]) return 0;
        return 1;
    }
    if (b[LSDJ_PS_NFX] != LSDJ_PRESET_FX || b[14] || b[15]) return 0;
    int letters = 0;
    for (unsigned i = 0; i < LSDJ_PRESET_NAME; i++) {
        char c = (char)b[LSDJ_PS_NAME + i];
        if (lsdj_preset_char(c) != c) return 0;
        letters |= c != ' ';
    }
    for (unsigned i = LSDJ_PS_END; i < LSDJ_PRESET_BYTES; i++) if (b[i]) return 0;
    return letters;
}
/* A slot's 128 bytes (used) into p. */
static void lsdj_preset_read(const uint8_t *s, lsdj_preset_t *p) {
    unsigned n = 0;
    for (unsigned k = 0; k < LSDJ_PRESET_NAME; k++) p->name[k] = (char)s[LSDJ_PS_NAME + k];
    for (unsigned k = 0; k < LSDJ_PRESET_NAME; k++) if (p->name[k] != ' ') n = k + 1u;
    p->name[n] = 0;
    for (unsigned k = 0; k < LSDJ_PRESET_FX; k++) p->fx[k] = lsdj_ps_rd32(s + LSDJ_PS_FX + 4u * k);
    p->settings = lsdj_ps_rd32(s + LSDJ_PS_SETTINGS); p->midi = lsdj_ps_rd32(s + LSDJ_PS_MIDI); p->feat = lsdj_ps_rd32(s + LSDJ_PS_FEAT);
    for (unsigned k = 0; k < 8u; k++) p->theme[k] = (uint16_t)(s[LSDJ_PS_THEME + 2u * k] | s[LSDJ_PS_THEME + 2u * k + 1u] << 8);
}
/* Slot i into p. 0 if it is empty. */
static int lsdj_preset_get(const uint8_t *page, unsigned i, lsdj_preset_t *p) {
    if (!lsdj_preset_used(page, i)) return 0;
    lsdj_preset_read(lsdj_preset_slot(page, i), p);
    return 1;
}
/* p into slot i (a name of other characters is cleaned up: lower case to upper, the rest to spaces; none left:
   "PRESET n"). */
static void lsdj_preset_put(uint8_t *page, unsigned i, const lsdj_preset_t *p) {
    if (i >= LSDJ_PRESETS) return;
    if (!lsdj_presets_ok(page)) lsdj_presets_start(page);
    uint8_t *s = page + LSDJ_PRESETS_HEAD + i * LSDJ_PRESET_BYTES;
    char name[LSDJ_PRESET_NAME + 1]; int letters = 0, end = 0;
    for (unsigned k = 0; k < LSDJ_PRESET_NAME; k++) {
        char c = end ? 0 : p->name[k];
        if (!c) end = 1;
        c = lsdj_preset_char(c); if (!c) c = ' ';
        name[k] = c; letters |= c != ' ';
    }
    if (!letters) { lsdj_preset_default_name(i, name); for (unsigned k = 8u; k < LSDJ_PRESET_NAME; k++) name[k] = ' ';   /* ("PRESET n": 8) */ }
    memset(s, 0, LSDJ_PRESET_BYTES);
    s[LSDJ_PS_USED] = LSDJ_PRESET_USED; s[LSDJ_PS_NFX] = LSDJ_PRESET_FX;
    memcpy(s + LSDJ_PS_NAME, name, LSDJ_PRESET_NAME);
    for (unsigned k = 0; k < LSDJ_PRESET_FX; k++) lsdj_ps_wr32(s + LSDJ_PS_FX + 4u * k, p->fx[k]);
    lsdj_ps_wr32(s + LSDJ_PS_SETTINGS, p->settings); lsdj_ps_wr32(s + LSDJ_PS_MIDI, p->midi); lsdj_ps_wr32(s + LSDJ_PS_FEAT, p->feat);
    for (unsigned k = 0; k < 8u; k++) { s[LSDJ_PS_THEME + 2u * k] = (uint8_t)p->theme[k]; s[LSDJ_PS_THEME + 2u * k + 1u] = (uint8_t)(p->theme[k] >> 8); }
}
/* Slot i's 128 bytes from the link (already lsdj_preset_raw_ok and its words checked). */
static void lsdj_preset_put_raw(uint8_t *page, unsigned i, const uint8_t b[LSDJ_PRESET_BYTES]) {
    if (i >= LSDJ_PRESETS) return;
    if (!lsdj_presets_ok(page)) lsdj_presets_start(page);
    memcpy(page + LSDJ_PRESETS_HEAD + i * LSDJ_PRESET_BYTES, b, LSDJ_PRESET_BYTES);
    if (b[LSDJ_PS_USED] != LSDJ_PRESET_USED && page[5] == i) page[5] = LSDJ_PRESET_NONE;
}
/* The list line of slot i: "1 C4  DUB ECHO" or "1 C4  -" (19 characters at most). */
static void lsdj_preset_line(const uint8_t *page, unsigned i, char line[20]) {
    static const char *const key[LSDJ_PRESETS] = {"C4", "D4", "E4", "F4", "G4", "A4", "B4", "C5"};
    unsigned n = 0;
    line[n++] = (char)('1' + i % LSDJ_PRESETS); line[n++] = ' ';
    line[n++] = key[i % LSDJ_PRESETS][0]; line[n++] = key[i % LSDJ_PRESETS][1]; line[n++] = ' '; line[n++] = ' ';
    lsdj_preset_t p;
    if (lsdj_preset_get(page, i, &p)) for (const char *c = p.name; *c; c++) line[n++] = *c;
    else line[n++] = '-';
    line[n] = 0;
}

/* The feature switches a preset brings: all but the device's own (AUTOSAVE, SCREEN RATE, BATTERY, PRESET GLIDE). */
static int lsdj_preset_feat_kept(unsigned item) {
    return item == LSDJ_FEAT_AUTOSAVE || item == LSDJ_FEAT_RATE || item == LSDJ_FEAT_BATTERY || item == LSDJ_FEAT_GLIDE;
}
static void lsdj_preset_feat_merge(lsdj_feat_t *now, const lsdj_feat_t *preset) {
    for (unsigned i = 0; i < LSDJ_FEAT_ITEMS; i++) if (!lsdj_preset_feat_kept(i)) now->v[i] = preset->v[i];
}

/* ---------- glide: the effects slide to a preset's values ----------
   Amounts move in a straight line over ms; choices (filter type, distortion, LFO shape and destination, echo sync
   and mode, FX off, bypass) take the new value at once, and the echo time too when SYNC changes (free and synced
   times are different scales). Someone else changing the effects meanwhile (a knob, the web page, MIDI CC) ends the
   glide where it is: lsdj_glide_step sees values it did not write. */
typedef struct {
    lsdj_fx_params_t from, to, last;
    uint32_t start_ms, ms;
    uint8_t on;
} lsdj_glide_t;

/* 1: field f of the params is a choice (never slid) */
static int lsdj_glide_choice(const lsdj_fx_params_t *p, const uint8_t *f) {
    for (unsigned c = 0; c < 4; c++)
        if (f == &p->ch[c][FXP_TYPE] || f == &p->q[c][FXQ_DIST] || f == &p->q[c][FXQ_LFO_SHAPE] || f == &p->q[c][FXQ_LFO_DEST]) return 1;
    return f == &p->m[FXM_SYNC] || f == &p->m[FXM_MODE] || f == &p->fx_off || f == &p->bypass;
}
/* Start sliding *now (the live params) to *to. ms 0: *now becomes *to at once. */
static void lsdj_glide_start(lsdj_glide_t *g, lsdj_fx_params_t *now, const lsdj_fx_params_t *to, uint32_t now_ms, uint32_t ms) {
    g->from = *now; g->to = *to; g->start_ms = now_ms; g->ms = ms; g->on = 0;
    uint8_t *n = (uint8_t *)now; const uint8_t *t = (const uint8_t *)to;
    int sync_changed = now->m[FXM_SYNC] != to->m[FXM_SYNC];
    for (unsigned i = 0; i < sizeof *now; i++) {
        if (!ms || lsdj_glide_choice(now, n + i) || (sync_changed && n + i == &now->m[FXM_TIME])) n[i] = t[i];
        else if (n[i] != t[i]) g->on = 1;
    }
    if (sync_changed) g->from.m[FXM_TIME] = to->m[FXM_TIME];
    g->last = *now;
}
/* Once a frame while on: *now one step further. Returns 1 if it wrote *now (the caller then updates the effects). */
static int lsdj_glide_step(lsdj_glide_t *g, lsdj_fx_params_t *now, uint32_t now_ms) {
    if (!g->on) return 0;
    if (memcmp(now, &g->last, sizeof *now)) { g->on = 0; return 0; }   /* changed by someone else: stop here */
    uint32_t t = now_ms - g->start_ms;
    uint8_t *n = (uint8_t *)now; const uint8_t *a = (const uint8_t *)&g->from, *b = (const uint8_t *)&g->to;
    if (t >= g->ms) { *now = g->to; g->on = 0; }
    else for (unsigned i = 0; i < sizeof *now; i++) {
        if (a[i] == b[i]) continue;
        int32_t v = (int32_t)a[i] + ((int32_t)b[i] - (int32_t)a[i]) * (int32_t)t / (int32_t)g->ms;
        n[i] = (uint8_t)v;
    }
    g->last = *now;
    return 1;
}
