/* SPDX-License-Identifier: GPL-3.0-only */
/* USB audio at the computer's own rate (0.9.98-dev.13). The FM-1 plays 750000 / 17 Hz (48 MHz / 1088: 44,117.647 Hz,
   measured on Colin's FM-1 as 44117), and LSDj runs in that time (gb_port.c GB_PORT_RATE_NUM / _DEN), so its tempo
   and pitch are right in real time. The computer takes 44,100 frames a second of ITS clock. Between the two, a
   resampler (8 taps of a windowed sinc, lsdj_usbrate_taps.h: within 0.05 dB to 10 kHz wherever the output falls between two
   input frames) takes 7500 / 7497 input frames for each output frame, nudged by a slow PI loop on how full
   the USB ring is at each render (its middle, against the host's packets of 44.1 frames a ms): the host gets its own
   rate exactly, whatever its clock, and LSDj's 120 BPM is 120 BPM on the DAW's grid. Felucca's +-1 frame packets
   (usb.c uac_packet) stay as a safety net outside the band; the loop keeps the fill well inside it.
     lsdj_ur_block(u, fill, in, n, ring, mask, w)   one render: fill = the ring's frames when it started (uac
                                                    fill_min), n input frames (int16 L R), written at ring[w & mask]
                                                    on; returns the frames written (n x 7497 / 7500 or so)
   Fixed point, no division: the audio interrupt. Pure logic: tests/lsdj_usbrate.c. */
#pragma once
#include <stdint.h>
#include "lsdj_usbrate_taps.h"

#define LSDJ_UR_ONE (1u << 28)                  /* the step: input frames an output frame, Q28 */
#define LSDJ_UR_NOM 268542873u                  /* 2^28 x 7500 / 7497 (44117.647 / 44100) */
#define LSDJ_UR_SPAN 536870                     /* the loop's reach: +-2000 ppm of the step */

typedef struct {
    int32_t l[8], r[8];                         /* the last eight input frames, oldest first */
    uint32_t acc;                               /* where the next output frame falls after l[3], Q28 */
    uint32_t step;                              /* input frames an output frame, Q28 */
    int32_t ef, integ;                          /* the fill's error, low-passed (x 256); the loop's integral */
    int32_t target;                             /* the fill it holds */
    uint8_t primed;
} lsdj_ur_t;

static void lsdj_ur_init(lsdj_ur_t *u, int32_t target) {
    uint8_t *b = (uint8_t *)u; for (uint32_t i = 0; i < sizeof *u; i++) b[i] = 0;
    u->step = LSDJ_UR_NOM; u->target = target;
}
static int16_t lsdj_ur_dot(const int32_t *h, const int32_t *c) {   /* sum of 8 (|h| < 2^15, sum |c| < 1.3 x 2^14) */
    int32_t y = 0;
    for (uint32_t k = 0; k < 8u; k++) y += c[k] * h[k];
    y = (y + 8192) >> 14;
    return (int16_t)(y > 32767 ? 32767 : y < -32768 ? -32768 : y);
}
static uint32_t lsdj_ur_block(lsdj_ur_t *u, int32_t fill, const int16_t *in, uint32_t n, uint32_t *ring, uint32_t mask,
                              uint32_t w) {
    int32_t e = fill - u->target;
    if (!u->primed) { u->primed = 1; u->ef = e * 256; }
    u->ef += (e * 256 - u->ef) / 64;            /* ~0.37 s at 172 renders a second (the packets' saw tooth out) */
    u->integ += u->ef / 512;                    /* the clocks' difference, learnt in ~15 s */
    if (u->integ > LSDJ_UR_SPAN) u->integ = LSDJ_UR_SPAN; else if (u->integ < -LSDJ_UR_SPAN) u->integ = -LSDJ_UR_SPAN;
    int32_t adj = u->ef * 10 + u->integ;        /* fuller than the middle: take input faster, give fewer frames (~9.5 ppm a frame) */
    if (adj > LSDJ_UR_SPAN) adj = LSDJ_UR_SPAN; else if (adj < -LSDJ_UR_SPAN) adj = -LSDJ_UR_SPAN;
    u->step = (uint32_t)((int32_t)LSDJ_UR_NOM + adj);
    uint32_t k = 0;
    for (uint32_t i = 0; i < n; i++) {
        for (uint32_t j = 0; j < 7u; j++) { u->l[j] = u->l[j + 1u]; u->r[j] = u->r[j + 1u]; }
        u->l[7] = in[2u * i]; u->r[7] = in[2u * i + 1u];
        while (u->acc < LSDJ_UR_ONE) {           /* (the step is over 1: at most one frame an input frame) */
            uint32_t p = u->acc >> 22; int32_t q = (int32_t)((u->acc >> 6) & 0xFFFFu), c[8];   /* the place: 64ths, Q16 */
            for (uint32_t j = 0; j < 8u; j++) c[j] = lsdj_ur_taps[p][j] + (((lsdj_ur_taps[p + 1u][j] - lsdj_ur_taps[p][j]) * q) >> 16);
            ring[(w + k) & mask] = (uint32_t)(uint16_t)lsdj_ur_dot(u->l, c) | (uint32_t)(uint16_t)lsdj_ur_dot(u->r, c) << 16;
            k++; u->acc += u->step;
        }
        u->acc -= LSDJ_UR_ONE;
    }
    return k;
}
