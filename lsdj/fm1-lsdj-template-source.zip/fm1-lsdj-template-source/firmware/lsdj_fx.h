/* SPDX-License-Identifier: GPL-3.0-only */
/* Per-channel effects and a master echo for LSDj on the FM-1. Runs on CPU0 in
   the audio interrupt (gp_audio_read -> lsdj_fx_mix), between the emulator's
   four channels (split, see minigb_apu_split) and the stereo output.

   Per channel (pulse 1, pulse 2, wave, noise), all values 0..127:
     filter type (0 off, 1 low-pass, 2 high-pass, 3 band-pass), cutoff
     (40 Hz .. 8 kHz), resonance, drive (soft saturation), crush (fewer
     bits), decimate (lower sample rate), echo send.
   Per channel also: FX off (plays dry, settings kept; saved) and mute (silent,
   its echo keeps ringing; not saved).
   Master echo, at 22.05 kHz in 8-bit mu-law (LSDJ_FX_ECHO_LEN bytes, 1.49 s):
     time (free: 3 ms .. 1.49 s, ping-pong half that; or synced: a note length
     at LSDj's tempo), feedback, mix, sync, mode (mono / ping-pong), tone
     (64 flat, below darker repeats, above thinner), wobble (tape pitch wobble),
     and freeze (loops what is in the buffer; not saved).
   Alpha 66 (no extra memory, a few bytes of state per channel):
     filter types 4 notch and 5 24 dB low-pass (two stages); warm (the
     filter's resonance saturates: rounder, less shrill); distortion type for
     drive (soft, hard clip, wavefolder, fuzz); an LFO per channel (rate free
     0.05..12.8 Hz or tempo-synced 1/32..4 bars, depth, shape sine / triangle
     / square / saw / random, to the cutoff, the volume or the pan); and a
     master compressor (one amount, make-up gain automatic).
   0.9.97 master reverb (lsdj_fx_set_reverb: LSDJ_FX_RV_LEN 16-bit samples, 6.6 KB): two input allpasses into a
     four-line feedback delay network (Hadamard mixing, a one-pole damping filter in each line) at 22.05 kHz,
     after the echo and before the compressor. MIX, SIZE (decay 0.4 .. 6 s), TONE (damping: dark .. bright); fed by
     each channel's own REVERB SEND (0.9.97-dev.7; dev.1-6 had INPUT: the whole mix or the echo sends).
   0.9.98 (no extra memory, a few words of state per channel), after the open FM-1 firmwares' inserts:
     filter types 6 PHASER (four swept all-passes, RESO its feedback) and 7 VOWEL (three formant band-passes, CUTOFF
     A E I O U); distortion types 4 SINE FOLD, 5 RECT (octave up), 6 RING (DRIVE the ring's pitch), 7 TAPE (soft
     saturation, the highs rolled off, the tone wandering); LFO shapes 5..8, gates (16 steps a cycle, tempo-synced
     rates line up with LSDj's phrase rows: lsdj_fx_row).
     The designs are after Optimist's insert types (github.com/w0ts/optimist, firmware/src/fx/insfx: insfx.c,
     tapespit.c, gater.c; GPL-3.0-only): PHSR, SFLD, RECT, RING after Felucca's (Copyright (C) 2026 Leo Kuroshita
     (@kurogedelic), Hügelton Instruments, GPL-3.0-only); FRMT (Melodee's vowels) and TAPE after Melodee's (Kerem
     Kilic, GPL-3.0-only); the gate patterns are GATER's. Rewritten here per sample at our scale; the tables made by
     tools/gen_fx_tables.py.
   With every value at 0 the output is the plain MiniGB mix, bit for bit.
   Pure logic, fixed point: tests/lsdj_fx.c. */
#pragma once
#include <stdint.h>

#ifndef LSDJ_FX_ECHO_LEN
#define LSDJ_FX_ECHO_LEN 32768u              /* bytes = samples, a power of 2: 1.49 s at 22.05 kHz */
#endif
enum { FXP_TYPE, FXP_CUTOFF, FXP_RESO, FXP_DRIVE, FXP_CRUSH, FXP_DECIM, FXP_SEND, FXP_CH_COUNT };
enum { FXM_TIME, FXM_FEEDBACK, FXM_MIX, FXM_SYNC, FXM_MODE, FXM_TONE, FXM_WOBBLE, FXM_COUNT };
/* alpha 66, per channel: distortion type, warm, LFO rate / depth / shape / destination */
enum { FXQ_DIST, FXQ_WARM, FXQ_LFO_RATE, FXQ_LFO_DEPTH, FXQ_LFO_SHAPE, FXQ_LFO_DEST, FXQ_COUNT };
/* 0.9.97, master reverb */
enum { FXR_MIX, FXR_SIZE, FXR_TONE, FXR_COUNT };
#define LSDJ_FX_RV_SIZE0 64u                 /* the defaults: a medium room, */
#define LSDJ_FX_RV_TONE0 64u                 /* ... damped above about 1.5 kHz */
#define LSDJ_FX_RV_AP1 113u                  /* the input allpasses and the four lines (27-39 ms), 22.05 kHz samples */
#define LSDJ_FX_RV_AP2 241u
static const uint16_t lsdj_fx_rv_line[4] = {601u, 683u, 787u, 863u};
#define LSDJ_FX_RV_LEN (LSDJ_FX_RV_AP1 + LSDJ_FX_RV_AP2 + 601u + 683u + 787u + 863u)
#define LSDJ_FX_FILTERS 8u                   /* off, low-pass, high-pass, band-pass, notch, low-pass 24 dB, phaser, vowel */
#define LSDJ_FX_DISTS 8u                     /* soft, hard, fold, fuzz, sine fold, rect, ring, tape */
#define LSDJ_FX_SHAPES 9u                    /* sine, triangle, square, saw, random, gates: 8ths, offbeat 8ths, trance,
                                                tresillo */
/* the counts before 0.9.98: MIDI CC 70 and 79 keep picking among these (lsdj_midi.h), so a song's CCs sound the same */
#define LSDJ_FX_FILTERS_CC 6u
#define LSDJ_FX_DISTS_CC 4u
#define LSDJ_FX_SHAPES_CC 5u
#define LSDJ_FX_GATES 4u
/* the gates: bit k = step k open (16 steps a cycle, step 0 first; Optimist's GATER 8TH, OFF8, TRNC1, TRESL) */
static const uint16_t lsdj_fx_gate[LSDJ_FX_GATES] = {0x5555, 0x4444, 0x6D6D, 0x4949};
#define LSDJ_FX_DESTS 3u                     /* cutoff, volume, pan */
#define LSDJ_FX_LFO_FREE 64u                 /* rates 0..63 free (Hz), 64..127 tempo-synced notes */
#define LSDJ_FX_LFO_NOTES 15u
/* synced LFO cycles in 1/6 sixteenth notes: the echo's twelve, then 1, 2 and 4 bars */
static const uint16_t lsdj_fx_lfo_note_u[LSDJ_FX_LFO_NOTES] = {3, 4, 6, 8, 9, 12, 16, 18, 24, 32, 36, 48, 96, 192, 384};
static const char *const lsdj_fx_lfo_note_name[LSDJ_FX_LFO_NOTES] = {
    "1/32", "1/16T", "1/16", "1/8T", "1/16.", "1/8", "1/4T", "1/8.", "1/4", "1/2T", "1/4.", "1/2", "1BAR", "2BAR", "4BAR" };
#define LSDJ_FX_TONE_FLAT 64u
#define LSDJ_FX_WOBBLE_MAX 96                /* +-samples of read-position swing */
#define LSDJ_FX_ECHO_MARGIN (4 * LSDJ_FX_WOBBLE_MAX + 4)   /* ping-pong reads 2 x (time + 2 x wobble) back */
#define LSDJ_FX_NOTES 12u
/* Synced echo times in 1/6 sixteenth notes: 1/32 1/16T 1/16 1/8T 1/16. 1/8 1/4T 1/8. 1/4 1/2T 1/4. 1/2 */
static const uint8_t lsdj_fx_note_u[LSDJ_FX_NOTES] = {3, 4, 6, 8, 9, 12, 16, 18, 24, 32, 36, 48};
static const char *const lsdj_fx_note_name[LSDJ_FX_NOTES] = {
    "1/32", "1/16T", "1/16", "1/8T", "1/16.", "1/8", "1/4T", "1/8.", "1/4", "1/2T", "1/4.", "1/2" };

typedef struct {
    uint8_t ch[4][FXP_CH_COUNT];             /* per channel parameters */
    uint8_t m[FXM_COUNT];                    /* master echo */
    uint8_t fx_off;                          /* bit c: channel c plays dry */
    uint8_t q[4][FXQ_COUNT];                 /* per channel, alpha 66 */
    uint8_t comp;                            /* master compressor amount */
    uint8_t bypass;                          /* all effects dry; settings retained */
    uint8_t r[FXR_COUNT];                    /* master reverb (0.9.97) */
    uint8_t rs[4];                           /* per channel: its reverb send (0.9.97-dev.7) */
} lsdj_fx_params_t;

typedef struct {
    int32_t low, band;                       /* filter state */
    int32_t low2, band2;                     /* the 24 dB low-pass's second stage */
    int32_t hold; uint32_t hold_n;           /* decimator */
    int32_t dc_x, dc_y;                      /* fuzz: DC blocker */
    uint32_t lfo_ph, lfo_inc, rnd;           /* LFO phase, step per sample, random state */
    int32_t lfo_sh;                          /* random shape: the held value */
    int32_t pan_l, pan_r;                    /* LFO to pan: gains, Q15 */
    int32_t z[8];                            /* PHASER: the four all-passes' last in (0-3) and out (4-7), x 16;
                                                VOWEL: the three band-passes' states (0-5), x 32 */
    int32_t zfb;                             /* PHASER: its feedback */
    uint32_t sw_ph;                          /* PHASER: its own sweep (0.5 Hz) */
    uint32_t d_ph, d_inc;                    /* RING: the sine's phase and step; TAPE: the wander's clock */
    int32_t d_k, d_t, d_lp, d_lp2;           /* TAPE: the tone's wander now and its target (Q15), its two low-passes (x 16) */
} lsdj_fx_chan_t;

typedef struct {
    lsdj_fx_params_t p;
    uint8_t mute;                            /* bit c: channel c silent */
    uint8_t freeze;                          /* echo loops its buffer */
    uint16_t bpm;                            /* LSDj's tempo, for synced times */
    lsdj_fx_chan_t c[4];
    uint8_t *echo; uint32_t echo_pos, echo_half, echo_len, lfo;
    int32_t echo_in, echo_l, echo_r, tone_st, tone_k;
    int32_t comp_env;                        /* compressor: the peak envelope */
    uint8_t active;                          /* anything to do (lsdj_fx_update) */
    int16_t *rv; uint32_t rv_pos[6], rv_half; /* reverb: its lines (none: no reverb), positions */
    int32_t rv_in, rv_l, rv_r, rv_lp[4], rv_g, rv_k, rv_o;
    uint8_t rv_on;                           /* the reverb ran last update (turned on: its lines start silent) */
    uint8_t row_last, bars;                  /* lsdj_fx_row: the phrase row seen last, phrases counted (mod 12) */
} lsdj_fx_t;

/* 2 sin(pi f / 44100) in Q14, f = 40 Hz * 200^(i / 127). */
static const uint16_t lsdj_fx_cutoff[128] = {
93, 97, 101, 106, 110, 115, 120, 125, 130, 136, 142, 148, 154, 161, 167, 175,
182, 190, 198, 206, 215, 224, 234, 244, 254, 265, 276, 288, 300, 313, 326, 340,
355, 370, 386, 402, 419, 437, 456, 475, 495, 516, 538, 561, 585, 610, 636, 663,
692, 721, 752, 784, 817, 852, 888, 926, 966, 1007, 1050, 1094, 1141, 1189, 1240, 1293,
1348, 1405, 1465, 1528, 1593, 1660, 1731, 1805, 1881, 1962, 2045, 2132, 2223, 2317, 2416, 2519,
2626, 2737, 2853, 2975, 3101, 3233, 3370, 3513, 3662, 3817, 3979, 4148, 4324, 4507, 4697, 4896,
5103, 5318, 5543, 5776, 6020, 6273, 6537, 6811, 7097, 7394, 7703, 8025, 8359, 8707, 9068, 9444,
9834, 10239, 10660, 11096, 11548, 12017, 12504, 13007, 13528, 14067, 14624, 15199, 15792, 16403, 17033, 17680
};

/* Stability limit of the filter coefficient per resonance, Q14: a Chamberlin
   filter with damping q is stable only for f < sqrt(q*q + 4) - q (here x 0.97).
   Without it, low resonance with a cutoff above ~121 blew up into distortion. */
static const uint16_t lsdj_fx_fmax[128] = {
13165, 13235, 13306, 13377, 13449, 13521, 13594, 13668, 13743, 13818, 13894, 13971, 14048, 14126, 14205, 14284,
14365, 14446, 14527, 14610, 14694, 14778, 14863, 14948, 15035, 15122, 15210, 15299, 15389, 15480, 15572, 15664,
15757, 15852, 15947, 16043, 16140, 16238, 16337, 16437, 16538, 16639, 16742, 16846, 16951, 17056, 17164, 17271,
17380, 17490, 17601, 17713, 17826, 17941, 18056, 18173, 18291, 18410, 18530, 18651, 18773, 18897, 19021, 19147,
19275, 19403, 19533, 19664, 19796, 19930, 20065, 20201, 20338, 20477, 20617, 20759, 20902, 21046, 21191, 21338,
21487, 21637, 21788, 21941, 22095, 22251, 22408, 22566, 22726, 22888, 23051, 23216, 23382, 23550, 23719, 23890,
24063, 24237, 24412, 24589, 24769, 24949, 25131, 25315, 25500, 25687, 25876, 26066, 26258, 26452, 26648, 26845,
27043, 27244, 27446, 27650, 27856, 28063, 28273, 28484, 28696, 28911, 29127, 29344, 29564, 29785, 30009, 30234
};

/* PHASER: a first-order all-pass's coefficient (t - 1) / (t + 1), t = tan(pi f / 44100), Q14, f = 100 Hz * 60^(i / 127).
   VOWEL: for each CUTOFF, the three formants' trapezoidal SVF coefficients (A. Simper; a1 a2 a3, Q13, Q 4): A E I O U
   at Melodee's {800,1150,2900} {400,1700,2600} {300,2200,3000} {500,800,2800} {350,650,2700} Hz over 0..127, geometric
   between them (at the vowels the same as Optimist's IFX_FMT). Both from tools/gen_fx_tables.py. */
static const int16_t lsdj_fx_ph_a[128] = {
    -16152, -16145, -16137, -16129, -16121, -16112, -16103, -16094, -16085, -16075, -16065, -16055, -16044, -16033, -16021, -16010,
    -15998, -15985, -15972, -15959, -15945, -15931, -15916, -15901, -15886, -15870, -15853, -15836, -15818, -15800, -15781, -15762,
    -15742, -15721, -15700, -15678, -15655, -15632, -15608, -15583, -15558, -15531, -15504, -15476, -15447, -15417, -15386, -15355,
    -15322, -15288, -15254, -15218, -15181, -15143, -15104, -15064, -15022, -14980, -14936, -14890, -14843, -14795, -14746, -14695,
    -14642, -14588, -14533, -14475, -14416, -14356, -14293, -14229, -14163, -14095, -14025, -13953, -13880, -13804, -13726, -13645,
    -13563, -13478, -13391, -13301, -13210, -13115, -13018, -12919, -12817, -12712, -12604, -12494, -12380, -12264, -12145, -12023,
    -11897, -11769, -11637, -11502, -11364, -11222, -11077, -10928, -10776, -10620, -10460, -10297, -10130, -9959, -9784, -9605,
    -9421, -9234, -9042, -8847, -8646, -8442, -8232, -8019, -7800, -7576, -7348, -7115, -6876, -6633, -6384, -6129,
};
static const int16_t lsdj_fx_vowel[128][9] = {
    {8052, 458, 26, 7975, 654, 53, 7473, 1565, 327}, {8056, 448, 24, 7972, 661, 54, 7476, 1560, 325}, {8060, 438, 23, 7970, 669, 56, 7479, 1555, 323}, {8062, 429, 22, 7966, 678, 57, 7483, 1551, 321},
    {8065, 421, 21, 7962, 686, 59, 7486, 1546, 319}, {8069, 411, 20, 7958, 693, 60, 7489, 1541, 317}, {8071, 401, 19, 7955, 703, 62, 7493, 1536, 315}, {8075, 394, 19, 7951, 710, 63, 7496, 1531, 312},
    {8077, 386, 18, 7947, 719, 65, 7499, 1526, 310}, {8081, 376, 17, 7943, 727, 66, 7503, 1522, 308}, {8083, 369, 16, 7939, 736, 68, 7506, 1517, 306}, {8087, 361, 16, 7936, 745, 70, 7509, 1512, 304},
    {8089, 353, 15, 7932, 755, 71, 7513, 1507, 302}, {8091, 345, 14, 7928, 764, 73, 7516, 1502, 300}, {8093, 339, 14, 7924, 771, 75, 7520, 1498, 298}, {8097, 332, 13, 7921, 781, 77, 7521, 1494, 296},
    {8099, 324, 12, 7915, 790, 78, 7525, 1489, 294}, {8101, 318, 12, 7911, 801, 81, 7528, 1485, 292}, {8102, 310, 11, 7906, 810, 83, 7531, 1480, 290}, {8104, 304, 11, 7902, 819, 84, 7535, 1475, 288},
    {8108, 296, 10, 7898, 829, 87, 7538, 1470, 286}, {8108, 290, 10, 7893, 840, 89, 7540, 1467, 285}, {8110, 285, 10, 7889, 849, 91, 7543, 1462, 283}, {8112, 279, 9, 7884, 860, 93, 7547, 1457, 281},
    {8114, 273, 9, 7880, 869, 95, 7550, 1452, 279}, {8116, 267, 8, 7874, 880, 98, 7553, 1447, 277}, {8118, 261, 8, 7869, 891, 100, 7555, 1444, 276}, {8120, 255, 8, 7865, 900, 103, 7559, 1439, 274},
    {8122, 249, 7, 7860, 911, 105, 7562, 1434, 272}, {8124, 243, 7, 7854, 922, 108, 7565, 1429, 270}, {8126, 240, 7, 7848, 933, 110, 7567, 1426, 268}, {8128, 234, 6, 7843, 943, 113, 7570, 1421, 266},
    {8128, 230, 6, 7837, 954, 116, 7570, 1419, 266}, {8130, 228, 6, 7834, 962, 118, 7569, 1424, 268}, {8130, 226, 6, 7830, 969, 119, 7564, 1431, 270}, {8130, 224, 6, 7827, 976, 121, 7560, 1437, 273},
    {8130, 222, 6, 7821, 985, 124, 7557, 1442, 275}, {8132, 220, 5, 7817, 992, 125, 7552, 1449, 278}, {8132, 218, 5, 7814, 999, 127, 7548, 1453, 279}, {8132, 216, 5, 7810, 1008, 130, 7545, 1460, 282},
    {8134, 214, 5, 7806, 1015, 132, 7540, 1467, 285}, {8134, 212, 5, 7803, 1023, 134, 7536, 1471, 287}, {8134, 210, 5, 7797, 1031, 136, 7533, 1478, 290}, {8136, 208, 5, 7794, 1038, 138, 7528, 1485, 292},
    {8136, 206, 5, 7790, 1047, 140, 7525, 1491, 295}, {8136, 204, 5, 7787, 1055, 142, 7521, 1496, 297}, {8136, 202, 5, 7781, 1063, 145, 7516, 1502, 300}, {8138, 200, 4, 7778, 1070, 147, 7511, 1509, 303},
    {8138, 198, 4, 7772, 1079, 149, 7508, 1515, 305}, {8138, 196, 4, 7769, 1088, 152, 7503, 1522, 308}, {8140, 194, 4, 7763, 1097, 155, 7499, 1526, 310}, {8140, 194, 4, 7760, 1104, 157, 7496, 1533, 313},
    {8140, 192, 4, 7754, 1113, 159, 7491, 1539, 316}, {8140, 190, 4, 7749, 1121, 162, 7486, 1546, 319}, {8142, 188, 4, 7745, 1130, 164, 7483, 1552, 322}, {8142, 186, 4, 7740, 1139, 167, 7478, 1559, 325},
    {8142, 184, 4, 7735, 1148, 170, 7473, 1565, 327}, {8142, 182, 4, 7731, 1157, 173, 7469, 1571, 330}, {8142, 182, 4, 7726, 1165, 175, 7464, 1578, 333}, {8144, 180, 3, 7720, 1174, 178, 7459, 1584, 336},
    {8144, 178, 3, 7715, 1182, 181, 7456, 1590, 339}, {8144, 176, 3, 7710, 1193, 184, 7451, 1597, 342}, {8146, 175, 3, 7704, 1201, 187, 7446, 1603, 345}, {8146, 173, 3, 7699, 1210, 190, 7441, 1609, 348},
    {8146, 175, 3, 7708, 1196, 185, 7441, 1611, 348}, {8144, 176, 3, 7727, 1162, 174, 7443, 1608, 347}, {8144, 180, 3, 7747, 1127, 163, 7444, 1604, 345}, {8142, 182, 4, 7765, 1093, 153, 7446, 1603, 345},
    {8142, 186, 4, 7781, 1061, 144, 7448, 1600, 343}, {8142, 188, 4, 7799, 1030, 136, 7451, 1597, 342}, {8140, 192, 4, 7814, 999, 127, 7453, 1593, 340}, {8140, 194, 4, 7828, 970, 120, 7456, 1590, 339},
    {8138, 198, 4, 7845, 940, 112, 7458, 1587, 337}, {8136, 202, 5, 7858, 913, 106, 7459, 1584, 336}, {8136, 204, 5, 7871, 885, 99, 7463, 1581, 335}, {8136, 208, 5, 7884, 858, 93, 7464, 1578, 333},
    {8134, 212, 5, 7897, 832, 87, 7466, 1574, 332}, {8134, 214, 5, 7908, 807, 82, 7469, 1571, 330}, {8132, 218, 5, 7919, 783, 77, 7471, 1568, 329}, {8130, 222, 6, 7930, 758, 72, 7473, 1565, 327},
    {8130, 226, 6, 7939, 736, 68, 7476, 1562, 326}, {8128, 230, 6, 7949, 714, 64, 7478, 1559, 325}, {8128, 232, 6, 7960, 691, 60, 7479, 1555, 323}, {8126, 236, 6, 7968, 671, 56, 7483, 1552, 322},
    {8126, 240, 7, 7977, 650, 53, 7483, 1551, 321}, {8124, 243, 7, 7985, 631, 49, 7486, 1548, 320}, {8122, 247, 7, 7992, 612, 46, 7488, 1544, 318}, {8122, 251, 7, 8000, 593, 44, 7489, 1541, 317},
    {8120, 255, 8, 8008, 574, 41, 7493, 1538, 315}, {8120, 259, 8, 8013, 557, 38, 7494, 1535, 314}, {8118, 265, 8, 8021, 540, 36, 7496, 1531, 312}, {8116, 269, 8, 8027, 523, 34, 7499, 1528, 311},
    {8114, 273, 9, 8033, 507, 32, 7499, 1526, 310}, {8114, 277, 9, 8038, 492, 30, 7501, 1523, 309}, {8112, 283, 9, 8044, 477, 28, 7504, 1520, 308}, {8110, 287, 10, 8050, 461, 26, 7506, 1517, 306},
    {8110, 285, 10, 8052, 456, 25, 7508, 1515, 305}, {8112, 283, 9, 8054, 454, 25, 7508, 1514, 305}, {8112, 279, 9, 8054, 450, 25, 7509, 1512, 304}, {8114, 275, 9, 8056, 448, 24, 7511, 1511, 303},
    {8114, 273, 9, 8058, 444, 24, 7511, 1509, 303}, {8116, 269, 8, 8058, 442, 24, 7513, 1507, 302}, {8116, 267, 8, 8060, 438, 23, 7514, 1506, 301}, {8118, 263, 8, 8060, 436, 23, 7514, 1504, 301},
    {8118, 261, 8, 8062, 433, 23, 7516, 1502, 300}, {8120, 257, 8, 8062, 431, 23, 7518, 1501, 299}, {8120, 255, 8, 8064, 427, 22, 7518, 1499, 298}, {8122, 251, 7, 8064, 425, 22, 7520, 1498, 298},
    {8122, 249, 7, 8065, 421, 21, 7521, 1496, 297}, {8122, 247, 7, 8065, 419, 21, 7521, 1494, 296}, {8124, 243, 7, 8067, 417, 21, 7523, 1493, 296}, {8124, 241, 7, 8067, 413, 21, 7525, 1491, 295},
    {8126, 238, 6, 8069, 411, 20, 7525, 1489, 294}, {8126, 236, 6, 8069, 409, 20, 7526, 1488, 294}, {8128, 234, 6, 8071, 405, 20, 7526, 1486, 293}, {8128, 230, 6, 8071, 403, 20, 7526, 1486, 293},
    {8130, 228, 6, 8073, 400, 19, 7528, 1485, 292}, {8130, 226, 6, 8073, 398, 19, 7530, 1483, 292}, {8130, 224, 6, 8073, 396, 19, 7530, 1481, 291}, {8132, 220, 5, 8075, 394, 19, 7531, 1480, 290},
    {8132, 218, 5, 8075, 390, 18, 7533, 1478, 290}, {8132, 216, 5, 8077, 388, 18, 7533, 1476, 289}, {8134, 214, 5, 8077, 386, 18, 7535, 1475, 288}, {8134, 210, 5, 8079, 382, 18, 7536, 1473, 288},
    {8136, 208, 5, 8079, 380, 17, 7536, 1471, 287}, {8136, 206, 5, 8079, 378, 17, 7538, 1470, 286}, {8136, 204, 5, 8081, 376, 17, 7540, 1468, 286}, {8136, 202, 5, 8083, 372, 17, 7540, 1467, 285},
};

/* sin(2 pi ph / 2^32), -32767..32767: a parabola and one correction (within about 0.1 %) */
static int32_t lsdj_fx_sin(uint32_t ph) {
    int32_t x = (int32_t)ph >> 16;                       /* -32768..32767: -pi..pi */
    int32_t y = (x * (32768 - (x < 0 ? -x : x))) >> 13;   /* 4 x (1 - |x|) */
    y += ((((y * (y < 0 ? -y : y)) >> 15) - y) * 7373) >> 15;   /* + 0.225 (y |y| - y) */
    return y > 32767 ? 32767 : y < -32767 ? -32767 : y;
}
/* RING: the sine's step a sample for DRIVE 1..127: 26 Hz * 100^((d - 1) / 126) (2^(1/16) steps) */
static uint32_t lsdj_fx_ring_step(unsigned d) {
    static const uint16_t e16[16] = {32768, 34219, 35734, 37316, 38968, 40693, 42495, 44376,
                                     46341, 48393, 50535, 52773, 55109, 57549, 60097, 62757};   /* 2^(i/16), Q15 */
    unsigned n = d ? (d - 1u) * 216u >> 8 : 0u;          /* 1/16 octaves: 0 .. 106 (6.6 octaves) */
    return (uint32_t)(((uint64_t)2532140u * e16[n & 15u] << (n >> 4)) >> 15);   /* 2532140: 26 Hz */
}

/* 8-bit mu-law (G.711) for the echo buffer: about 13 bits of range in a byte. */
static uint8_t lsdj_fx_ulaw(int32_t x) {
    uint8_t mask = 0xFF;
    x >>= 2;
    if (x < 0) { x = -x; mask = 0x7F; }
    if (x > 8158) x = 8158;
    x += 33;
    uint32_t seg = 0; for (int32_t v = x >> 6; v; v >>= 1) seg++;
    return (uint8_t)(((seg << 4) | ((uint32_t)(x >> (seg + 1)) & 15u)) ^ mask);
}
static int32_t lsdj_fx_unulaw(uint8_t u) {
    u = (uint8_t)~u;
    int32_t t = (((int32_t)u & 15) << 3) + 0x84;
    t <<= (u >> 4) & 7u;
    return (u & 0x80) ? 0x84 - t : t - 0x84;
}
#define LSDJ_FX_SILENT_BYTE 0xFFu            /* lsdj_fx_ulaw(0) */

static void lsdj_fx_init(lsdj_fx_t *f, uint8_t *echo_buf) {
    uint8_t *b = (uint8_t *)f; for (uint32_t i = 0; i < sizeof *f; i++) b[i] = 0;
    f->echo = echo_buf; f->bpm = 120; f->p.m[FXM_TONE] = LSDJ_FX_TONE_FLAT; f->row_last = 15u; f->bars = 11u;   /* (lsdj_fx_row_stop) */
    f->p.r[FXR_SIZE] = LSDJ_FX_RV_SIZE0; f->p.r[FXR_TONE] = LSDJ_FX_RV_TONE0;
    for (uint32_t c = 0; c < 4; c++) { f->c[c].pan_l = f->c[c].pan_r = 32768; f->c[c].rnd = 0x9E3779B9u * (c + 1u); }
    for (uint32_t i = 0; i < LSDJ_FX_ECHO_LEN; i++) echo_buf[i] = LSDJ_FX_SILENT_BYTE;
}
/* LFO step per 44.1 kHz sample (2^32 a cycle) for a RATE value: 0..63 free, 0.05 Hz doubling every 8 to
   about 12 Hz; 64..127 one of the synced cycles at LSDj's tempo (2^32 / (44100 * 15 / bpm * u / 6)). */
static uint32_t lsdj_fx_lfo_step(unsigned rate, unsigned bpm) {
    if (rate < LSDJ_FX_LFO_FREE) return (4870u << (rate >> 3)) * (8u + (rate & 7u)) / 8u;
    unsigned n = (rate - LSDJ_FX_LFO_FREE) * LSDJ_FX_LFO_NOTES / (128u - LSDJ_FX_LFO_FREE);
    if (bpm < 40u) bpm = 40u;
    return 38957u * bpm / lsdj_fx_lfo_note_u[n];
}
static unsigned lsdj_fx_lfo_note(unsigned rate) { return (rate - LSDJ_FX_LFO_FREE) * LSDJ_FX_LFO_NOTES / (128u - LSDJ_FX_LFO_FREE); }
/* Longest echo time, in 22.05 kHz samples (ping-pong reads twice as far back). */
static uint32_t lsdj_fx_echo_max(const lsdj_fx_t *f) {
    uint32_t m = LSDJ_FX_ECHO_LEN - LSDJ_FX_ECHO_MARGIN;
    return f->p.m[FXM_MODE] ? m / 2u : m;
}
/* The note a synced TIME value picks, and a TIME value for a note. */
static unsigned lsdj_fx_note_of(unsigned time) { return time * LSDJ_FX_NOTES / 128u; }
static unsigned lsdj_fx_time_of(unsigned note) { return (note * 128u + 64u) / LSDJ_FX_NOTES; }
/* Echo time in 22.05 kHz samples from TIME, SYNC, MODE and the tempo. A synced
   time too long for the buffer halves until it fits. */
static uint32_t lsdj_fx_echo_samples(const lsdj_fx_t *f) {
    uint32_t max = lsdj_fx_echo_max(f), t = f->p.m[FXM_TIME];
    if (!f->p.m[FXM_SYNC]) return 64u + t * (max - 64u) / 127u;
    uint32_t bpm = f->bpm < 40u ? 40u : f->bpm;
    uint32_t n = 55125u * lsdj_fx_note_u[lsdj_fx_note_of(t)] / bpm;   /* 22050 * 15 / bpm / 6 per unit */
    while (n > max) n /= 2u;
    return n < 64u ? 64u : n;
}
/* The reverb's lines (LSDJ_FX_RV_LEN samples); without them REVERB does nothing. */
static void lsdj_fx_set_reverb(lsdj_fx_t *f, int16_t *buf) { f->rv = buf; f->rv_on = 0; }
/* Call after changing f->p, f->mute or f->bpm. */
static void lsdj_fx_update(lsdj_fx_t *f) {
    uint8_t rv = f->rv && f->p.r[FXR_MIX];
    if (rv && !f->rv_on) {                   /* turned on: start from silence, not what was left */
        for (uint32_t i = 0; i < LSDJ_FX_RV_LEN; i++) f->rv[i] = 0;
        for (uint32_t i = 0; i < 4; i++) f->rv_lp[i] = 0;
        f->rv_l = f->rv_r = f->rv_in = 0;
    }
    f->rv_on = rv;
    /* decay per pass, Q14: 0.57 .. 0.96 (with lines of 27-39 ms: about 0.4 .. 6 s to fade 60 dB);
       damping, Q14: a one-pole low-pass from ~400 Hz (TONE 0) to open (127) */
    f->rv_g = 9270 + (int32_t)f->p.r[FXR_SIZE] * (15775 - 9270) / 127;
    f->rv_k = 1800 + (int32_t)f->p.r[FXR_TONE] * f->p.r[FXR_TONE] * (16384 - 1800) / (127 * 127);
    /* output level, Q14: 0.7 sqrt(1 - g^2), so a long tail (more energy kept) is no louder than a short one; MIX 127
       about as loud as the dry sound */
    {
        uint32_t v = 268435456u - (uint32_t)(f->rv_g * f->rv_g), r = 0;
        for (uint32_t b = 1u << 30; b; b >>= 2) { if (v >= r + b) { v -= r + b; r = (r >> 1) + b; } else r >>= 1; }
        f->rv_o = (int32_t)r * 7 / 10;
    }
    uint8_t any = (uint8_t)(f->p.m[FXM_MIX] != 0) | f->mute | f->p.comp | rv;
    for (uint32_t c = 0; c < 4; c++) {
        if (!((f->p.fx_off >> c) & 1u))
            any |= f->p.ch[c][FXP_TYPE] | f->p.ch[c][FXP_DRIVE] | f->p.ch[c][FXP_CRUSH] |
                   f->p.ch[c][FXP_DECIM] | f->p.ch[c][FXP_SEND] | f->p.q[c][FXQ_LFO_DEPTH];
        f->c[c].lfo_inc = lsdj_fx_lfo_step(f->p.q[c][FXQ_LFO_RATE], f->bpm);
        f->c[c].d_inc = lsdj_fx_ring_step(f->p.ch[c][FXP_DRIVE]);
        if (!f->c[c].d_k) f->c[c].d_k = f->c[c].d_t = 32768;   /* TAPE: its wander from the middle */
        if (!f->p.q[c][FXQ_LFO_DEPTH] || f->p.q[c][FXQ_LFO_DEST] != 2u) f->c[c].pan_l = f->c[c].pan_r = 32768;
    }
    f->echo_len = lsdj_fx_echo_samples(f);
    /* Tone: a one-pole filter on what goes into the buffer, Q14. Below 64 a
       low-pass (repeats darker, down to ~300 Hz); above, a high-pass (thinner, up to ~1.5 kHz). */
    int32_t t = f->p.m[FXM_TONE];
    f->tone_k = t < 64 ? 1300 + (t * t) * (16384 - 1300) / (63 * 63)
              : t > 64 ? (t - 64) * (t - 64) * 7000 / (63 * 63) : 0;
    f->active = any != 0;
}
static void lsdj_fx_set_bpm(lsdj_fx_t *f, unsigned bpm) {
    if (bpm == f->bpm) return;
    f->bpm = (uint16_t)bpm;
    if (f->p.m[FXM_SYNC]) f->echo_len = lsdj_fx_echo_samples(f);
    for (uint32_t c = 0; c < 4; c++)
        if (f->p.q[c][FXQ_LFO_RATE] >= LSDJ_FX_LFO_FREE) f->c[c].lfo_inc = lsdj_fx_lfo_step(f->p.q[c][FXQ_LFO_RATE], bpm);
}

/* LSDj's phrase row (0..15) was seen to change while it plays (once a frame at most): each tempo-synced LFO moves
   towards where it would be had it started on row 00 of the first phrase, so a gate's step 0 and a cycle's start
   fall on LSDj's bars. The phrases are counted (a row lower than the last starts the next one; 12 of them hold every
   synced cycle a whole number of times). A quarter of the way a row, or at once when more than 1/8 cycle off. The
   row is seen up to a frame late: half a frame (367 samples) is added. */
static void lsdj_fx_row(lsdj_fx_t *f, unsigned row) {
    row &= 15u;
    if (row == f->row_last) return;
    if (row < f->row_last) f->bars = (uint8_t)((f->bars + 1u) % 12u);
    f->row_last = (uint8_t)row;
    uint32_t pos = ((uint32_t)f->bars * 16u + row) * 6u;   /* LSDj ticks (6 a row) */
    for (uint32_t c = 0; c < 4; c++) {
        unsigned rate = f->p.q[c][FXQ_LFO_RATE];
        if (rate < LSDJ_FX_LFO_FREE) continue;
        uint32_t u = lsdj_fx_lfo_note_u[lsdj_fx_lfo_note(rate)];
        lsdj_fx_chan_t *s = &f->c[c];
        uint32_t want = (uint32_t)(((uint64_t)(pos % u) << 32) / u) + s->lfo_inc * 367u;
        int32_t err = (int32_t)(want - s->lfo_ph);
        s->lfo_ph += err > (1 << 29) || err < -(1 << 29) ? (uint32_t)err : (uint32_t)(err / 4);
    }
}
/* LSDj stopped: the next row 00 starts the count again (its first phrase) */
static void lsdj_fx_row_stop(lsdj_fx_t *f) { f->row_last = 15u; f->bars = 11u; }
static int32_t lsdj_fx_clamp16(int32_t v) { return v > 32767 ? 32767 : v < -32768 ? -32768 : v; }
/* Filter state limit (x 256 scale) and a Q14 multiply in 32 bits for |b| < 2^21:
   b = hi * 64 + lo (lo 0..63), so a * hi and a * lo both stay below 2^31. */
static int32_t lsdj_fx_clampst(int32_t v) { return v > 2000000 ? 2000000 : v < -2000000 ? -2000000 : v; }
static int32_t lsdj_fx_mq14(int32_t a, int32_t b) {
    int32_t hi = b >> 6, lo = b - (hi << 6);
    return ((a * hi) >> 8) + ((a * lo) >> 14);
}

/* The LFO's next value, -32768..32767 (one per sample, the channel's step). */
static int32_t lsdj_fx_lfo(lsdj_fx_chan_t *s, unsigned shape) {
    uint32_t ph = s->lfo_ph + s->lfo_inc;
    int wrapped = ph < s->lfo_ph;
    s->lfo_ph = ph;
    int32_t tri = (int32_t)(ph >> 16) - 32768;
    tri = (tri < 0 ? -tri : tri) * 2 - 32768;
    if (tri > 32767) tri = 32767;
    switch (shape) {
    case 0: return tri * (65536 - (tri < 0 ? -tri : tri)) >> 15;              /* sine (parabolic) */
    case 1: return tri;
    case 2: return ph < 0x80000000u ? 32767 : -32768;                          /* square */
    case 3: return 32767 - (int32_t)(ph >> 16);                                /* saw, falling */
    case 4:                                                                    /* random: a new value each cycle */
        if (wrapped) { s->rnd = s->rnd * 1664525u + 1013904223u; s->lfo_sh = (int32_t)(s->rnd >> 16) - 32768; }
        return s->lfo_sh;
    default: {                               /* a gate: 16 steps a cycle, open -32768 (VOL: full), shut 32767 (VOL: silent
                                                at full depth); ramps of ~1 ms, no click at an edge */
        int32_t to = (lsdj_fx_gate[(shape - 5u) % LSDJ_FX_GATES] >> (ph >> 28)) & 1u ? -32768 : 32767, d = to - s->lfo_sh;
        s->lfo_sh += d > 1366 ? 1366 : d < -1366 ? -1366 : d;
        return s->lfo_sh;
    }
    }
}

/* One channel sample (MiniGB scale, about +-1024) through its effects. */
static int32_t lsdj_fx_chan(lsdj_fx_chan_t *s, const uint8_t *p, const uint8_t *q, int32_t x) {
    int32_t depth = q[FXQ_LFO_DEPTH], lfo = depth ? lsdj_fx_lfo(s, q[FXQ_LFO_SHAPE]) : 0;
    unsigned dest = q[FXQ_LFO_DEST];
    if (p[FXP_DRIVE]) {                      /* gain 1..17, then the distortion type */
        int32_t g = x * (int32_t)(8u + p[FXP_DRIVE]) / 8;
        int32_t a = g < 0 ? -g : g;
        switch (q[FXQ_DIST]) {
        default: x = g * 1024 / (1024 + a); break;                               /* soft: x / (1 + |x|) */
        case 1: x = g > 1024 ? 1024 : g < -1024 ? -1024 : g; break;              /* hard clip */
        case 2: { int32_t u = (g + 1024) & 4095; x = (u < 2048 ? u : 4096 - u) - 1024; break; }   /* wavefolder */
        case 3: {                                                                 /* fuzz: soft up, hard down, DC removed */
            int32_t y = g > 0 ? g * 1024 / (1024 + g) : (g < -384 ? -384 : g);
            s->dc_y += ((y - s->dc_x) << 8) - (s->dc_y >> 8);   /* one-pole high-pass (~27 Hz), state x 256 */
            s->dc_x = y; x = (s->dc_y + 128) >> 8; break;
        }
        case 4:                                                                   /* sine fold: sin(g pi / 2048), round folds */
            x = lsdj_fx_sin((uint32_t)g << 20) >> 5; break;
        case 5: {                            /* rect: to 64 clean -> half-wave -> full-wave (the octave up), then drive 1x .. 8x */
            int32_t d = p[FXP_DRIVE], u = d > 64 ? x * (63 + (d - 64) * 7) / 63 : x, au = u < 0 ? -u : u;
            int32_t y = u + (((au - u) * (d > 64 ? 64 : d)) >> 6);           /* 32: the half-wave, 64: the full */
            au = y < 0 ? -y : y; y = y * 1024 / (1024 + au);                   /* the soft clip */
            s->dc_y += ((y - s->dc_x) << 8) - (s->dc_y >> 8);                   /* the rectified wave's mean out (~27 Hz) */
            s->dc_x = y; x = (s->dc_y + 128) >> 8; break;
        }
        case 6:                              /* ring: times a sine of 26 Hz .. 2.6 kHz (DRIVE, lsdj_fx_ring_step) */
            x = x * lsdj_fx_sin(s->d_ph) >> 15; s->d_ph += s->d_inc; break;
        case 7: {                            /* tape: the soft clip, then a low-pass (two poles, 12 dB an octave) from ~6.4 kHz
                                                (DRIVE 1) to ~1.7 kHz (127) that wanders +-25 % to a new place every ~2 s */
            int32_t y = g * 1024 / (1024 + a);
            uint32_t ph = s->d_ph + 48696u;    /* wraps every 2 s */
            if (ph < s->d_ph) { s->rnd = s->rnd * 1664525u + 1013904223u; s->d_t = 24576 + (int32_t)(s->rnd >> 18); }   /* 0.75 .. 1.25 */
            s->d_ph = ph;
            s->d_k += (s->d_t - s->d_k) >> 12;                                  /* ~90 ms glide */
            int32_t k = (19800 - (int32_t)p[FXP_DRIVE] * 100) * (s->d_k >> 3) >> 12;   /* Q15 */
            s->d_lp += ((y << 4) - s->d_lp) * k / 32768;                       /* (toward 0: it settles on 0) */
            s->d_lp2 += (s->d_lp - s->d_lp2) * k / 32768;
            x = s->d_lp2 / 16; break;
        }
        }
    }
    if (p[FXP_TYPE] >= 6u) {                 /* PHASER, VOWEL: CUTOFF (with the LFO to it) is where they are */
        int32_t ci = p[FXP_CUTOFF] & 127u;
        if (depth && dest == 0u) ci += lfo * depth / 65536;
        else if (p[FXP_TYPE] == 6u) {        /* the phaser without the LFO on its cutoff sweeps itself: 0.5 Hz, +-24 steps */
            s->sw_ph += 48696u;
            int32_t t = (int32_t)(s->sw_ph >> 15) - 65536;
            ci += ((t < 0 ? -t : t) - 32768) * 24 / 32768;
        }
        ci = ci < 0 ? 0 : ci > 127 ? 127 : ci;
        if (p[FXP_TYPE] == 6u) {             /* four first-order all-passes (x 16), RESO the feedback 0 .. 0.7 */
            int32_t c = lsdj_fx_ph_a[ci], u = (x << 4) + s->zfb * ((int32_t)p[FXP_RESO] * 181) / 32768;
            u = u > 65535 ? 65535 : u < -65535 ? -65535 : u;
            for (uint32_t st = 0; st < 4u; st++) {   /* y = c (u - y1) + u1; |c (u - y1)| < 2^31 */
                int32_t y = s->z[st] + c * (u - s->z[4 + st]) / 16384;   /* (toward 0: no ringing on in silence) */
                y = y > 65535 ? 65535 : y < -65535 ? -65535 : y;
                s->z[st] = u; s->z[4 + st] = y; u = y;
            }
            s->zfb = u > 32767 ? 32767 : u < -32767 ? -32767 : u;
            x = ((x << 4) + u) / 32;         /* (the dry + the swept) / 2: its notches */
        } else {                             /* three formant band-passes (trapezoidal SVF, x 32) over the dry at half */
            int32_t sum = 0, xs = x << 5;
            xs = xs > 37500 ? 37500 : xs < -37500 ? -37500 : xs;
            const int16_t *t = lsdj_fx_vowel[ci];
            for (uint32_t k = 0; k < 3u; k++) {
                int32_t a1 = t[3 * k], a2 = t[3 * k + 1], a3 = t[3 * k + 2];
                int32_t *z = s->z + 2 * k, v3 = xs - z[1];
                int32_t v1 = (a1 * z[0] + a2 * v3) >> 13, v2 = z[1] + ((a2 * z[0] + a3 * v3) >> 13);
                z[0] = 2 * v1 - z[0]; z[0] = z[0] > 150000 ? 150000 : z[0] < -150000 ? -150000 : z[0];
                z[1] = 2 * v2 - z[1]; z[1] = z[1] > 150000 ? 150000 : z[1] < -150000 ? -150000 : z[1];
                sum += v1;
            }
            x = (xs / 2 + ((sum >> 2) * 9175 >> 13)) / 32;
        }
    } else if (p[FXP_TYPE]) {                /* Chamberlin state-variable filter */
        /* Coefficients in Q14, states with 8 fractional bits (x 256): at low
           cutoffs a coarser state gets stuck at a leftover value once the
           sound stops. */
        int32_t ci = p[FXP_CUTOFF] & 127u;
        if (depth && dest == 0u) {           /* LFO to the cutoff: +-63 steps at full depth */
            ci += lfo * depth / 65536;
            ci = ci < 0 ? 0 : ci > 127 ? 127 : ci;
        }
        int32_t fc = lsdj_fx_cutoff[ci];
        if (fc > lsdj_fx_fmax[p[FXP_RESO] & 127u]) fc = lsdj_fx_fmax[p[FXP_RESO] & 127u];   /* stay stable */
        int32_t qd = 16384 * 2 - (int32_t)p[FXP_RESO] * (16384 * 19 / 10) / 127;   /* damping 2 .. 0.1 */
        s->low = lsdj_fx_clampst(s->low + lsdj_fx_mq14(fc, s->band));
        int32_t high = lsdj_fx_clampst((x << 8) - s->low - lsdj_fx_mq14(qd, s->band));
        s->band = lsdj_fx_clampst(s->band + lsdj_fx_mq14(fc, high));
        if (q[FXQ_WARM]) {                   /* warm: the resonance saturates above a knee K (8192 .. 2100), towards 2K */
            int32_t bs = s->band >> 8, k = 8192 - (int32_t)q[FXQ_WARM] * 48, a = bs < 0 ? -bs : bs;
            if (a > k) {
                a = k + (a - k) * k / a;
                s->band = ((bs < 0 ? -a : a) << 8) | (s->band & 255);
            }
        }
        int32_t y;
        switch (p[FXP_TYPE]) {
        case 1: y = s->low; break;
        case 2: y = high; break;
        case 4: y = s->low + high; break;   /* notch */
        case 5: {                            /* 24 dB: a second, gentle stage (damping 1.4) on the low-pass */
            int32_t fc2 = fc > 16538 ? 16538 : fc;
            s->low2 = lsdj_fx_clampst(s->low2 + lsdj_fx_mq14(fc2, s->band2));
            int32_t h2 = lsdj_fx_clampst(s->low - s->low2 - lsdj_fx_mq14(22938, s->band2));
            s->band2 = lsdj_fx_clampst(s->band2 + lsdj_fx_mq14(fc2, h2));
            y = s->low2; break;
        }
        default: y = s->band; break;
        }
        x = (lsdj_fx_clampst(y) + 128) >> 8;
    }
    if (p[FXP_CRUSH]) {                      /* step 1 .. 512 on a +-1024 signal */
        int32_t step = 1 << ((uint32_t)p[FXP_CRUSH] * 9u / 127u);
        x = x >= 0 ? x / step * step : -((-x) / step * step);
    }
    if (p[FXP_DECIM]) {                      /* hold every sample for 1 .. 32 samples */
        if (s->hold_n == 0) { s->hold = x; s->hold_n = 1u + (uint32_t)p[FXP_DECIM] * 31u / 127u; }
        s->hold_n--; x = s->hold;
    }
    if (depth && dest == 1u)                 /* LFO to the volume: tremolo, down to silence at full depth */
        x = x * (32768 - ((lfo + 32768) >> 1) * depth / 127) >> 15;
    if (depth && dest == 2u) {               /* LFO to the pan: one side dips, then the other */
        s->pan_l = 32768 - (lfo > 0 ? lfo : 0) * depth / 127;
        s->pan_r = 32768 - (lfo < 0 ? -lfo : 0) * depth / 127;
    }
    return x;
}

/* Echo buffer read d (Q8 samples) back from the write position, interpolated. */
#define LSDJ_FX_EMASK (LSDJ_FX_ECHO_LEN - 1u)
static int32_t lsdj_fx_echo_read(const lsdj_fx_t *f, uint32_t d) {
    uint32_t i = d >> 8, fr = d & 255u;
    int32_t a = lsdj_fx_unulaw(f->echo[(f->echo_pos - i) & LSDJ_FX_EMASK]);
    if (!fr) return a;
    int32_t b = lsdj_fx_unulaw(f->echo[(f->echo_pos - i - 1u) & LSDJ_FX_EMASK]);
    return a + (b - a) * (int32_t)fr / 256;
}
/* One 22.05 kHz echo step: in = the sends. Mono: one tap at the echo time.
   Ping-pong: taps at 1x (left) and 2x (right), feedback from 2x, so repeats
   alternate left, right. Freeze copies the loop back in instead of new sound. */
static void lsdj_fx_echo_tick(lsdj_fx_t *f, int32_t in) {
    uint32_t len = f->echo_len, ping = f->p.m[FXM_MODE];
    uint32_t d = len << 8;
    if (f->p.m[FXM_WOBBLE] && !f->freeze) {  /* 0.6 Hz triangle on the read position */
        f->lfo += 116871u;                   /* 2^32 * 0.6 / 22050 */
        int32_t tri = (int32_t)(f->lfo >> 16) - 32768; tri = (tri < 0 ? -tri : tri) * 2 - 32768;   /* -32768..32766 */
        int32_t depth = (int32_t)f->p.m[FXM_WOBBLE] * (LSDJ_FX_WOBBLE_MAX * 256) / 127;
        d += (uint32_t)(depth + tri * (depth >> 4) / 2048);   /* len .. len + 2 depth */
    }
    int32_t t1 = lsdj_fx_echo_read(f, d), t2 = ping ? lsdj_fx_echo_read(f, d * 2u) : t1;
    f->echo_l = t1; f->echo_r = t2;
    if (f->freeze) {
        uint32_t loop = ping ? len * 2u : len;
        f->echo[f->echo_pos] = f->echo[(f->echo_pos - loop) & LSDJ_FX_EMASK];
    } else {
        int32_t w = in + t2 * (int32_t)f->p.m[FXM_FEEDBACK] * 115 / (127 * 128);   /* feedback <= 0.9 */
        w = lsdj_fx_clamp16(w);
        if (f->tone_k) {                     /* one-pole, state x 16 */
            int32_t dlt = (w << 4) - f->tone_st;
            f->tone_st += lsdj_fx_mq14(f->tone_k, dlt);
            int32_t lp = f->tone_st >> 4;
            w = f->p.m[FXM_TONE] < LSDJ_FX_TONE_FLAT ? lp : w - lp;
        }
        f->echo[f->echo_pos] = lsdj_fx_ulaw(w);
    }
    f->echo_pos = (f->echo_pos + 1u) & LSDJ_FX_EMASK;
}

/* Reverb arithmetic rounds toward zero (C division), never toward minus infinity: a shift would leave a
   small signal going round the lines for ever instead of fading out. */
/* Reverb: a Schroeder allpass (gain 0.5) on line b of length n. */
static int32_t lsdj_fx_rv_ap(int16_t *b, uint32_t n, uint32_t *pos, int32_t x) {
    int32_t d = b[*pos], w = lsdj_fx_clamp16(x - d / 2);
    b[*pos] = (int16_t)w;
    if (++*pos == n) *pos = 0;
    return d + w / 2;
}
/* One 22.05 kHz reverb step: in = what goes in (mono). */
static void lsdj_fx_rv_tick(lsdj_fx_t *f, int32_t in) {
    int16_t *b = f->rv;
    int32_t u = lsdj_fx_rv_ap(b, LSDJ_FX_RV_AP1, &f->rv_pos[4], in);
    u = lsdj_fx_rv_ap(b + LSDJ_FX_RV_AP1, LSDJ_FX_RV_AP2, &f->rv_pos[5], u);
    int16_t *ln[4]; int32_t a[4];
    ln[0] = b + LSDJ_FX_RV_AP1 + LSDJ_FX_RV_AP2;
    for (uint32_t i = 1; i < 4; i++) ln[i] = ln[i - 1] + lsdj_fx_rv_line[i - 1];
    for (uint32_t i = 0; i < 4; i++) a[i] = ln[i][f->rv_pos[i]];
    /* Hadamard / 2 (no gain), held to 16 bits so the Q14 products below stay inside 32 bits */
    int32_t h[4] = {lsdj_fx_clamp16((a[0] + a[1] + a[2] + a[3]) / 2), lsdj_fx_clamp16((a[0] - a[1] + a[2] - a[3]) / 2),
                    lsdj_fx_clamp16((a[0] + a[1] - a[2] - a[3]) / 2), lsdj_fx_clamp16((a[0] - a[1] - a[2] + a[3]) / 2)};
    u /= 2;
    for (uint32_t i = 0; i < 4; i++) {
        f->rv_lp[i] += (h[i] - f->rv_lp[i]) * f->rv_k / 16384;
        int32_t w = (i & 1u ? -u : u) + f->rv_lp[i] * f->rv_g / 16384;
        ln[i][f->rv_pos[i]] = (int16_t)lsdj_fx_clamp16(w);
        if (++f->rv_pos[i] == lsdj_fx_rv_line[i]) f->rv_pos[i] = 0;
    }
    f->rv_l = (a[0] + a[2]) * f->rv_o / 16384; f->rv_r = (a[1] + a[3]) * f->rv_o / 16384;
}

/* The stereo mix of one split sample (4 channels + panning word, see
   minigb_apu_split) with the effects; before the volume. */
static void lsdj_fx_mix(lsdj_fx_t *f, const int16_t *smp, int32_t *lo, int32_t *ro) {
    uint32_t pan = (uint16_t)smp[4], vl = (pan >> 8) & 7u, vr = (pan >> 11) & 7u;
    int16_t dry_l = 0, dry_r = 0;
    if (!f->active || f->p.bypass) {          /* exactly MiniGB: int16 sums in channel order */
        int16_t L = 0, R = 0;
        for (uint32_t c = 0; c < 4; c++) {
            if ((f->mute >> c) & 1u) continue;
            L = (int16_t)(L + smp[c] * (int32_t)((pan >> (4 + c)) & 1u) * (int32_t)vl);
            R = (int16_t)(R + smp[c] * (int32_t)((pan >> c) & 1u) * (int32_t)vr);
        }
        if (!f->active) { *lo = L; *ro = R; return; }
        dry_l = L; dry_r = R;
    }
    int32_t L = 0, R = 0, send = 0, rsend = 0;
    for (uint32_t c = 0; c < 4; c++) {
        if ((f->mute >> c) & 1u) continue;
        int dry = (f->p.fx_off >> c) & 1u;
        int32_t y = dry ? smp[c] : lsdj_fx_chan(&f->c[c], f->p.ch[c], f->p.q[c], smp[c]);
        int32_t l = y * (int32_t)((pan >> (4 + c)) & 1u) * (int32_t)vl;
        int32_t r = y * (int32_t)((pan >> c) & 1u) * (int32_t)vr;
        if (!dry && f->c[c].pan_l != 32768) l = l * f->c[c].pan_l >> 15;
        if (!dry && f->c[c].pan_r != 32768) r = r * f->c[c].pan_r >> 15;
        L += l; R += r;
        if (!dry && f->p.ch[c][FXP_SEND]) send += (l + r) / 2 * (int32_t)f->p.ch[c][FXP_SEND] / 127;
        if (!dry && f->p.rs[c]) rsend += (l + r) / 2 * (int32_t)f->p.rs[c] / 127;
    }
    if (f->p.m[FXM_MIX] && f->echo) {        /* master echo at half rate (22.05 kHz) */
        f->echo_in += send;
        if (++f->echo_half == 2u) {
            f->echo_half = 0;
            lsdj_fx_echo_tick(f, f->echo_in / 2);
            f->echo_in = 0;
        }
        L += f->echo_l * (int32_t)f->p.m[FXM_MIX] / 127;
        R += f->echo_r * (int32_t)f->p.m[FXM_MIX] / 127;
    }
    if (f->rv_on) {                          /* master reverb at half rate, after the echo */
        f->rv_in += rsend;
        if (++f->rv_half == 2u) {
            f->rv_half = 0;
            lsdj_fx_rv_tick(f, lsdj_fx_clamp16(f->rv_in / 2));
            f->rv_in = 0;
        }
        L += f->rv_l * (int32_t)f->p.r[FXR_MIX] / 127;
        R += f->rv_r * (int32_t)f->p.r[FXR_MIX] / 127;
    }
    if (f->p.comp) {                         /* master compressor: peak envelope (attack ~0.4 ms, release ~90 ms),
                                                4:1 above a threshold the amount lowers (0 .. -16 dB), make-up gain */
        L = lsdj_fx_clamp16(L); R = lsdj_fx_clamp16(R);
        int32_t a = L < 0 ? -L : L, b = R < 0 ? -R : R;
        if (b > a) a = b;
        f->comp_env += a > f->comp_env ? (a - f->comp_env) >> 4 : (a - f->comp_env) >> 12;
        int32_t th = 32767 - (int32_t)f->p.comp * 215, g = 32768;
        if (f->comp_env > th) g = (int32_t)(((uint32_t)(th + ((f->comp_env - th) >> 2)) << 15) / (uint32_t)f->comp_env);
        g = g * (32768 + (int32_t)f->p.comp * 96) >> 15;
        L = L * g >> 15; R = R * g >> 15;
    }
    /* Keep DSP state advancing while bypassed, so echo/LFO do not resume stale. */
    *lo = f->p.bypass ? dry_l : lsdj_fx_clamp16(L);
    *ro = f->p.bypass ? dry_r : lsdj_fx_clamp16(R);
}
