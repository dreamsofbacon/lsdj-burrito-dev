/* SPDX-License-Identifier: GPL-3.0-only */
/* MIDI clock sync for LSDj (PROJECT > SYNC = MIDI), as an Arduinoboy does it:
   every MIDI clock tick (0xF8, 24 per beat) goes into the link port as one 0x00
   byte, and LSDj moves one step per 6 ticks. LSDj only follows the clock once
   START has armed it, so the transport messages press START for the player:
     Start (0xFA)    restart: disarm if armed, then arm (plays from the cursor)
     Continue (0xFB) arm if not armed (carries on where it paused)
     Stop (0xFC)     disarm
   Ticks that arrive while LSDj is being armed wait in the link queue (LSDj
   only reads it once armed), so it starts in step with the clock.
   0.9.98-dev.2: a clock that goes quiet while running (no tick or transport
   for LSDJ_MS_QUIET_MS: the web page closed, USB pulled, a sender gone without
   a Stop) counts as Stop, so LSDj never waits for a clock that will not come.
   0.9.98-dev.25, LIVE mode: there START on a playing chain does not stop it (it
   queues it again; SELECT+START stops it only at the phrase's end), so a Stop,
   or a Start's restart, pressed START up to four times while LSDj played on:
   it carried on out of step, or stopped at the phrase's end and started again a
   phrase later (Colin's DJ deck in LIVE mode, 2026-11-25: "it starts with the
   LSDj cursor blinking, then stops and restarts the chain on the next bar"). A
   press that stops LSDj (it is armed) in LIVE mode is now made in song mode,
   where START stops at once: `song` asks the caller to hold LSDj's SEQ at song
   for that press and its gap, then put LIVE back (board.c). The caller sets
   `live` (LIVE mode, counting a song hold of its own) before each frame.
   Pure logic: tests/lsdj_midisync.c. */
#pragma once
#include <stdint.h>

#define LSDJ_MS_HOLD 2u        /* frames START is held */
#define LSDJ_MS_GAP 4u         /* frames released before LSDj's state is trusted again */
#define LSDJ_MS_TRIES 4u       /* presses per request, if LSDj does not respond */
#define LSDJ_MS_QUIET_MS 3000u /* running with no clock this long: a Stop (a page in a background tab
                                  sends its clock in bursts about a second apart; never cut short) */

enum { LSDJ_MS_NONE, LSDJ_MS_ARM, LSDJ_MS_DISARM, LSDJ_MS_RESTART };
/* What a transport message did, for the on-screen message. */
enum { LSDJ_MS_SAID_NOTHING, LSDJ_MS_SAID_START, LSDJ_MS_SAID_CONTINUE, LSDJ_MS_SAID_STOP, LSDJ_MS_SAID_SET_SYNC };

typedef struct {
    uint8_t want;              /* LSDJ_MS_* */
    uint8_t hold, gap, tries;
    uint32_t ticks;            /* clock ticks passed to LSDj */
    uint8_t running;           /* between Start/Continue and Stop */
    uint32_t heard;            /* ms: the last tick, Start or Continue (lsdj_ms_heard) */
    uint8_t live;              /* in: LSDj is in LIVE mode (dev.25) */
    uint8_t song;              /* out: hold LSDj in song mode now (a stopping press in LIVE mode, dev.25) */
} lsdj_ms_t;

static void lsdj_ms_init(lsdj_ms_t *s) { uint8_t *b = (uint8_t *)s; for (uint32_t i = 0; i < sizeof *s; i++) b[i] = 0; }

/* One MIDI realtime status byte. midi_mode: LSDj's SYNC is MIDI; armed: LSDj is
   armed or playing. A tick is passed on (send(0)) between Start/Continue and
   Stop, or while LSDj is armed (started with PLAY). Returns LSDJ_MS_SAID_*. */
static int lsdj_ms_byte(lsdj_ms_t *s, uint8_t st, int midi_mode, int armed, void (*send)(uint8_t)) {
    if (!midi_mode) return st == 0xFAu ? LSDJ_MS_SAID_SET_SYNC : LSDJ_MS_SAID_NOTHING;
    switch (st) {
    case 0xF8:                         /* stale ticks would make LSDj jump ahead when armed */
        if (s->running || armed) { send(0x00); s->ticks++; }
        return LSDJ_MS_SAID_NOTHING;
    case 0xFA: s->want = LSDJ_MS_RESTART; s->tries = 0; s->running = 1; return LSDJ_MS_SAID_START;
    case 0xFB: s->want = LSDJ_MS_ARM; s->tries = 0; s->running = 1; return LSDJ_MS_SAID_CONTINUE;
    case 0xFC: s->want = LSDJ_MS_DISARM; s->tries = 0; s->running = 0; return LSDJ_MS_SAID_STOP;
    }
    return LSDJ_MS_SAID_NOTHING;
}

/* A tick, Start or Continue arrived at now_ms (the caller's clock). */
static void lsdj_ms_heard(lsdj_ms_t *s, uint8_t st, uint32_t now_ms) {
    if (st == 0xF8u || st == 0xFAu || st == 0xFBu) s->heard = now_ms;
}
/* Running, but nothing heard for LSDJ_MS_QUIET_MS: stop as a Stop would (LSDj
   disarmed). Returns 1 when it did. */
static int lsdj_ms_quiet(lsdj_ms_t *s, uint32_t now_ms) {
    if (!s->running || now_ms - s->heard < LSDJ_MS_QUIET_MS) return 0;
    s->want = LSDJ_MS_DISARM; s->tries = 0; s->running = 0;
    return 1;
}

/* Once per emulated frame: armed = LSDj is armed or playing. Returns 1 while
   START should be held down. */
static int lsdj_ms_frame(lsdj_ms_t *s, int armed) {
    if (s->hold) { if (--s->hold == 0) s->gap = LSDJ_MS_GAP; return 1; }
    if (s->gap) { s->gap--; return 0; }
    s->song = 0;                       /* (the press made in song mode, and its gap, are over) */
    int press = 0;
    switch (s->want) {
    case LSDJ_MS_RESTART: if (armed) press = 1; else { s->want = LSDJ_MS_ARM; s->tries = 0; return lsdj_ms_frame(s, armed); } break;
    case LSDJ_MS_ARM: if (!armed) press = 1; else s->want = LSDJ_MS_NONE; break;
    case LSDJ_MS_DISARM: if (armed) press = 1; else s->want = LSDJ_MS_NONE; break;
    }
    if (!press) return 0;
    if (s->tries >= LSDJ_MS_TRIES) { s->want = LSDJ_MS_NONE; return 0; }   /* LSDj not responding: give up */
    s->tries++;
    s->song = (uint8_t)(s->live && armed);   /* LIVE mode: a press that stops LSDj, made in song mode */
    s->hold = LSDJ_MS_HOLD - 1u;
    if (!s->hold) s->gap = LSDJ_MS_GAP;
    return 1;
}
