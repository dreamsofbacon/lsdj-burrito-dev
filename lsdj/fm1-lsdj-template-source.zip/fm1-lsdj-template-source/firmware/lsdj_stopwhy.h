/* SPDX-License-Identifier: GPL-3.0-only */
/* 0.9.98-dev.28: why LSDj last stopped, for the DJ layout's Log (LIVE). Colin's DJ test (2026-11-27): deck A's FM-1
   stopped the moment deck B's FM-1 began an install, and nothing said why (a quiet clock, a MIDI Stop, the FM-1's own
   buttons, or LSDj by itself). Each stopping path marks its cause as it acts; once a frame the playing state is
   checked, and the moment it goes from playing to stopped the last cause marked within LSDJ_WHY_WINDOW_MS is kept
   (none: LSDj itself, a song's end, LSDj's own START, or a cause this doesn't see), with what the MIDI clock was doing:
   how long since the last tick at the stop, and the longest gap between ticks while it played.
   Pure logic: tests/lsdj_stopwhy.c. */
#pragma once
#include <stdint.h>

#define LSDJ_WHY_WINDOW_MS 1500u   /* a cause this recent explains a stop (a press acts within a few frames: up to
                                      4 tries of 2 frames held and 4 released, about 0.4 s) */
enum { LSDJ_WHY_NONE = 0,          /* not stopped since power-on */
       LSDJ_WHY_QUIET = 1,         /* the MIDI clock went quiet while running (lsdj_ms_quiet, 3 s) */
       LSDJ_WHY_MIDI_STOP = 2,     /* a MIDI Stop (0xFC) */
       LSDJ_WHY_BUTTON = 3,        /* a button on the FM-1 pressed */
       LSDJ_WHY_SELF = 4 };        /* none of those: LSDj itself */

typedef struct {
    uint8_t cause; uint32_t cause_ms;   /* the last cause marked, and when */
    uint8_t was;                        /* playing last frame */
    uint32_t tick_ms; uint8_t ticked;   /* the last clock tick heard */
    uint32_t gap_run;                   /* the longest gap between ticks since it started playing */
    /* the last stop: */
    uint8_t why; uint32_t at_ms, gap_at, gap_max;
} lsdj_why_t;

static void lsdj_why_init(lsdj_why_t *w) { uint8_t *b = (uint8_t *)w; for (uint32_t i = 0; i < sizeof *w; i++) b[i] = 0; }
static void lsdj_why_cause(lsdj_why_t *w, uint8_t cause, uint32_t now_ms) { w->cause = cause; w->cause_ms = now_ms; }
/* a MIDI clock tick (0xF8) heard */
static void lsdj_why_tick(lsdj_why_t *w, uint32_t now_ms) {
    if (w->ticked && w->was && now_ms - w->tick_ms > w->gap_run) w->gap_run = now_ms - w->tick_ms;
    w->tick_ms = now_ms; w->ticked = 1;
}
/* once a frame: playing = any channel plays (LIVE's playing bits) */
static void lsdj_why_frame(lsdj_why_t *w, int playing, uint32_t now_ms) {
    if (playing && !w->was) w->gap_run = 0;
    if (!playing && w->was) {
        w->why = w->cause && now_ms - w->cause_ms <= LSDJ_WHY_WINDOW_MS ? w->cause : LSDJ_WHY_SELF;
        w->at_ms = now_ms; w->gap_at = w->ticked ? now_ms - w->tick_ms : 0xFFFFFFFFu; w->gap_max = w->gap_run;
        w->cause = 0;
    }
    w->was = (uint8_t)!!playing;
}
static uint16_t lsdj_why_ms16(uint32_t ms) { return (uint16_t)(ms < 65535u ? ms : 65535u); }
