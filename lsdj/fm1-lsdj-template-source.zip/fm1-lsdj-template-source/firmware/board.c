/* SPDX-License-Identifier: GPL-3.0-only
 * FM-1 and SMK37 adapters using MusicCoach/Felucca HAL. Compile-only candidate.
 * Audio IRQ drains PCM; CPU0 emulates GB/APU; CPU1 scales immutable display frames. */
#include <stdint.h>
#include "gb_port.h"
#include "fm1_time.h"
#include "fm1_sys.h"
#include "fm1_irq.h"
#include "smk37_bootguard.h"
#include "cartridge.h"
static volatile uint8_t hang_on,hang_test,restart_test;static volatile uint32_t hang_op,loop_passes;   /* 0.9.98-dev.20, the hang recorder (hang_check) */
#ifdef CART_SLOT_CAPACITY
#include "lsdj_slot.h"
static lsdj_slot_t cart_slot;
static uint8_t cart_slot_valid;
#endif
#include "boot_brand.h"
extern void gb_isr_audio(void),gb_isr_scan(void);
static int32_t dma[256*4] __attribute__((aligned(4)));
static int16_t samples[256*2];
static uint16_t screen[240*216] __attribute__((section(".pool"),aligned(4)));
static volatile uint32_t scan_count,audio_count,key_lo,key_hi,audio_underruns;
static uint32_t display_count;
static uint32_t input_buttons,input_seen;
#include "lsdj_cpu.h"
static lsdj_cpu_t cpu;   /* CPU meter (FM-1: GLO shows it) */
static volatile uint32_t splash_active,ding_position;
static void read_samples(void){
    if(!splash_active){gp_audio_read(samples,256);return;}
    uint32_t p=ding_position;
    for(unsigned i=0;i<256;i++){
        int16_t v=gd_ding(p);if(p<GD_DING_FRAMES)p++;
        samples[2*i]=samples[2*i+1]=v;
    }
    ding_position=p;
}
#include "multicore_video.h"
volatile smk37_bootguard_t gb_bootguard __attribute__((section(".noinit")));

#if GB_SMK37
/* The scanner also includes the LED encoder: configure it before either HAL. */
#define SMK37_LIGHT_MAX_LEVEL 255u /* Readable game pads; diagnostics keep their dim default. */
#include "smk37_boot.h"
#include "smk37_time.h"
#include "smk37_audio.h"
#include "smk37_lcd_hw.h"
#include "smk37_panel.h"
#include "smk37_scan_config.h"
#include "smk37_scanner.h"
#include "smk37_contacts.h"
#include "smk37_keyscan.h"
#include "smk37_controls.h"
#include "smk37_adc.h"
#define SMK37_LIGHT_RESET() fm1_delay_us(350)
#define SMK37_LIGHT_DMA_BARRIER() __asm__ volatile("csync" ::: "memory")
#include "smk37_lights_hw.h"
_Static_assert(SMK37_LIGHT_COMPILED_MAX_LEVEL==255u,"SMK pad encoder must use application brightness");
#include "smk37_game_controls.h"
#include "smk37_game_pads.h"
#include "smk37_volume.h"
#include "smk37_brightness.h"
static smk_brightness_t smk_brightness_fader;
static volatile uint32_t smk_brightness=150;
static volatile uint32_t smk_volume_target=64;
static uint32_t smk_volume_current=64;
static smk37_keyscan_t keys[37];
static smk37_adc_t pad_adc;
static smk37_controls_t panel_controls;
static gb_smk37_pads_t game_pads;
static volatile uint32_t smk_buttons;
static uint8_t pad_lights[SMK37_LIGHT_BYTES] __attribute__((aligned(4)));
static int lcd_command(uint8_t c){return smk37_lcd_command(c,4000000);}
static int lcd_data(const void*p,uint32_t n){return smk37_lcd_data(p,n,4000000);}
static const smk37_panel_io_t panel={lcd_command,lcd_data,fm1_delay_ms};
static const smk37_audio_hooks_t audio_hooks={fm1_delay_ms,fm1_irq_attach};
void gb_scan_irq(void) {
    if(!(SMK37_SCAN_CON&0x8000u))return;
    unsigned index=pad_adc.scan.index;
    int result=smk37_adc_spi_done(&pad_adc);
    if(result>0)smk_volume_target=smk_volume_sample(smk_volume_target,index,pad_adc.scan.raw[index]);
    if(result>0)smk_brightness=smk_brightness_sample(&smk_brightness_fader,smk_brightness,index,pad_adc.scan.raw[index]);
    if(result>0)for(unsigned p=0;p<16;p++)if(index==smk37_pad_input[p])
        gb_smk37_pad_sample(&game_pads,p,pad_adc.scan.raw[index]);
    if(result<0)game_pads.held=game_pads.pressed=0;
    smk37_scan_set_analog(smk37_analog_mask(&pad_adc.scan));
    if(!smk37_scan_tick())return;
    (void)smk37_controls_tick(&panel_controls,smk37_scan_frame);
    smk_buttons=panel_controls.buttons;
    scan_count++;
    for(unsigned k=0;k<37;k++) {
        unsigned raw=smk37_contact_closed(smk37_scan_frame,smk37_key_contacts[k][0])|
            smk37_contact_closed(smk37_scan_frame,smk37_key_contacts[k][1])<<1;
        uint32_t duration;
        if(!smk37_keyscan_tick(&keys[k],raw,&duration))continue;
        if(k<32) {if(duration)key_lo|=1u<<k;else key_lo&=~(1u<<k);}
        else {if(duration)key_hi|=1u<<(k-32);else key_hi&=~(1u<<(k-32));}
    }
}
void gb_audio_irq(void) {
    uint8_t p=smk37_audio_pending();smk37_audio_ack_aux(p);
    if(!(p&SMK37_AUDIO_HALF))return;
    unsigned h=smk37_audio_free_half();read_samples();
    uint32_t target=smk_volume_target;
    smk_volume_render(dma+h*512,samples,smk_volume_current,target);smk_volume_current=target;
    audio_count++;smk37_audio_ack_half();
}
static int display_init(void){smk37_lcd_hw_init(4);return smk37_panel_init(&panel);}
static void display_frame(void){
    if(smk37_panel_window(&panel,0,12,240,216))lcd_data(screen,sizeof screen);
}
static int display_ready(void){return 1;}
static void display_stop(void){}
/* Main-loop only: leave the shared SPI peripheral to any active LCD DMA. */
static void smk_pad_lights(uint32_t held){
    static uint32_t previous=UINT32_MAX,last;
    uint32_t lit=gp_smk37_pad_lights()&~held,level=smk_brightness;
    uint32_t state=lit|(level<<16);
    if(state==previous||!display_ready())return;
    uint32_t now=fm1_ticks();
    /* Coalesce fader changes to 50 Hz; pad press/release feedback stays immediate. */
    if(lit==(previous&0xffffu)&&(uint32_t)(now-last)<480000u)return;
    uint32_t rgb[16]={0};
    for(unsigned p=0;p<16;p++)if(lit&(1u<<p))
        rgb[p]=p>=14?(level<<16)|level:((level*2/3)<<8)|level;
    smk37_light_encode_rgb(pad_lights,rgb);
    if(smk37_lights_send(pad_lights,4000000)){previous=state;last=now;}
}
static void input_init(void){
    smk37_adc_init(&pad_adc);
    SMK37_LIGHT_REG(0x50080u)&=~(1u<<10);
    SMK37_LIGHT_REG(0x50088u)&=~(1u<<10);
    smk37_scan_set_analog(smk37_analog_mask(&pad_adc.scan));
    smk37_scan_indicator_bits=(1u<<16)|(1u<<18); /* PLAY green, REC red. */
    smk37_scan_init(fm1_irq_attach,gb_isr_scan);
    smk_pad_lights(0);
}
static uint32_t smk_input_frame(void){
    fm1_irq_off();
    uint32_t lo=key_lo,hi=key_hi,pads=gb_smk37_pads_take(&game_pads),buttons=smk_buttons;
    uint32_t held=game_pads.held;
    fm1_irq_on();
    smk_pad_lights(held);
    return gp_input_keys(lo,hi)|gp_smk37_pads(pads)|gp_smk37_panel(buttons);
}
static void audio_start(void){(void)smk37_audio_init(dma,512,gb_isr_audio,3,&audio_hooks);}
static void audio_stop(void){smk37_audio_stop();}
#include "smk37_recovery.h"
#else
#define BURRITO_UAC 1   /* USB audio out (0.9.98-dev.11): fm1_recovery.h turns Felucca's FELUCCA_UAC on with it */
static void uac_render_start(void);
static void uac_tap_s16(const int16_t *s,uint32_t n);
#include "lsdj_clock.h"
static lsdj_clk_t clk;   /* the audio clock, measured (CPU meter; 0.9.98-dev.12) */
#include "fm1_timer.h"
#include "fm1_input.h"
#include "fm1_audio.h"
#include "fm1_adc.h"
#include "master_volume.h"
#include "fm1_lcd_hw.h"
#include "../vendor/felucca/firmware/src/lcd.c"
static volatile uint32_t master_gain;
static volatile uint8_t page_level=127u;   /* 0.9.98: the web page's volume (VOLUME_SET), times the knob; not saved */
static volatile uint8_t usb_follow;   /* USB AUDIO: VOLUME (lsdj_feat.h): the USB sound at the volume too, not full */
static int32_t master_raw=-1;
static uint32_t master_audio_gain;
static uint32_t page_audio_gain=4096u;   /* USB AUDIO: FULL, the page's volume alone (gb_page_gain), ramped */
static void master_boot(void){
    fm1_adc_init();(void)fm1_adc_read(FM1_ADC_MASTER);
    for(unsigned i=0;i<3;i++){
        int32_t raw=fm1_adc_read(FM1_ADC_MASTER);
        if(raw>=0){master_raw=raw;master_gain=master_audio_gain=gb_master_gain((uint32_t)raw);return;}
    }
    /* ADC failure starts muted; a later successful conversion recovers. */
    master_gain=master_audio_gain=0;
}
/* The battery (FM1_ADC_BATT, PB1's divider), averaged slowly as Felucca does (a new reading
   counts 1/32, every 100 ms); 0 = no reading yet. Felucca's thresholds: battery_level. */
static int32_t batt_raw,batt_last=-2;   /* batt_last: the last reading (-1 timeout, -2 none yet), shown on FX+LIGHTS */
static unsigned battery_level(void);   /* bars and USB power: after the USB driver (below) */
static void master_poll(void){
    static uint32_t last;static uint8_t tenth;
    uint32_t now=fm1_ticks();if(now-last<240000u)return;last=now;
    int32_t raw=fm1_adc_read(FM1_ADC_MASTER);
    master_raw=raw;if(raw>=0)master_gain=gb_master_gain((uint32_t)raw);
    if(++tenth>=10u){tenth=0;int32_t b=fm1_adc_read(FM1_ADC_BATT);batt_last=b;if(b>0)batt_raw=batt_raw?batt_raw+(b-batt_raw)/32:b;}
}
static void recovery_tick(void);
static void hang_check(uint32_t pc);   /* 0.9.98-dev.20, the hang recorder (below fm1_fault) */
/* the interrupted PC, in an interrupt's C body (start.S's wrapper keeps reti as it was) */
static inline uint32_t isr_reti(void){uint32_t v;__asm__ volatile("%0 = reti":"=r"(v));return v;}
void gb_scan_irq(void){
    hang_check(isr_reti());
    uint32_t t0=fm1_ticks();
    fm1_timer5_ack();fm1_input_tick();key_lo=fm1_in.notes;scan_count++;recovery_tick();
    cpu.isr+=fm1_ticks()-t0;
}
/* Sound clock: when the audio interrupt last took a block, and the position. */
static volatile uint32_t aud_seq,aud_at_ticks,aud_at_pos;
void gb_audio_irq(void){
    hang_check(isr_reti());
    uint32_t t0=fm1_ticks();
    uint32_t p=fm1_audio_pending();fm1_audio_ack_aux(p);
    if(!(p&FM1_AUDIO_HALF))return;
    unsigned h=fm1_audio_free_half();if(!splash_active&&gp_audio_queued()<256)audio_underruns++;
#if BURRITO_UAC
    uac_render_start();   /* USB audio out: the ring's fill before this block (fm1_recovery.h) */
#endif
    read_samples();
    aud_seq++;aud_at_ticks=fm1_ticks();aud_at_pos=gp_audio_consumed();aud_seq++;   /* sound clock, for MIDI sync */
    int32_t start=(int32_t)master_audio_gain,target=(int32_t)(master_gain*page_level/127u);   /* ramped: no click */
    uint8_t follow=usb_follow;
    /* USB AUDIO: FULL: the USB sound at the page's volume only (the DJ crossfader), never the knob; nothing to do at full */
    int32_t pstart=(int32_t)page_audio_gain,ptarget=(int32_t)gb_page_gain(page_level);
    uint8_t paged=!follow&&(pstart<4096||ptarget<4096);
    for(unsigned i=0;i<256;i++){
        uint32_t gain=(uint32_t)(start+(target-start)*(int32_t)(i+1)/256);
        dma[h*512+i*2]=gb_master_sample(samples[i*2],gain);
        dma[h*512+i*2+1]=gb_master_sample(samples[i*2+1],gain);
        if(follow){samples[i*2]=gb_master_s16(samples[i*2],gain);samples[i*2+1]=gb_master_s16(samples[i*2+1],gain);}
        else if(paged){uint32_t pg=(uint32_t)(pstart+(ptarget-pstart)*(int32_t)(i+1)/256);
            samples[i*2]=gb_master_s16(samples[i*2],pg);samples[i*2+1]=gb_master_s16(samples[i*2+1],pg);}
    }
    master_audio_gain=(uint32_t)target;page_audio_gain=(uint32_t)ptarget;
#if BURRITO_UAC
    uac_tap_s16(samples,256);   /* full level, or at the volume with USB AUDIO: VOLUME */
#endif
    audio_count++;lsdj_clk_dac(&clk,aud_at_ticks,(uint64_t)audio_count*256u);fm1_audio_ack_half();
    cpu.isr+=fm1_ticks()-t0;
}
static int display_init(void){lcd_init();return 1;}
/* Transfer asynchronously so enlarging the image cannot block emulation for
   the duration of a full LCD DMA. Never overwrite a buffer still in flight. */
static int display_ready(void){
    if(lcd_busy&&!(FM1_LCD_SPI_CON&0x8000u))return 0;
    lcd_sync();return 1;
}
static void display_frame(void){lcd_blit(0,12,240,216,screen);}
#include "fm1_game_lights.h"
/* Note mode: piano keys -> LSDj keyboard (PROJECT > SYNC = KEYBD) through the
   software PS/2 link port in gb_port.c. Mapping as Arduinoboy / RetroPlug: MIDI note
   48 = LSDj keyboard C, two rows of note keys, LSDj's octave keys slide its octave
   to the note's; key presses only (LSDj's keyboard has no note-off). Notes below 48
   are ignored, so low keys never turn into LSDj's mute/cursor commands. */
static void lsdj_keybd_note(int note,int on);
static void keybd_sync_note(void);
#define LSDJ_KEYBD_NOTE(n,on) lsdj_keybd_note((n),(on))
#include "fm1_lsdj_input.h"
static const uint8_t kb_note_map[24]={0x1A,0x1B,0x22,0x23,0x21,0x2A,0x34,0x32,0x33,0x31,0x3B,0x3A,
                                      0x15,0x1E,0x1D,0x26,0x24,0x2D,0x2E,0x2C,0x36,0x35,0x3D,0x3C};
#define KB_OCT_DN 0x05u   /* F1 */
#define KB_OCT_UP 0x06u   /* F2 */
static int kb_octave=-1;  /* LSDj's keyboard octave as we last set it; -1 = not synced yet */
static uint8_t sync_midi;   /* LSDj's SYNC is MIDI: the link port carries clock, not keys */
static void lsdj_keybd_note(int note,int on){
    if(!on)return;
    keybd_sync_note();   /* LSDj SYNC OFF: KEYBD now (FM-1_995) */
    if(note<48||sync_midi)return;
    if(kb_octave<0){for(int i=0;i<5;i++)gp_keybd_send(KB_OCT_DN);kb_octave=0;}  /* clamp to 0, as Arduinoboy */
    int n=note-48,oct=n/12;
    while(kb_octave<oct){gp_keybd_send(KB_OCT_UP);kb_octave++;}
    while(kb_octave>oct){gp_keybd_send(KB_OCT_DN);kb_octave--;}
    gp_keybd_send(kb_note_map[n>=0x3C?(n%12)+12:n%12]);
}
static lsdj_input_t lsdj_in;
/* A key's LED at the soft level: the HAL's steady mid level plus the glow. */
static void led_key_soft(uint32_t id,int on){
    for(uint32_t p=0;p<FM1_NCOL;p++)
        for(uint32_t r=1;r<5u;r++)
            if(FM1_KEYMAP[r][p]==(int8_t)id){
                if(on){fm1_led_mid[p]|=(uint8_t)(1u<<r);fm1_led_dim[p]|=(uint8_t)(1u<<r);}
                else{fm1_led_mid[p]&=(uint8_t)~(1u<<r);fm1_led_dim[p]&=(uint8_t)~(1u<<r);}
            }
}
static uint32_t lights_held_prev=UINT32_MAX,lights_shown,soft_shown,lights_base;
static uint8_t lights_valid;   /* 0: the LEDs are unknown (boot, after the boot sweep): write every key */
static uint8_t led_anim;       /* the boot sweep owns the LEDs: write none */
static uint32_t piano_soft;   /* keys to show soft instead of lit (the D-pad on the beat: play_light) */
/* The web page's DJ layout on OP4 / OP5 (firmware/lsdj_djkeys.h): while attached, these keys' lights
   are the deck's whatever else would show (fm1_input_frame sets them each frame). */
#include "lsdj_djkeys.h"
static lsdj_dj_t djk;
static uint32_t dj_mask,dj_lit,dj_soft;
static void piano_set2(uint32_t lights,uint32_t soft){   /* bit k = key k */
    if(led_anim)return;
    lights=(lights&~dj_mask)|dj_lit;soft=(soft&~dj_mask)|dj_soft;
    if(lights_valid&&lights==lights_shown&&soft==soft_shown)return;
    if(!lights_valid){lights_shown=~lights;soft_shown=~soft;lights_valid=1;}
    for(unsigned k=0;k<27;k++){
        uint32_t b=1u<<k;
        if((lights^lights_shown)&b)fm1_led_key(14+k,(lights&b)!=0);
        if((soft^soft_shown)&b)led_key_soft(14+k,(soft&b)!=0);
    }
    lights_shown=lights;soft_shown=soft;
}
static void piano_set(uint32_t lights){   /* key lights as given (bit k = key k) */
    lights_held_prev=UINT32_MAX;
    piano_set2(lights,0);
}
static uint32_t page_light(void);   /* PAGE LIGHTS: a black key for the page (below) */
static void piano_lights(uint32_t held_actions){
    if(held_actions!=lights_held_prev){lights_base=gp_fm1_key_lights(held_actions);lights_held_prev=held_actions;}
    uint32_t page=page_light();
    piano_set2(lights_base&~piano_soft&~page,(lights_base&piano_soft)|page);
}
static void input_init(void){
    fm1_input_init();
    lsdj_input_init(&lsdj_in);
    piano_lights(0);
    fm1_led_key(12,1); /* PLAY / Start */
    fm1_led_key(13,1); /* REC / Select */
    fm1_timer5_start(gb_isr_scan,4);
}
static void audio_start(void){fm1_audio_init(dma,512,gb_isr_audio,3);}
static void audio_stop(void){fm1_audio_stop();}
#if !GB_SMK37
static void midi_in(uint32_t pkt,uint32_t at_ms,uint32_t src);   /* MIDI in (lsdj_midi.h), below */
#define FM1_MIDI_IN(p,at,src) midi_in((p),(at),(src))
#endif
#include "fm1_recovery.h"
/* LSDj songs (cartridge RAM) in flash: loaded at boot, written on SAVE. */
static int lsdj_fl_erase(uint32_t off){uint32_t took;return fl_erase4k(off,&took);}
#define LSDJ_FL_ERASE(off) lsdj_fl_erase(off)
#define LSDJ_FL_WRITE(off,p,n) fl_write(off,p,n)
#define LSDJ_FL_READ(off,p,n) ota_fread(off,p,n)
#define LSDJ_FL_IDLE() fm1_wdt_feed()
/* The import's 4 KiB bounce buffer: borrowed from the screen buffer, past the 32 KiB+
   the compressed-save import also borrows (boot only, before anything is drawn there). */
#define LSDJ_SAVE_BUF ((uint8_t*)screen+65536u)
typedef char lsdj_save_buf_inside_screen[65536u+4096u<=sizeof screen?1:-1];
#include "lsdj_save.h"   /* v5 A/B save format: only read once, to import it */
#include "lsdj_state.h"  /* compressed save store: the autosave (and later the slots) */
/* Build-time check: the flash driver must accept the whole save pool (a narrower
   range made autosaves that landed in the pool's top sectors fail silently). */
typedef char lst_pool_inside_flash_range[FL_RANGE_BASE(LST_POOL_LO,LST_POOL_HI-LST_POOL_LO)?1:-1];
#include "lsdj_ftl.h"    /* power-cut-safe save store, written only by the SAVE button */
#define SAVE_BUTTON 9u            /* BTN_SAVE */
#define GLO_BUTTON 7u             /* BTN_GLO: settings menu */
#define FX_BUTTON 2u              /* BTN_FX: effects page */
#define SEQ_BUTTON 11u            /* BTN_SEQ: LSDj live / song mode, any screen */
#define ARP_BUTTON 10u            /* BTN_ARP: song row cue (hold, K1/K2 row, let go) */
#define EDIT_BUTTON 6u            /* BTN_EDIT: tempo (hold + K1/K2, or tap) */
#define TAP_KEY 0u                /* F3, the lowest key: with EDIT held, tap tempo (0.9.98-dev.8; EDIT is too stiff to tap) */
#define CHAN_BUTTON 3u            /* the SELECT button (printed SELECT; not the SELECT knob): the effects channel, any LSDj screen */
#define LSDJ_STATE_BUILD 1u       /* cartridge-RAM-only compressed autosave (v6..v10, imported) */
#define SILENT_FRAMES 30u            /* 0.5 s of exactly-zero output: LSDj is stopped */
static ftl_t ftl;
static int save_display_ok;
#include "lsdj_overlay.h"
#include "lsdj_splash.h"   /* startup screen */
static lsdj_ov_t ov;
/* Settings menu: GLO opens and closes it; firmware/lsdj_settings.h. */
#include "lsdj_settings.h"
static lsdj_settings_t settings;
static lsdj_midi_t midi;   /* the MIDI options (lsdj_midi.h): save-store record 16 */
#define MIDI_REC 16u
static lsdj_feat_t feat;   /* the feature switches, SETTINGS / FX+LIGHTS (lsdj_feat.h): record 23 */
#define FEAT_REC 23u
static lsdj_menu_t menu;
/* A save-store record, if it changed. 0 = ok. */
static int rec_put(unsigned r,uint32_t w){return ((ftl.rec_has>>r)&1u)&&ftl.rec[r]==w?0:ftl_put_record(&ftl,r,w);}
/* The settings (record 0), the MIDI options (record 16) and the feature switches
   (record 23), only what changed. The flash must be safe (emulator parked). 0 = ok. */
static int settings_store(void){
    int rc=ftl_put_settings(&ftl,lsdj_set_pack(&settings));
    if(!rc)rc=rec_put(MIDI_REC,lsdj_midi_pack(&midi));
    if(!rc)rc=rec_put(FEAT_REC,lsdj_feat_pack(&feat));
    return rc;
}
static char menu_hint[20];
static uint32_t menu_hint_until;

/* Effects (FX button: page; KNOB 1-4: live). firmware/lsdj_fx.h, lsdj_fx_ui.h */
#include "lsdj_fx_ui.h"
static lsdj_fx_t fx;
static lsdj_fx_ui_t fxu;
static uint8_t fx_echo[LSDJ_FX_ECHO_LEN] __attribute__((section(".pool"),aligned(4)));
/* Presets (0.9.98-dev.6, firmware/lsdj_presets.h): the page in RAM (the save store's block 32), the slot loaded or
   kept last (its key blinks while the EDIT page is open), the effects' glide, and the EDIT page (0.9.98-dev.9:
   nothing is held; a press of EDIT opens it and it stays, EDIT again (or FX / GLO) closes it). On it: K1 / K2
   the tempo, F3 taps it, C4 .. C5 load a preset at once, the SELECT knob moves the cursor, the SELECT button
   loads the preset at the cursor, SAVE keeps everything there. */
#include "lsdj_presets.h"
static uint8_t presets_page[LSDJ_PRESETS_PAGE] __attribute__((aligned(4)));
static uint8_t preset_cur=LSDJ_PRESET_NONE,presets_dirty;
static lsdj_glide_t glide;
static uint8_t edit_open,plist_cur;
static int16_t fx_reverb[LSDJ_FX_RV_LEN] __attribute__((aligned(4)));   /* the master reverb (0.9.97), 6.6 KB: in RAM (.bss), the pool has 3 KB left */
static void fx_hook(const int16_t *s,int32_t *l,int32_t *r){lsdj_fx_mix(&fx,s,l,r);}   /* audio interrupt */
/* Two areas (FM-1_984). The channel effects: turning KNOB 1-4 or SELECT pops up the channel pages
   (FILTER .. LO-FI) for the channel under LSDj's cursor, for a moment, as before; LSDj keeps its input.
   The master effects: only the FX button, which opens the master pages (MASTER, ECHO, ECHO MOD, REVERB: the
   channel strip, C4-F4 mute, lsdj_fx_hold_keys) and keeps them open until FX again. */
static uint8_t fx_open;
static uint32_t fx_keys_prev;
/* Where LSDj keeps the channel under its cursor (kept on the CHAIN and PHRASE
   screens too) and its live tempo, per version, found with harness/find_cursor.c
   and harness/find_tempo.c; the SYNC setting (song RAM offset) and the armed /
   playing flags (4 WRAM bytes, one per channel) with harness/lsdj_drive.c.
   0 = unknown. */
static uint16_t cursor_addr,tempo_addr,sync_off,armed_addr,row_addr,live_addr,songrow_addr,chainpos_addr,songtab_off,
                period_addr,songtempo_off,screen_addr,synclive_addr,syncmask_addr,songcur_addr;
/* the song's chain table and LSDj's play-time clock (song memory offsets; 0 = unknown): 9.3.9's, or profile 3's */
static uint16_t chaintab_off,playtime_off;
#define LSDJ_SYNC_MIDI 3u
#define LSDJ_SYNC_LSDJ 1u
#define LSDJ_SYNC_KEYBD 5u
static void cursor_detect(void){
    /* row: 4 phrase rows (0..15, one per channel), live: 1 in live mode, songrow: 4 song
       rows, chainpos: 4 places in the chain, songtab: the song table in cartridge RAM
       (harness/lsdj_drive.c rec / peek / sdump, find_chainpos.py) */
    /* period: the tempo period (16 bits), songtempo: the song's tempo in cartridge RAM */
    /* synclive: LSDj's working copy of SYNC; syncmask: the interrupt bits it builds IE from on a
       screen change (harness/keybd_auto.sh, by diffing WRAM around its PROJECT screen) */
    /* songcur: the SONG screen's cursor row, the row START plays from (lsdj_drive.c: D presses, then a poke
       before START plays from the poked row; LSDj redraws the cursor only when it moves) */
    static const struct {const char *title;uint16_t cursor,tempo,sync,armed,row,live,songrow,chainpos,songtab,period,songtempo,screen,synclive,syncmask,songcur;} known[]={
        {"LSDj-v9.3.9",0xC41D,0xC529,0x3FBD,0xC0E0,0xC16C,0xC528,0xC200,0xC17C,0x1290,0xC954,0x3FB4,0xC401,0xCB66,0xCB6D,0xC41E}};
#ifdef CART_SLOT_CAPACITY
    /* Generic builds: the browser marks the slot with profile 1 only when the program
       banks' SHA-256 matches the verified LSDj 9.3.9 program (lsdj_slot.h byte 148), never
       by title. Every address below comes from that program, so all of them apply;
       unknown programs keep every helper off. Profile 2 (FM-1_986): another LSDj on the web page's
       list (custom palettes and kits allowed): its cursor and tempo bytes from the slot, nothing else. */
    const int verified=cart_slot.profile==1u;
    if(cart_slot.profile==2u){cursor_addr=cart_slot.cursor_addr;tempo_addr=cart_slot.tempo_addr;return;}
    /* Profile 3 (0.9.98-dev.18): another LSDj with every helper, its addresses from the slot (the web page found
       them from 9.3.9's code, harness/lsdj_addr_find.mjs, and lists only versions that pass the emulator checks);
       lsdj_slot_parse refused the slot if any is outside its memory. */
    if(cart_slot.profile==3u){
        const uint16_t *a=cart_slot.addr;
        cursor_addr=cart_slot.cursor_addr;tempo_addr=cart_slot.tempo_addr;sync_off=a[LSDJ_SLOT_A_SYNC];
        armed_addr=a[LSDJ_SLOT_A_ARMED];row_addr=a[LSDJ_SLOT_A_ROW];live_addr=a[LSDJ_SLOT_A_LIVE];
        songrow_addr=a[LSDJ_SLOT_A_SONGROW];chainpos_addr=a[LSDJ_SLOT_A_CHAINPOS];songtab_off=a[LSDJ_SLOT_A_SONGTAB];
        period_addr=a[LSDJ_SLOT_A_PERIOD];songtempo_off=a[LSDJ_SLOT_A_SONGTEMPO];screen_addr=a[LSDJ_SLOT_A_SCREEN];
        synclive_addr=a[LSDJ_SLOT_A_SYNCLIVE];syncmask_addr=a[LSDJ_SLOT_A_SYNCMASK];songcur_addr=a[LSDJ_SLOT_A_SONGCUR];
        chaintab_off=a[LSDJ_SLOT_A_CHAINTAB];playtime_off=a[LSDJ_SLOT_A_PLAYTIME];
        gp_save_ignore(playtime_off,playtime_off+5u);   /* its play-time clock: not a change for AUTOSAVE */
        return;
    }
#endif
    const char *t=gp_title();
    for(unsigned i=0;i<sizeof known/sizeof known[0];i++){
        unsigned k=0;while(known[i].title[k]&&t[k]==known[i].title[k])k++;
#ifdef CART_SLOT_CAPACITY
        if(i==0&&verified){
#else
        if(!known[i].title[k]&&!t[k]){
#endif
            cursor_addr=known[i].cursor;tempo_addr=known[i].tempo;sync_off=known[i].sync;armed_addr=known[i].armed;
            row_addr=known[i].row;live_addr=known[i].live;
            songrow_addr=known[i].songrow;chainpos_addr=known[i].chainpos;songtab_off=known[i].songtab;
            period_addr=known[i].period;songtempo_off=known[i].songtempo;screen_addr=known[i].screen;
            synclive_addr=known[i].synclive;syncmask_addr=known[i].syncmask;songcur_addr=known[i].songcur;
            chaintab_off=0x2080u;playtime_off=0x3FB3u;return;
        }
    }
}
/* Note mode needs LSDj's SYNC on KEYBD (the keys reach LSDj through the link port). LSDj 9.3.9 with
   SYNC OFF: set here as LSDj's own PROJECT screen does (harness/keybd_auto.sh): the song's SYNC
   byte, LSDj's working copy, the interrupt bits it builds IE from, and IE's serial bit at once.
   MIDI and LSDJ are left as they are (MIDI clock in / out need them); the message says how.
   0: KEYBD already, 1: set just now, 2: not set (another SYNC, or an LSDj without the addresses). */
/* Songs coming in from the page (lsdj_link.h BEGIN..COMMIT) are written straight into the save memory and
   checked whole at COMMIT: nothing else may change it meanwhile. The SYNC byte (auto SYNC on the DJ page's
   MIDI Stop, its SYNC_SET) and the song tempo did, and every crate load ended "checksum mismatch" (0.9.98-dev.6,
   Colin's Log). Defined after link_state. */
static int songs_incoming(void);
static int keybd_sync(void){
    if(!sync_off||songs_incoming())return 2;
    uint8_t s=gp_save_data()[sync_off];
    if(s==LSDJ_SYNC_KEYBD)return 0;
    if(s!=0u||!synclive_addr||!syncmask_addr)return 2;
    const uint16_t a[2]={synclive_addr,syncmask_addr};
    const uint8_t v[2]={LSDJ_SYNC_KEYBD,(uint8_t)(gp_wram_peek(syncmask_addr)|0x08u)};
    if(!gp_wram_poke_many(a,v,2u))return 2;
    gp_ie_or(0x08u);gp_save_data()[sync_off]=LSDJ_SYNC_KEYBD;
    return 1;
}
static void keybd_sync_note(void){if(keybd_sync()==1)lsdj_ov_say(&ov,LSDJ_MSG_KEYBD_SET,fm1_ms);}
/* Auto SYNC (0.9.97): with SYNC on KEYBD (or OFF), a MIDI Start / Continue sets it to MIDI for the
   clock, and Stop sets KEYBD again once LSDj has stopped, so note mode and NOTE IN work between
   runs. LSDj 9.3.9 (harness/sync_switch.sh): the song's SYNC byte, LSDj's working copy and the
   keyboard flag after the interrupt bits (1 for KEYBD; it must be 0 for MIDI, or LSDj runs on its
   own clock). The interrupt bits are the same for both. 0.9.98-dev.2: SYNC = LSDJ follows a Start too
   when CLOCK OUT is OFF (on an FM-1, LSDJ only matters for CLOCK OUT: it has no link cable), and goes
   back to LSDJ; with CLOCK OUT on it is left alone. */
static uint8_t sync_auto;   /* SYNC is MIDI because of a MIDI Start: the SYNC to go back to after Stop
                               (LSDJ_SYNC_KEYBD or LSDJ_SYNC_LSDJ), 0 when not */
static int sync_set(uint8_t s){
    if(!sync_off||!synclive_addr||!syncmask_addr||songs_incoming())return 0;
    const uint16_t a[2]={synclive_addr,(uint16_t)(syncmask_addr+1u)};
    const uint8_t v[2]={s,(uint8_t)(s==LSDJ_SYNC_KEYBD)};
    if(!gp_wram_poke_many(a,v,2u))return 0;
    gp_save_data()[sync_off]=s;return 1;
}
/* MIDI clock sync (firmware/lsdj_midisync.h): USB MIDI clock and transport. */
#include "lsdj_midisync.h"
static lsdj_ms_t msync;
static uint32_t sync_btn;   /* START held by the sync this frame */
static int lsdj_armed(void){
    if(!armed_addr)return 0;
    for(unsigned c=0;c<4;c++)if(gp_wram_peek((uint16_t)(armed_addr+c)))return 1;
    return 0;
}
/* Tick timing: a tick is heard SYNC DELAY (the MIDI options: 100, 75 or 50 ms) after
   it arrived, always. The sound clock is the output's sample count, interpolated since
   the last audio interrupt; emulation runs at most GP_AUDIO_TARGET + one frame (2040
   samples, 46 ms) ahead of it, so a tick placed 50 ms or more later is never already past. */
static uint32_t sound_clock(void){
    uint32_t s,t,p;
    do{s=aud_seq;t=aud_at_ticks;p=aud_at_pos;}while((s&1u)||s!=aud_seq);
    uint32_t dt=fm1_ticks()-t;if(dt>288000u)dt=288000u;   /* at most two blocks (12 ms) */
#if GB_SMK37
    return p+dt*441u/240000u;                             /* 24 MHz ticks -> 44.1 kHz samples */
#else
    return p+dt/544u;                                     /* 24 MHz ticks -> the DAC's frames: 750000 / 17 Hz, 544 ticks each */
#endif
}
static uint32_t tick_target;
static void sync_link_send(uint8_t b){(void)b;gp_link_tick_at(tick_target);}
static int16_t midi_pc_row=-1;   /* a program change to cue (cue_frame takes it) */
static int cue_stop(int said);   /* (the ARP cue, below) */
/* Who muted each channel (for the MUTE POPUP): 1 the C4-F4 keys, 2 the web page, 3 MIDI CC 81. */
static uint8_t mute_by[4];
static void mute_mark(uint8_t before,uint8_t by){
    for(unsigned c=0;c<4u;c++)if((fx.mute&~before)>>c&1u)mute_by[c]=by;
}
/* SHOW CC: an effect moved by MIDI CC, as a message: "PU2 CUTOFF" / "MIDI CC 74: 5A". */
static void cc_show(unsigned c,unsigned cc){
    unsigned i=0;
    while(i<LSDJ_MIDI_CCS&&lsdj_midi_cc_num[i]!=cc)i++;
    if(i>=LSDJ_MIDI_CCS)return;
    char l1[20],l2[20],v[6];unsigned e=lsdj_midi_cc_fxk[i],n=0;
    if(lsdj_fxk_on_channel(e)||cc==81u)n=lsdj_fx_put(l1,lsdj_fx_put(l1,0,lsdj_fx_target_name[c&3u])," ");
    lsdj_fx_put(l1,n,e==FXK_NONE?"MUTE":lsdj_fxk_name[e]);   /* (the knobs' names: no second table) */
    n=lsdj_fx_put(l2,lsdj_fx_num(l2,lsdj_fx_put(l2,0,"MIDI CC "),cc),": ");
    if(e==FXK_NONE)lsdj_fx_put(l2,n,(fx.mute>>c)&1u?"MUTED":"PLAYING");
    else{lsdj_fx_ui_t t=fxu;t.target=(uint8_t)(c&3u);lsdj_fxk_value(&fx,&t,e,v);lsdj_fx_put(l2,n,v);}
    lsdj_ov_show(&ov,l1,l2,fm1_ms);
}
static uint8_t midi_note_told;
static uint8_t lsdj_absent;   /* no LSDj in the slot (no_lsdj): no link, no MIDI */
static void midi_in(uint32_t pkt,uint32_t at_ms,uint32_t src){
    /* songs coming in (LSDj paused): MIDI waits for nothing. A Start kept for later pressed START on the new
       songs as LSDj started, and auto SYNC wrote into the save memory being filled (songs_incoming) */
    if(lsdj_absent||songs_incoming())return;
    uint8_t st=(uint8_t)(pkt>>8),d1=(uint8_t)(pkt>>16);
    switch(lsdj_midi_route(&midi,pkt,src)){
    case LSDJ_MIDI_CLOCK:case LSDJ_MIDI_TRANSPORT:break;   /* below */
    case LSDJ_MIDI_NOTE:
        keybd_sync_note();
        if(sync_off&&gp_save_data()[sync_off]!=LSDJ_SYNC_KEYBD&&!midi_note_told&&!sync_auto){
            midi_note_told=1;lsdj_ov_show(&ov,"MIDI NOTES: SET","LSDJ SYNC TO KEYBD",fm1_ms);
        }
        lsdj_keybd_note(d1,1);return;
    case LSDJ_MIDI_CC:{
        uint8_t before=fx.mute;int c=lsdj_midi_cc(&midi,&fx,pkt);
        if(c){mute_mark(before,3);if(feat.v[LSDJ_FEAT_CCSHOW])cc_show((unsigned)c-1u,d1);}
        return;
    }
    case LSDJ_MIDI_PC:midi_pc_row=d1;return;
    default:return;
    }
    uint32_t age=fm1_ms-at_ms;if(age>50u)age=50u;   /* waited in the ring (ms) */
#if GB_SMK37
    tick_target=sound_clock()-age*441u/10u+lsdj_midi_delay_samples(&midi);
#else
    tick_target=sound_clock()-age*750u/17u+lsdj_midi_delay_samples(&midi);   /* (ms -> the DAC's frames) */
#endif
    if((st==0xFAu||st==0xFBu)&&sync_off){   /* auto SYNC: KEYBD (or OFF) -> MIDI */
        uint8_t s=gp_save_data()[sync_off];
        if(s==0u&&keybd_sync()==1)s=LSDJ_SYNC_KEYBD;   /* (OFF: KEYBD's interrupt bits first) */
        if((s==LSDJ_SYNC_KEYBD||(s==LSDJ_SYNC_LSDJ&&!midi.clock_out))&&sync_set(LSDJ_SYNC_MIDI))sync_auto=s;
    }
    sync_midi=(uint8_t)(sync_off&&gp_save_data()[sync_off]==LSDJ_SYNC_MIDI);
    lsdj_ms_heard(&msync,st,fm1_ms);
    int said=lsdj_ms_byte(&msync,st,sync_midi,lsdj_armed(),sync_link_send);
    /* a Stop clears the cue (whatever LSDj's SYNC: after a Stop it is the user's again, and a Stop then says
       nothing); LSDj stopped already: "CUE CANCELLED" on screen instead of MIDI STOP */
    if(st==0xFCu&&cue_stop(!lsdj_armed()))return;
    static const char *const msg[5][2]={{0,0},{"MIDI START",""},{"MIDI CONTINUE",""},{"MIDI STOP",""},
                                        {"MIDI START: SET","LSDJ SYNC TO MIDI"}};
    const char *l2=msg[said][1];
    if(sync_auto&&said!=LSDJ_MS_SAID_SET_SYNC)
        l2=said!=LSDJ_MS_SAID_STOP?"LSDJ SYNC: MIDI":sync_auto==LSDJ_SYNC_LSDJ?"LSDJ SYNC: LSDJ":"LSDJ SYNC: KEYBD";
    if(said)lsdj_ov_show(&ov,msg[said][0],l2,fm1_ms);
}
/* The effects pop-up: the page's four knobs as bars under LSDj's four channel
   columns (lsdj_overlay.h). hot = the knob just turned (amber), -1 none. While
   it shows, it is refilled every frame (cursor moves, synced times...). */
static lsdj_ov_bars_t bars;
static uint32_t mute_pop_until;   /* MUTE POPUP: the title says why mute_pop_ch is silent, until then */
static uint8_t mute_pop_ch;
/* The channels knob k's effect acts on (bit per channel; 0: a shared effect). */
static unsigned fx_knob_chans(unsigned k){
    if(!lsdj_fxk_on_channel(lsdj_fx_knob(&fxu,k)))return 0;
    if(lsdj_fx_chmode(&fxu))return 1u<<k;
    unsigned t=lsdj_fx_eff(&fxu);return t<4u?1u<<t:15u;
}
static void fx_bars_fill(void){
    lsdj_fx_bars(&fx,&fxu,bars.hot,bars.title,bars.big,bars.label,bars.value,bars.caption,bars.level);
    lsdj_fx_bar_choices(&fx,&fxu,bars.nchoice,bars.pick,bars.choice);
    bars.amount_scale=1;
    bars.strip=lsdj_fx_on_master(&fxu)?(uint8_t)(0x80u|fx.mute):0u;
    bars.grey=0;   /* GREY MUTED: a muted channel's controls (KNOBS = CHANNELS: its column) */
    if(feat.v[LSDJ_FEAT_GREY]&&!lsdj_fx_on_master(&fxu))
        for(unsigned k=0;k<4u;k++){
            unsigned ch=fx_knob_chans(k);
            if(ch&&(ch&fx.mute)==ch)bars.grey|=(uint8_t)(lsdj_fx_chmode(&fxu)?1u<<k:0x80u);
        }
    if(mute_pop_until&&(int32_t)(mute_pop_until-fm1_ms)>0){   /* "PU1 MUTED: KEYS" (15: the panel's width) */
        static const char *const by[4]={"",": KEYS",": WEB",": CC81"};
        lsdj_fx_put(bars.title,lsdj_fx_put(bars.title,lsdj_fx_put(bars.title,0,lsdj_fx_target_name[mute_pop_ch&3u])," MUTED"),
                    by[mute_by[mute_pop_ch&3u]&3u]);
    }else mute_pop_until=0;
    { unsigned t=lsdj_fx_eff(&fxu);bars.chan=(int8_t)(t<4u?(int)t:-1); }   /* frame the channel the effects act on */
}
static void fx_bars_show(int hot){
    bars.hot=(int8_t)hot;fx_bars_fill();lsdj_ov_bars_keep(&bars,fm1_ms);
}
/* The effects setup into the save store (records 1..11), only what changed.
   The flash must be safe (emulator parked or stopped). Records written, or -1. */
/* the record of effects word i: words 0..10 in records 1..11, words 11..16 (alpha 66) in 17..22, word 17 (the
   reverb, 0.9.97) in 24 (23 is the feature switches), word 18 (the reverb sends, 0.9.97-dev.7) in 25 */
#define FX_REC(i) ((i)<LSDJ_FX_WORDS_OLD?(i)+1u:(i)<LSDJ_FX_WORDS_LINK?(i)+6u:(i)+7u)
static int fx_store(void){
    uint32_t w[LSDJ_FX_WORDS];lsdj_fx_pack(&fx,&fxu,w);int n=0;
    for(unsigned i=0;i<LSDJ_FX_WORDS;i++){
        unsigned r=FX_REC(i);
        if(((ftl.rec_has>>r)&1u)&&ftl.rec[r]==w[i])continue;
        if(ftl_put_record(&ftl,r,w[i]))return -1;
        n++;
    }
    return n;
}
static void fx_load(void){
    uint32_t w[LSDJ_FX_WORDS];unsigned n=LSDJ_FX_WORDS;
    for(unsigned i=0;i<LSDJ_FX_WORDS;i++){
        unsigned r=FX_REC(i);
        if((ftl.rec_has>>r)&1u)w[i]=ftl.rec[r];
        else if(i==10u)w[i]=0;   /* alphas 27-29 kept 10 words */
        else if(i>=LSDJ_FX_WORDS_RV){n=LSDJ_FX_WORDS_RV;break;}   /* saved by 0.9.97-dev.1-6: sends from INPUT */
        else if(i>=LSDJ_FX_WORDS_LINK){n=LSDJ_FX_WORDS_LINK;break;}   /* saved before 0.9.97: the reverb off */
        else if(i>=LSDJ_FX_WORDS_OLD){n=LSDJ_FX_WORDS_OLD;break;}   /* saved before alpha 66: the new effects off */
        else return;
    }
    (void)lsdj_fx_unpack_n(&fx,&fxu,w,n);
}
/* The feature switches the effects controls use (KNOBS = CHANNELS starts on its first effect). */
static void feat_apply(void){
    gp_core1.pic_every=lsdj_feat_rate_every[feat.v[LSDJ_FEAT_RATE]&3u];   /* SCREEN RATE (both paths) */
    if(fxu.channels!=feat.v[LSDJ_FEAT_CHANNELS]){fxu.channels=feat.v[LSDJ_FEAT_CHANNELS];fxu.param=0;fxu.page=FX_PAGE_FILTER;}
#if !GB_SMK37
    usb_follow=feat.v[LSDJ_FEAT_USBVOL];
#endif
}
/* Themes (firmware/lsdj_theme.h): the screen's four colours and the overlay's. */
#include "lsdj_theme.h"
typedef char lsdj_theme_count_ok[LSDJ_THEMES==LSDJ_SET_THEMES?1:-1];
static void settings_apply(void){
    static const uint32_t sel[3]={0,1u<<LSDJ_KEY_FS5,1u<<LSDJ_KEY_DS5};
    lsdj_input_config(&lsdj_in,settings.knobs_swapped,settings.presets_rev,settings.algo_rev,
                      settings.play_is_select,sel[settings.select_key%3u]);
    const lsdj_theme_t *th=lsdj_theme_of(settings.theme);
    lsdj_theme_overlay(th);gp_palette_colors(th->gb);
    lsdj_ov_ms=lsdj_set_popup_ms[settings.popup%LSDJ_SET_POPUPS];   /* POPUP TIME */
}
/* Everything the firmware shows, in LSDj's own style (firmware/lsdj_native.h):
   drawn into the Game Boy picture before it is scaled. native_draw is below. */
#include "lsdj_native.h"
static void native_draw(void);
/* Menu open: SELECT picks a setting, KNOB 1-4 change it;
   PRESETS / ALGORITHM show what they now do (to try the directions). */
static void menu_input(void){
    int32_t enc[FM1_NENC];
    for(unsigned e=0;e<FM1_NENC;e++)enc[e]=fm1_enc_take(e);
    int32_t st[4]={enc[2],enc[3],enc[4],enc[5]};
    switch(lsdj_menu_knobs(&menu,&settings,&midi,&feat,st,enc[0])){case 1:settings_apply();break;case 3:feat_apply();break;}
    if(enc[0]||st[0]||st[1]||st[2]||st[3])menu_hint_until=0;
    static const char *const knob_name[2]={"PRESETS: ","ALGO: "};
    static const int enc_of[2]={LSDJ_ENC_PRESETS,LSDJ_ENC_ALGORITHM};
    for(unsigned k=0;k<2;k++){
        int32_t d=enc[enc_of[k]];if(!d)continue;
        uint8_t b=lsdj_in.knob_out[k][d>0];
        const char *dir=b==GP_UP?"UP":b==GP_DOWN?"DOWN":b==GP_LEFT?"LEFT":"RIGHT";
        unsigned n=0;
        for(const char *c=knob_name[k];*c;c++)menu_hint[n++]=*c;
        for(const char *c=dir;*c;c++)menu_hint[n++]=*c;
        menu_hint[n]=0;menu_hint_until=(fm1_ms+1500u)|1u;
    }
    gp_buttons(sync_btn);
}
/* Show a message now, while the emulator (and the CPU1 video job) is stopped. */
static void ov_now(unsigned msg){
    lsdj_ov_say(&ov,msg,fm1_ms);
    if(!save_display_ok)return;
    while(!display_ready())fm1_wdt_feed();
    native_draw();video_scale_local(gp_pixels(),screen);display_frame();
    while(!display_ready())fm1_wdt_feed();
}
/* The same with any two lines (0.9.98-dev.3: the web page's song import). */
static void ov_now_text(const char *l1,const char *l2){
    lsdj_ov_show(&ov,l1,l2,fm1_ms);
    if(!save_display_ok)return;
    while(!display_ready())fm1_wdt_feed();
    native_draw();video_scale_local(gp_pixels(),screen);display_frame();
    while(!display_ready())fm1_wdt_feed();
}
static void save_wait(uint32_t ticks){uint32_t t=fm1_ticks();while(fm1_ticks()-t<ticks)fm1_wdt_feed();}
static void save_blink(unsigned n,uint32_t ticks){
    for(unsigned i=0;i<n;i++){fm1_led_key(SAVE_BUTTON,0);save_wait(ticks);fm1_led_key(SAVE_BUTTON,1);save_wait(ticks);}
}
/* The save with LSDj stopped: LSDj (and CPU1's video) paused, erases allowed. quiet: an
   autosave, no messages unless it fails. */
static void stopped_save(int quiet){
    fm1_led_key(SAVE_BUTTON,0);
    video_hold();   /* CPU1 parked, not stopped (multicore_video.h) */
    if(!quiet)ov_now(LSDJ_MSG_SAVING);
    int rc=ftl_save_now(&ftl,gp_save_data());
    if(rc>=0){int fr=fx_store();if(fr<0)rc=-1;else if(rc==0&&fr>0)rc=1;}   /* and the effects */
    video_release();
    if(rc>=0)gp_save_clean();
    if(rc<0||!quiet)lsdj_ov_say(&ov,rc>0?LSDJ_MSG_SAVED:rc==0?LSDJ_MSG_NO_CHANGES:LSDJ_MSG_SAVE_FAILED,fm1_ms);
    fm1_led_key(SAVE_BUTTON,1);
    if(rc<0)save_blink(5,1200000u);
}
/* SAVE button. Nothing writes flash in the background: SAVE pauses LSDj (and
   the CPU1 video job), writes the changed 4 KiB blocks of cartridge RAM through
   the power-cut-safe store, and resumes. Only while LSDj is stopped (0.5 s of
   silent output); while it plays, SAVE is refused with 2 slow blinks. SAVE light
   off while writing; 5 fast blinks = flash error (the previous save stays). */
/* SAVE while LSDj plays: the save store writes one step (a 256-byte page, a
   block snapshot, the commit) per emulated frame, the emulator parked for each
   step (~1-2 ms), never an erase (those wait for a SAVE with the song stopped).
   Each block is snapshotted when its turn comes. */
static int play_save,settings_pending;
static uint8_t play_save_songs=1;   /* this save is the songs' (with the effects); 0: the presets page alone */
static uint8_t play_save_quiet;      /* an autosave: no messages unless it fails */
static uint32_t play_save_change;    /* gp_save_last_change() when it began */
/* Saved: no unsaved change left, unless LSDj changed something while the save ran. */
static void save_cleaned(uint32_t change_at_start){
    int again=gp_save_last_change()!=change_at_start;
    gp_save_clean();if(again)gp_save_mark_dirty();
}
static int theme_store(void);
static void play_save_done(int ok){
    if(ok&&play_save_songs){   /* the effects setup with it */
        if(core1_park(960000u)){if(fx_store()<0)ok=0;core1_unpark();}else ok=0;
    }
    play_save=0;fm1_led_key(SAVE_BUTTON,1);
    if(ok&&play_save_songs)save_cleaned(play_save_change);
    if(settings_pending){   /* settings (or a preset's) changed while the save ran */
        settings_pending=0;video_hold();(void)settings_store();(void)theme_store();video_release();
    }
    if(!ok||!play_save_quiet)lsdj_ov_say(&ov,ok?LSDJ_MSG_SAVED:LSDJ_MSG_SAVE_FAILED,fm1_ms);
    if(!ok)save_blink(5,1200000u);
}
static void play_save_step(void){
    if(!play_save)return;
    if(!core1_park(960000u))return;          /* 40 ms: try again on the next frame */
    int r=ftl_step(&ftl,gp_save_data(),0);
    core1_unpark();
    if(r<0)play_save_done(0);
    else if(!ftl_busy(&ftl))play_save_done(1);
}
/* want: the blocks to save if changed (all; or the presets page alone, which never touches the songs' state) */
static int play_save_start_mask(int quiet,ftl_mask_t want){
    uint32_t change=gp_save_last_change();ftl_mask_t mask=ftl_changed(&ftl,gp_save_data())&want;
    int songs=(want&~FTL_BIT(FTL_XBLOCK))!=0;
    if(!songs&&ftl.retry&~FTL_BIT(FTL_XBLOCK))return 0;   /* (a failed song save waits: never part of one alone) */
    if(!mask&&!ftl.retry&&!songs)return 1;
    if(!mask&&!ftl.retry){   /* the song is saved; maybe the effects are not */
        int fr=-1;
        if(core1_park(960000u)){fr=fx_store();core1_unpark();}
        if(fr>=0)save_cleaned(change);
        if(fr<0||!quiet)lsdj_ov_say(&ov,fr<0?LSDJ_MSG_SAVE_FAILED:fr?LSDJ_MSG_SAVED:LSDJ_MSG_NO_CHANGES,fm1_ms);
        return 1;
    }
    int rc=ftl_begin(&ftl,mask);
    if(rc==-2){ftl.retry=0;return 0;}         /* would need an erase: only with the song stopped */
    if(rc){lsdj_ov_say(&ov,LSDJ_MSG_SAVE_FAILED,fm1_ms);return 1;}
    play_save=1;play_save_quiet=(uint8_t)quiet;play_save_change=change;play_save_songs=(uint8_t)songs;fm1_led_key(SAVE_BUTTON,0);
    if(!quiet)lsdj_ov_say(&ov,LSDJ_MSG_SAVING_PLAYING,fm1_ms);
    return 1;
}
static int play_save_start(int quiet){return play_save_start_mask(quiet,~(ftl_mask_t)0);}
static void lsdj_save_button(void){
    if(play_save)return;                      /* already saving */
    if(gp_silent_frames()<SILENT_FRAMES){
        if(!recovery_flash_ok){lsdj_ov_say(&ov,LSDJ_MSG_SAVE_FAILED,fm1_ms);save_blink(5,1200000u);return;}
        if(play_save_start(0))return;
        lsdj_ov_say(&ov,LSDJ_MSG_SAVE_PLAYING,fm1_ms);save_blink(2,7200000u);return;   /* flash full: stop first */
    }
    if(!recovery_flash_ok){lsdj_ov_say(&ov,LSDJ_MSG_SAVE_FAILED,fm1_ms);save_blink(5,1200000u);return;}
    stopped_save(0);
}
/* AUTOSAVE (lsdj_feat.h, FM-1_981): once nothing has changed for AUTOSAVE_QUIET_FRAMES, at most
   every 1 / 5 / 15 minutes: the song (and the effects) saved quietly, as the save-while-playing
   (a step a frame, no erases: nothing pauses, the music goes on). If the store needs an erase
   first, it waits until the song is stopped (then saves as SAVE does, LSDj paused a moment).
   SAVE light off while writing. */
#define AUTOSAVE_QUIET_FRAMES 300u   /* 5 s */
static uint32_t autosave_last;       /* fm1_ms of the last autosave */
static int fx_changed(void){         /* the effects differ from their saved records */
    uint32_t w[LSDJ_FX_WORDS];lsdj_fx_pack(&fx,&fxu,w);
    for(unsigned i=0;i<LSDJ_FX_WORDS;i++){unsigned r=FX_REC(i);if(!((ftl.rec_has>>r)&1u)||ftl.rec[r]!=w[i])return 1;}
    return 0;
}
static void autosave_poll(void){
    static const uint32_t every_ms[4]={0,60000u,300000u,900000u};
    uint32_t every=every_ms[feat.v[LSDJ_FEAT_AUTOSAVE]&3u];
    if(!every||play_save||!recovery_flash_ok||menu.open||fm1_ms-autosave_last<every)return;
    int song=(int)gp_save_dirty_sig();
    if(song&&gp_frame_count()-gp_save_last_change()<AUTOSAVE_QUIET_FRAMES)return;   /* still editing */
    if(!song&&!fx_changed())return;
    autosave_last=fm1_ms;
    if(play_save_start(1))return;           /* stopped or playing: written a step a frame, nothing paused */
    if(gp_silent_frames()>=SILENT_FRAMES)stopped_save(1);   /* needs an erase: with the song stopped */
    else autosave_last=fm1_ms-every+10000u;  /* ... playing: look again in 10 s */
}
/* At boot, before LSDj's first frame (sound is silent here, so erases are
   fine): load the autosave (SAVE light blinks 3 times). Without one, import the
   previous format (v6..v10 compressed autosave, or the v5 A/B save; blinks
   twice) into a fresh autosave area, keeping the old copy until the new one is
   committed. */
static int songs_loaded;   /* shown once the game picture is up */
static void lsdj_save_boot(void){
    unsigned blinks=0;
    ftl_x_set(presets_page,sizeof presets_page);   /* block 32: the presets (read by ftl_boot) */
    gp_save_ignore(0x3FB3u,0x3FB8u);   /* LSDj 9.3.9's play-time clock: not a change for AUTOSAVE */
    if(ftl_boot(&ftl,gp_save_data()))blinks=3;
    else if(recovery_flash_ok){
        uint8_t keep[FTL_N];memset(keep,0,sizeof keep);
        lst_region_t r={gp_save_data(),gp_save_size()};
        lst_entry_t e[LST_KINDS];lst_scan(e,NULL);
        if(e[LST_AUTO].valid&&lst_load(LST_AUTO,&r,1,LSDJ_STATE_BUILD,(uint8_t*)screen,LSDJ_SAVE_BUF,NULL)==LST_OK){
            for(uint32_t k=0;k<e[LST_AUTO].nsect;k++)keep[e[LST_AUTO].sector+k]=1;
            blinks=2;
        }else if(lsdj_save_load(gp_save_data(),gp_save_size())){
            for(uint32_t k=0;k<FTL_N&&k<0x42u;k++)keep[k]=1;   /* v5 slots: 0x97000..0xD9000 */
            blinks=2;
        }
        if(ftl_format(&ftl,gp_save_data(),keep))blinks=0;
    }
    gp_save_clean();   /* what was just loaded is saved */
    for(unsigned i=0;i<blinks;i++){fm1_led_key(SAVE_BUTTON,1);save_wait(4800000u);fm1_led_key(SAVE_BUTTON,0);save_wait(4800000u);}
    if(blinks)songs_loaded=1;
}
/* Buttons, keys and knobs, once per emulated frame (knob taps are timed in
   frames): src/fm1_lsdj_input.h. PLAY=Start, REC=Select. */
/* PLAY's light on the beat (firmware/lsdj_lights.h): song mode flashes, live mode dips. */
#include "lsdj_lights.h"
/* Button lights as last written (-1 unknown): reset after the boot sweep. */
static int play_shown=-1,seq_shown=-1,arp_shown=-1,chan_shown=-1,edit_shown=-1;
static uint8_t dj_beat;   /* LSDj is on a beat (the DJ Play key's flash) */
static void play_light(void){
    int on=1;
    dj_beat=0;
    if(armed_addr&&row_addr){
        uint8_t playing[4],rows[4];
        for(unsigned c=0;c<4;c++){playing[c]=gp_wram_peek((uint16_t)(armed_addr+c));rows[c]=gp_wram_peek((uint16_t)(row_addr+c));}
        on=lsdj_play_light(playing,rows,live_addr&&gp_wram_peek(live_addr));
        dj_beat=(uint8_t)lsdj_play_light(playing,rows,0)&&lsdj_armed();   /* song-mode sense: lit on the beat */
        piano_soft=lsdj_in.mode==LSDJ_KEYS_BUTTONS?lsdj_dpad_soft(playing,rows):0u;   /* D-pad keys take turns */
        {int pc=-1;for(unsigned c=0;c<4u&&pc<0;c++)if(playing[c])pc=(int)c;   /* synced LFOs and gates on LSDj's bars */
         if(pc<0)lsdj_fx_row_stop(&fx);else lsdj_fx_row(&fx,rows[pc]);}
    }
    if(!led_anim&&on!=play_shown){play_shown=on;fm1_led_key(LSDJ_BTN_PLAY,on);}
    int live=live_addr&&gp_wram_peek(live_addr);   /* SEQ lit in live mode */
    if(!led_anim&&live!=seq_shown){seq_shown=live;fm1_led_key(SEQ_BUTTON,live);}
    int ed=edit_open;   /* EDIT lit while the EDIT page is open */
    if(!led_anim&&ed!=edit_shown){edit_shown=ed;fm1_led_key(EDIT_BUTTON,ed);}
    /* the SELECT button lit while it picks the effects channel, or on the EDIT page (it loads the preset at the cursor) */
    int picked=edit_open?1:lsdj_fx_picked(&fxu);
    if(!led_anim&&picked!=chan_shown){chan_shown=picked;fm1_led_key(CHAN_BUTTON,picked);}
}
/* ARP: song row cue (firmware/lsdj_cue.h). */
#include "lsdj_cue.h"
static lsdj_cue_t cue;
static void cue_lsdj_state(uint8_t playing[4],uint8_t rows[4]){
    for(unsigned c=0;c<4;c++){playing[c]=gp_wram_peek((uint16_t)(armed_addr+c));rows[c]=gp_wram_peek((uint16_t)(songrow_addr+c));}
}
static void cue_button(int down){
    uint8_t playing[4],rows[4];cue_lsdj_state(playing,rows);
    if(down){lsdj_cue_open(&cue,playing,rows);bars.until_ms=0;return;}
    if(lsdj_cue_release(&cue)){
        static const char hex[]="0123456789ABCDEF";
        static char l1[20]="CUE ROW 00";l1[8]=hex[cue.row>>4];l1[9]=hex[cue.row&15u];
        lsdj_ov_show(&ov,l1,lsdj_cue_first(playing)<0?"PLAY STARTS HERE":"AT THE NEXT BAR",fm1_ms);
    }
    bars.until_ms=0;
}
/* the song cursor (songcur_addr) back, or onto the start row (lsdj_cue.h) */
static uint8_t cue_cursor(void){return songcur_addr?gp_wram_peek(songcur_addr):0u;}
static void cue_put(uint8_t v){if(songcur_addr)gp_wram_poke(songcur_addr,v);}
/* Stop: every cue cleared; said: "CUE CANCELLED" on screen if one was (returns 1 when it said it) */
static int cue_stop(int said){
    if(!songrow_addr)return 0;
    uint8_t p;int r=lsdj_cue_stop(&cue,cue_cursor(),&p);
    if(r&2)cue_put(p);
    if(!(r&1)||!said)return 0;
    lsdj_ov_show(&ov,"CUE CANCELLED","STOP PRESSED",fm1_ms);
    return 1;
}
/* START about to start LSDj: 1 if it may go now; a start row cued while stopped first goes into the song
   cursor (START waits until LSDj's cursor holds it: the write lands between frames, the press at once) */
static int cue_start_ok(void){
    if(!songcur_addr||!songrow_addr)return 1;
    uint8_t p;int g=lsdj_cue_gate(&cue,cue_cursor(),&p);
    if(g&2)cue_put(p);
    return g&1;
}
/* START by hand (PLAY, the keys, the page's pad) starting LSDj: held back the same way (not SELECT+START,
   nor the sync's own press, already let through) */
static uint32_t cue_buttons(uint32_t b){
    if((b&GP_START)&&!(b&GP_SELECT)&&!(sync_btn&GP_START)&&!lsdj_armed()&&!cue_start_ok())b&=~(uint32_t)GP_START;
    return b;
}
/* EDIT: tempo (firmware/lsdj_tempo.h): the period LSDj counts with, its tempo
   setting and the song's tempo, all at once. */
#include "lsdj_tempo.h"
static lsdj_tempo_t tempo;
static void tempo_apply(unsigned bpm){
    if(songs_incoming())return;   /* (the save memory is the import's) */
    uint16_t p=lsdj_tempo_period(bpm);uint8_t b=lsdj_tempo_byte(bpm);
    uint16_t a[3]={period_addr,(uint16_t)(period_addr+1u),tempo_addr};uint8_t v[3]={(uint8_t)p,(uint8_t)(p>>8),b};
    if(gp_wram_poke_many(a,v,3))gp_save_data()[songtempo_off]=b;
    lsdj_fx_set_bpm(&fx,bpm);
}
static void tempo_button(int down){   /* EDIT: held, the knobs set the tempo (the tap is TAP_KEY's) */
    if(!period_addr)return;
    if(!down){lsdj_tempo_release(&tempo);return;}
    lsdj_tempo_hold(&tempo,lsdj_tempo_of_byte(gp_wram_peek(tempo_addr)));
    bars.until_ms=0;
}
/* The EDIT page, open or closed (0.9.98-dev.9: it stays open; nothing is held). Open, the tempo knobs are on and the
   cursor starts on the preset loaded last. */
static void edit_page(int open){
    if(open==(int)edit_open)return;
    edit_open=(uint8_t)open;tempo.taps=0;
    if(open)plist_cur=(uint8_t)(preset_cur<LSDJ_PRESETS?preset_cur:0u);
    tempo_button(open);
}
static void cue_frame(void){   /* once per emulated frame: the writes, ARP's light */
    if(!songrow_addr)return;
    uint8_t playing[4],rows[4];cue_lsdj_state(playing,rows);
    if(midi_pc_row>=0){   /* MIDI program change n: cue song row n (PC CUE); stopped, the start row again: cancelled */
        static const char hx[]="0123456789ABCDEF";char l[20]="CUE ROW ";
        uint8_t r=(uint8_t)midi_pc_row,p;midi_pc_row=-1;
        l[8]=hx[r>>4];l[9]=hx[r&15u];l[10]=0;
        int c=lsdj_cue_pc(&cue,r,lsdj_cue_first(playing)<0,cue_cursor(),&p);
        if(c&2)cue_put(p);
        lsdj_ov_show(&ov,c?"CUE CANCELLED":"MIDI PROGRAM CHANGE",l,fm1_ms);
    }
    {uint8_t p;if(lsdj_cue_play(&cue,playing,cue_cursor(),&p))cue_put(p);}   /* stopped, started: lsdj_cue.h */
    uint16_t a[8];uint8_t v[8];
    unsigned n=lsdj_cue_frame(&cue,playing,rows,songrow_addr,chainpos_addr,a,v);
    if(n&&!gp_wram_poke_many(a,v,n))cue.pending=1;   /* queue full: next frame */
    int l=lsdj_cue_lit(&cue);
    if(!led_anim&&l!=arp_shown){arp_shown=l;fm1_led_key(ARP_BUTTON,l);}
}
/* SEQ: LSDj's live / song mode from any screen, without touching the player's
   controls: LSDj's mode flag is written (the same switch as its SELECT+LEFT on the
   SONG screen, also while playing: harness/live_poke_check.sh). LSDj only redraws
   its mode display (the S / L in the screen map, the SONG / LIVE title) when the
   screen changes, so until then the firmware covers it with the right one
   (lsdj_ov_mode_cover). */
static uint8_t seq_cover;      /* 0 none, else LSDj's display is stale: 1 song, 2 live */
static uint8_t seq_poked;      /* SEQ wrote the flag; LSDj has not redrawn since */
static uint8_t seq_screen=0xFF;
static void seq_frame(void){   /* once per emulated frame */
    if(!live_addr||!screen_addr){seq_cover=0;return;}
    uint8_t scr=gp_wram_peek(screen_addr),live=gp_wram_peek(live_addr)!=0;
    if(scr!=seq_screen){seq_screen=scr;seq_poked=0;}   /* a new screen: LSDj drew it with the mode as it is */
    seq_cover=seq_poked?(uint8_t)(live?2u:1u):0u;
}
static void seq_button(void){
    if(!live_addr||!screen_addr){lsdj_ov_show(&ov,"SEQ: LIVE/SONG","NEEDS KNOWN LSDJ",fm1_ms);return;}
    int live=!gp_wram_peek(live_addr);
    gp_wram_poke(live_addr,(uint8_t)live);seq_poked=1;
    lsdj_ov_show(&ov,live?"LIVE MODE":"SONG MODE",live?"SEQ: BACK TO SONG":"SEQ: LIVE MODE",fm1_ms);
}
/* 0.9.98-dev.19: this FM-1's number big over the screen while the page asks which FM-1 to install on (IDENTIFY) */
static uint8_t ident_no;static uint32_t ident_until;
static uint8_t restart_kind;static uint32_t restart_p3,restart_rst;   /* 0.9.98-dev.19: why the last run ended (restart_note) */
static int ident_on(void){return ident_no&&(int32_t)(ident_until-fm1_ms)>0;}
/* The mode cover (SEQ), the effects / cue / tempo panel, the settings list and
   messages, in that order, into the picture: CPU0, while CPU1 waits for it to be
   taken (or the emulator on CPU0 is between frames, or stopped). Last, over all of it, the FM-1's number. */
static void native_draw(void){
    lsdj_nat_t n={gp_pixels(),gp_vram(),gp_lcdc(),gp_bgp(),gp_shades()};
    lsdj_nat_mode(&n,seq_cover,seq_screen==4u);   /* (part of LSDj's screen: LSDj's colours) */
    const lsdj_theme_t *ft=lsdj_theme_of(lsdj_feat_theme(&feat,settings.theme));   /* FX THEME (MATCH: LSDj's) */
    n.shade=ft->gb;
    /* the panel, with the knobs' names on LSDj's bottom two rows: the effects
       page's, or the cue / tempo panel's own while ARP / EDIT is held. Only
       while the panel shows: otherwise LSDj's screen is left whole. */
    int panel=lsdj_ov_bars_active(&bars,fm1_ms),own=panel&&(cue.held||tempo.held);
    if(panel){
        char names[4][7];
        if(own)for(unsigned k=0;k<4u;k++){unsigned j=0;for(;j<6u&&bars.label[k][j];j++)names[k][j]=bars.label[k][j];names[k][j]=0;}
        else lsdj_fx_names(&fxu,names);
        lsdj_nat_bars(&n,&bars,ft->accent);
        if(!own){
            lsdj_nat_pagemap(&n,lsdj_fx_list_letters[lsdj_fx_on_master(&fxu)?1:0],lsdj_fx_chmode(&fxu)?lsdj_fx_cur(&fxu)-FX_PAGE_FILTER:lsdj_fx_pos(&fxu));   /* the list's pages, in the screen map */
            if(feat.v[LSDJ_FEAT_BATTERY])lsdj_nat_battery(&n,17,15,battery_level());   /* BATTERY: after "FX" */
        }
        lsdj_nat_names(&n,(const char(*)[7])names,bars.hot,ft->accent);
    }else bars.until_ms=0;
    if(menu.open){
        int hint=menu_hint_until&&(int32_t)(menu_hint_until-fm1_ms)>0;
        char lines[LSDJ_MENU_LINES][20];
        unsigned cnt=lsdj_menu_lines(&menu,&settings,&midi,&feat,hint?menu_hint:0,lines);   /* the open page */
        lsdj_nat_list(&n,(const char(*)[20])lines,cnt,(int)menu.cursor);
        if(feat.v[LSDJ_FEAT_BATTERY])lsdj_nat_battery(&n,17,1,battery_level());   /* BATTERY: the blank row under the title */
        if(menu.page==LSDJ_PAGE_FEAT){   /* the battery's ADC reading (to check BATTERY on a real FM-1): "BATT ADC 0597" */
            char t[14]="BATT ADC ----";int32_t v=batt_last;
            if(v==-1){t[9]='T';t[10]='I';t[11]='M';t[12]='E';}
            else if(v>=0)for(int i=12;i>=9;i--){t[i]=(char)('0'+v%10);v/=10;}
            lsdj_nat_text(&n,0,1,t,13,0);
        }
    }
    if(edit_open&&!menu.open){   /* the EDIT page (0.9.98-dev.9: open until EDIT again): the tempo, how to set it, the
                                    presets (the cursor highlighted, the one loaded last marked *) */
        char lines[17][20],t[20];unsigned c=0,k=0;
        unsigned bpm=tempo.held?tempo.bpm:tempo_addr?lsdj_tempo_of_byte(gp_wram_peek(tempo_addr)):0u;
        for(const char *s="EDIT   TEMPO ";*s;s++)t[k++]=*s;
        if(bpm){if(bpm>=100u)t[k++]=(char)('0'+bpm/100u);t[k++]=(char)('0'+bpm/10u%10u);t[k++]=(char)('0'+bpm%10u);}else t[k++]='-';
        t[k]=0;lsdj_set_put(lines[c++],0,t);
        if(!period_addr)lsdj_set_put(lines[c++],0,"TEMPO: KNOWN LSDJ");
        else if(sync_midi)lsdj_set_put(lines[c++],0,"MIDI CLOCK SETS IT");
        else{lsdj_set_put(lines[c++],0,"K1 TURN: +-1 BPM");lsdj_set_put(lines[c++],0,"K2 TURN: +-10 BPM");lsdj_set_put(lines[c++],0,"F3 TAP IN TIME");}
        lsdj_set_put(lines[c++],0,"");
        lsdj_set_put(lines[c++],0,"KEYS LOAD PRESETS:");
        unsigned first=c-1u;   /* (the entries count from lines[1]) */
        for(unsigned i=0;i<LSDJ_PRESETS;i++){lsdj_preset_line(presets_page,i,lines[c]);if(i==preset_cur)lines[c][5]='*';c++;}
        lsdj_set_put(lines[c++],0,"SEL LOAD  SAVE KEEP");
        lsdj_nat_list(&n,(const char(*)[20])lines,c,(int)(first+plist_cur));
    }
    if(lsdj_ov_active(&ov,fm1_ms))lsdj_nat_message(&n,ov.line[0],ov.line[1]);
    else ov.until_ms=0;
    if(ident_on())lsdj_nat_big(&n,ident_no);else ident_no=0;
}
/* The boot sweep (Felucca's power-on light animation, started when the startup
   screen ends: LSDj is ready) owns the LEDs while it runs; then every light of
   ours is written again. Returns 1 while it runs. */
static int leds_busy(void){
    static int was;
    int on=fm1_led_anim_on();
    if(was&&!on){lights_valid=0;lights_held_prev=UINT32_MAX;play_shown=seq_shown=arp_shown=chan_shown=edit_shown=-1;fm1_led_key(LSDJ_BTN_REC,1);}
    was=on;
    return on;
}
/* The web page's link (firmware/lsdj_link.h): songs, settings, effects, themes
   and live data over USB-MIDI. Never firmware. Flash writes park CPU1 first, as
   SAVE does. */
#include "lsdj_link.h"
static lsdj_link_t link_state;
static int songs_incoming(void){return link_state.importing;}
static uint8_t *lk_save(void){return gp_save_data();}
static uint32_t lk_size(void){return gp_save_size();}
static void lk_pause(int on){gp_pause((uint32_t)on);}
static int lk_store(void){
    if(!recovery_flash_ok||play_save)return -1;
    video_hold();ov_now_text("SAVING SONGS","KEEP USB IN");int rc=ftl_save_now(&ftl,gp_save_data());video_release();
    if(rc>=0)gp_save_clean();
    return rc<0?-1:0;
}
static int lk_load(void){return ftl_boot(&ftl,gp_save_data())?0:-1;}
/* the import done: LSDj starts again on the new songs; says which one is open (the save's open slot, its name) */
static void lk_reset(void){
    gp_reset();
    const uint8_t *sv=gp_save_data();
    char l2[20]="OPEN: ";unsigned n=6,slot=sv[0x8140];
    if(slot<32u){for(unsigned i=0;i<8u&&sv[0x8000u+slot*8u+i];i++){uint8_t c=sv[0x8000u+slot*8u+i];l2[n++]=(char)(c>=32u&&c<127u?c:'?');}}
    else{const char *t="NO SONG OPEN";for(n=0;t[n];n++)l2[n]=t[n];}
    l2[n]=0;
    lsdj_ov_show(&ov,"SONGS LOADED",l2,fm1_ms);
}
/* Songs coming from the web page (IMPORT): LSDj is paused, so nothing drew the screen and it froze. Now it says
   RECEIVING and a 10-step bar (LSDj's letters have no %), redrawn when the bar grows and at most 5 times a
   second (each draw waits for the display: ~16 ms). */
#if LSDJ_SLOT_PROBE
/* SLOT TEST build (spare FM-1 only). Question: does the FM-1's boot code check the app area against its
   CRC at power-on? If not, the web page can later rewrite the LSDj slot alone instead of the whole firmware.
   Hold SAVE 3 s: one bit of the slot's unused last byte is cleared in flash (a 1-byte program, never an
   erase; the app's CRC then no longer matches). Turn the FM-1 off and on:
     it starts and says SLOT TEST CHANGED / IT STILL STARTS: the boot code does not check;
     it does not start: it checks (recover: Install from the web page if update mode comes up, else the
     unbrick tool). Installing any normal firmware afterwards rewrites that sector back. */
static uint32_t slot_probe_flash(void){   /* the slot's last byte in flash: XIP 0x02000000 = flash 0x4000 */
    return (uint32_t)(uintptr_t)(cartridge+CART_SLOT_CAPACITY-1u)-0x02000000u+0x4000u;
}
/* (an unused byte reads 0xFF; read through volatile: cartridge[] is a const array of 0xFF in the source, so a plain
   read is folded to 0xFF by the compiler and never sees the flash) */
static int slot_probe_changed(void){return *(volatile const uint8_t*)&cartridge[CART_SLOT_CAPACITY-1u]!=0xFFu;}
static void slot_probe_hex(char *d,uint8_t v){static const char h[]="0123456789ABCDEF";d[0]=h[v>>4];d[1]=h[v&15u];}
/* the byte as stored in flash (scrambled by the chip key), read straight from flash: what the screen shows,
   so a restart shows the written value whatever the XIP view says */
static int slot_probe_raw(uint8_t *v){
    uint32_t off=slot_probe_flash();
    if(off<0x4120u||off>=0x93000u)return -1;
    video_hold();int rc=ota_fread(off,v,1u);video_release();
    return rc;
}
static uint8_t slot_probe_done;   /* written since this start (the slot as read through XIP may not show it until a restart) */
static void slot_probe_write(void){
    uint32_t off=slot_probe_flash();
    if(!recovery_flash_ok||!cart_slot_valid||cart_slot.total>=CART_SLOT_CAPACITY||off<0x4120u||off>=0x93000u){
        lsdj_ov_show(&ov,"SLOT TEST","NOT POSSIBLE HERE",fm1_ms);return;
    }
    if(slot_probe_done||slot_probe_changed()){lsdj_ov_show(&ov,"SLOT TEST: DONE","TURN OFF AND ON",fm1_ms);ov.until_ms=(fm1_ms+6000u)|1u;return;}
    uint8_t raw=0,want=0,back=0;
    video_hold();
    int rc=ota_fread(off,&raw,1u);
    if(!rc&&!raw)rc=-21;   /* no bit left to clear */
    if(!rc){
        want=(uint8_t)(raw&(raw-1u));   /* the lowest set bit cleared */
        slot_probe_lo=off;rc=fl_write(off,&want,1u);slot_probe_lo=0;
        if(!rc)rc=ota_fread(off,&back,1u);
        if(!rc&&back!=want)rc=-20;
    }
    video_release();
    if(rc){lsdj_ov_show(&ov,"SLOT TEST FAILED","NOTHING CHANGED",fm1_ms);ov.until_ms=(fm1_ms+6000u)|1u;return;}
    slot_probe_done=1u;
    char l2[20]="BYTE xx TO xx";
    slot_probe_hex(l2+5,raw);slot_probe_hex(l2+11,want);
    lsdj_ov_show(&ov,"SLOT TEST WRITTEN",l2,fm1_ms);   /* e.g. BYTE 03 TO 02 */
    ov.until_ms=(fm1_ms+15000u)|1u;
}
/* what the test build says a few seconds after it starts, and again every 20 s for a minute */
static void slot_probe_status(void){
    static uint32_t next=5000u;
    if(fm1_ms<next||next>65000u)return;
    next+=20000u;
    uint8_t v=0;char l1[20]="SLOT TEST: BYTE xx";
    if(slot_probe_raw(&v)){l1[16]='?';l1[17]='?';}else slot_probe_hex(l1+16,v);
    /* changed before this start: the FM-1 started with the changed slot, the answer (its boot code does not check) */
    if(!slot_probe_done&&slot_probe_changed())lsdj_ov_show(&ov,"SLOT TEST CHANGED","IT STILL STARTS",fm1_ms);
    else lsdj_ov_show(&ov,l1,slot_probe_done?"WRITTEN. OFF + ON":"HOLD SAVE 3 S",fm1_ms);
    ov.until_ms=(fm1_ms+6000u)|1u;
}
#endif
/* Songs coming in from the web page (0.9.98-dev.9, Colin: a loading bar on the FM-1): the install screen
   (upd_screen.h) with its own title, LOADING SONGS, the bar and the percentage, DO NOT UNPLUG. LSDj is paused
   meanwhile (lsdj_link.h BEGIN), so nothing else draws; when it ends the screen goes black (LSDj draws only the
   middle rows) and LSDj's next picture takes over, as after the swap (swap_resume). */
static void import_screen(void){
    static int32_t shown=-1;static uint32_t at;
    if(!save_display_ok)return;
    if(!link_state.importing){
        if(shown<0)return;
        shown=-1;
        video_hold();while(!display_ready())fm1_wdt_feed();
        lcd_fill(0,0,240,240,0);upd_status_shown=0;
        upd_title1="INSTALLING";upd_title2="FIRMWARE";upd_keep1="KEEP THE USB CABLE IN AND THE";upd_keep2="INSTALLER OPEN UNTIL IT SAYS DONE";
        video_release();
        return;
    }
    int32_t pct=link_state.len?(int32_t)((uint64_t)link_state.next*100u/link_state.len):0;
    if(pct==shown||(shown>=0&&fm1_ms-at<100u))return;
    video_hold();while(!display_ready())fm1_wdt_feed();
    if(shown<0){
        upd_title1="LOADING";upd_title2="SONGS";upd_keep1="KEEP THE USB CABLE IN AND THE";upd_keep2="WEB PAGE OPEN UNTIL IT SAYS DONE";
        upd_status_shown=0;
    }
    upd_screen("FROM THE WEB PAGE",pct,0);
    video_release();
    shown=pct;at=fm1_ms;
}
static const char *lk_firmware(void){return BURRITO_VERSION;}   /* "FM-1_992": the package identity is longer */
static const char *lk_title(void){return gp_title();}
static int lk_live_known(void){return cursor_addr!=0;}
/* The battery as bars of 3 (Felucca's thresholds 531 / 561 / 591), +0x80 on USB power (a host
   that configured us and is awake: the FM-1 has no charge line); 0xFF before a reading. */
static unsigned battery_level(void){
    if(!batt_raw)return 0xFFu;
    unsigned bars=batt_raw>=591?3u:batt_raw>=561?2u:batt_raw>=531?1u:0u;
    return usb.config&&!usb.suspended?0x80u|bars:bars;
}
static uint32_t lk_settings_get(void){return lsdj_set_pack(&settings);}
static int lk_settings_set(uint32_t v){
    lsdj_settings_t t;if(!lsdj_set_unpack(v,&t))return 0;
    settings=t;settings_apply();return 1;
}
static void lk_fx_get(uint32_t w[LSDJ_LINK_FX_WORDS]){   /* the first 17 words (the reverb is not on the web page yet) */
    uint32_t a[LSDJ_FX_WORDS];lsdj_fx_pack(&fx,&fxu,a);for(unsigned i=0;i<LSDJ_LINK_FX_WORDS;i++)w[i]=a[i];
}
/* Older clients retain effects they cannot expose; saved page numbers migrate. */
static int lk_fx_set(const uint32_t *w,unsigned n){
    return lsdj_fx_set_words(&fx,&fxu,w,n);
}
typedef char lk_fx_words_ok[LSDJ_LINK_FX_WORDS==LSDJ_FX_WORDS_LINK&&LSDJ_LINK_FX_WORDS_OLD==LSDJ_FX_WORDS_OLD?1:-1];
static void lk_theme_get(uint16_t c[8]){lsdj_theme_to8(&lsdj_theme_custom,c);}
static void lk_theme_set(const uint16_t c[8]){lsdj_theme_from8(&lsdj_theme_custom,c);if(settings.theme==LSDJ_THEME_CUSTOM)settings_apply();}
static int theme_store(void){   /* the custom theme: records 12..15, only what changed */
    uint16_t c[8];lsdj_theme_to8(&lsdj_theme_custom,c);
    for(unsigned i=0;i<4u;i++){
        if(rec_put(12u+i,(uint32_t)c[2*i]|(uint32_t)c[2*i+1]<<16))return -1;
    }
    return 0;
}
static void theme_load(void){
    uint16_t c[8];
    for(unsigned i=0;i<4u;i++){unsigned r=12u+i;if(!((ftl.rec_has>>r)&1u))return;c[2*i]=(uint16_t)ftl.rec[r];c[2*i+1]=(uint16_t)(ftl.rec[r]>>16);}
    lsdj_theme_from8(&lsdj_theme_custom,c);
}
static int lk_store_config(void){
    if(!recovery_flash_ok||play_save)return -1;
    video_hold();
    int rc=settings_store();
    if(!rc&&fx_store()<0)rc=-1;
    if(!rc)rc=theme_store();
    video_release();
    return rc?-1:0;
}
static void lk_live(lsdj_link_live_t *l){
    l->page=(uint8_t)lsdj_fx_cur(&fxu);{unsigned t=lsdj_fx_eff(&fxu);l->cursor_ch=t<4u?(uint8_t)t:0xFFu;}   /* the effects' channel (SELECT button pick or cursor) */l->bpm=fx.bpm;l->mute=fx.mute;l->freeze=fx.freeze;l->playing=0;
    l->battery=(uint8_t)battery_level();
    if(armed_addr)for(unsigned c=0;c<4;c++)if(gp_wram_peek((uint16_t)(armed_addr+c)))l->playing|=(uint8_t)(1u<<c);
    /* 0.9.98, for the DJ layout: where each channel is, SYNC, SEQ and the page volume (0xFF unknown) */
    for(unsigned c=0;c<4;c++){
        if(row_addr)l->rows[c]=gp_wram_peek((uint16_t)(row_addr+c));
        if(songrow_addr)l->songrows[c]=gp_wram_peek((uint16_t)(songrow_addr+c));
        /* 0.9.98-dev.12, Next chain: the place in the chain (C17C..) and the chain's phrases, counted in the song's
           chain table (LSDj's song memory: chain phrases at chaintab_off, 0x2080 on 9.3.9, 16 a chain, FF empty; the song
           rows at songtab_off, 0x1290) */
        if(chainpos_addr)l->chainpos[c]=gp_wram_peek((uint16_t)(chainpos_addr+c));
        if(songtab_off&&songrow_addr&&chaintab_off){
            const uint8_t *song=gp_save_data();
            uint8_t ch=song[songtab_off+gp_wram_peek((uint16_t)(songrow_addr+c))*4u+c];
            if(ch<0x80u){unsigned k=0;while(k<16u&&song[chaintab_off+ch*16u+k]!=0xFFu)k++;if(k)l->chainlen[c]=(uint8_t)k;}
        }
    }
    if(sync_off)l->sync=gp_save_data()[sync_off];
    if(live_addr)l->seq=gp_wram_peek(live_addr)!=0u;
#if !GB_SMK37
    l->level=page_level;
#endif
}
/* 0.9.98: the web page's DJ layout. VOLUME_SET: the FM-1's volume times the knob (its crossfader without a
   MIDI mixer); SEQ_SET: live / song mode as the SEQ button (no message: the page shows it); SONG_ROWS: the
   song table, for the page's row map. */
#if GB_SMK37
static int lk_volume_set(uint8_t v){(void)v;return 0;}
#else
static int lk_volume_set(uint8_t v){if(v>127u)return 0;page_level=v;return 1;}
#endif
static int lk_seq_set(uint8_t live){
    if(!live_addr||!screen_addr||live>1u)return 0;
    if((gp_wram_peek(live_addr)!=0u)!=live){gp_wram_poke(live_addr,live);seq_poked=1;}
    return 1;
}
static int lk_song_rows(uint8_t row,uint8_t out[4u*LSDJ_LINK_SONG_WINDOW]){
    if(!songtab_off)return 0;
    const uint8_t *song=gp_save_data()+songtab_off;
    for(unsigned i=0;i<LSDJ_LINK_SONG_WINDOW;i++)for(unsigned c=0;c<4u;c++){
        unsigned r=row+i;out[i*4u+c]=r<256u?song[r*4u+c]:0xFFu;
    }
    return 1;
}
/* SYNC_SET (0.9.98-dev.2): the web page sets LSDj's SYNC to KEYBD (the FM-1 then switches it to MIDI for
   a MIDI Start and back after Stop, and START by hand plays) or MIDI; only while LSDj is stopped and no
   MIDI Start runs it. OFF -> KEYBD as note mode does (keybd_sync: the interrupt bits too); MIDI or LSDJ ->
   KEYBD and KEYBD -> MIDI as auto SYNC does (sync_set). */
static int lk_sync_set(uint8_t v){
    if(!sync_off||!synclive_addr||!syncmask_addr||(v!=LSDJ_SYNC_KEYBD&&v!=LSDJ_SYNC_MIDI))return 0;
    if(songs_incoming()||lsdj_armed()||msync.running||msync.want!=LSDJ_MS_NONE)return -1;   /* (status 2: later) */
    uint8_t s=gp_save_data()[sync_off];
    if(s==v){sync_auto=0;return 1;}
    if(s==0u&&keybd_sync()!=1)return 0;   /* (OFF: KEYBD's interrupt bits first) */
    if(v!=LSDJ_SYNC_KEYBD||gp_save_data()[sync_off]!=LSDJ_SYNC_KEYBD){if(!sync_set(v))return 0;}
    sync_auto=0;
    if(v==LSDJ_SYNC_KEYBD)kb_octave=-1;
    return 1;
}
static uint32_t lk_midi_get(void){return lsdj_midi_pack(&midi);}
static int lk_midi_set(uint32_t v){lsdj_midi_t t;if(!lsdj_midi_unpack(v,&t))return 0;midi=t;return 1;}
static const volatile uint8_t *lk_cartridge(uint32_t *len){
#ifdef CART_SLOT_CAPACITY
    *len=cart_slot.total;   /* header (+ v2 bank table) + data, as the page reads it back */
    if(cart_slot_valid&&cart_slot.stored_banks&&*len<=CART_SLOT_CAPACITY)return cartridge;
#else
    (void)len;
#endif
    return 0;
}
/* READ_STREAM (0.9.98-dev.14): the songs (what 0) or the slot as CART_READ reads it (what 1) sent by themselves from
   the USB interrupt (firmware/lsdj_stream.h; usb.c FELUCCA_SX_STREAM): a grab took ~1m45s at 128 bytes a request. */
#include "lsdj_stream.h"
static lsdj_stream_t sxs;
static int sx_stream_next(uint32_t *pkt,int yield){return lsdj_stream_next(&sxs,pkt,yield);}
static int sx_stream_mid(void){return lsdj_stream_mid(&sxs);}
static int sx_stream_on(void){return lsdj_stream_busy(&sxs);}
static int lk_stream(uint8_t what,uint32_t off,uint32_t len,uint32_t *total){
    const volatile uint8_t *src;uint32_t size=0;
    if(what==0u){src=gp_save_data();size=lk_size();}
    else{src=lk_cartridge(&size);if(!src)return 0;}
    *total=size;
    if(off>size)return 0;
    uint32_t end=len>size-off?size:off+len;
    uint32_t f=irq_save();lsdj_stream_start(&sxs,src,what,off,len?end:off);irq_restore(f);
    return 1;
}
static int lk_mute_set(uint8_t m,uint8_t f){   /* the web page's channel buttons and freeze */
    if(m>15u||f>1u)return 0;
    uint8_t before=fx.mute;fx.mute=m;fx.freeze=f;mute_mark(before,2);lsdj_fx_update(&fx);return 1;
}
static uint32_t lk_feat_get(void){return lsdj_feat_pack(&feat);}
static uint32_t lk_rv_get(void){return lsdj_fx_rv_word(&fx);}
/* 0.9.97: a game controller on the web page (PAD_SET): its buttons until LSDJ_LINK_PAD_MS after the last message */
static uint8_t link_pad;static uint32_t link_pad_ms;
static void lk_pad_set(uint8_t b){link_pad=b;link_pad_ms=fm1_ms;}
static uint32_t link_pad_now(void){return link_pad&&fm1_ms-link_pad_ms<LSDJ_LINK_PAD_MS?link_pad:0u;}
/* 0.9.98-dev.4: the DJ layout's deck on OP4 / OP5 (DJ_DECK; DJ_KEY goes from dj_frame) */
static int lk_dj_deck(uint8_t state){return lsdj_dj_set(&djk,state,fm1_ms);}
/* 0.9.98-dev.19, IDENTIFY: its number big for seconds (0: away now; native_draw draws it). The number and time are
   checked by lsdj_link.h (1..99, 0..60); not again here: 80 bytes over a sector cost the LSDj slot 4 KiB. */
static int lk_identify(uint8_t no,uint8_t s){ident_no=s?no:0;ident_until=(fm1_ms+s*1000u)|1u;return 1;}
/* 0.9.98-dev.19, RESTART: why the last run ended (restart_note) and the crash record */
static uint8_t lk_restart(uint32_t v[LSDJ_LINK_RESTART_WORDS]){
    const fm1_crash_t *c=&fm1_crash;int rec=c->magic==FM1_CRASH_MAGIC;
    /* (0.9.98-dev.21: CPU1 now, the 12th word: emulating, why not (the CPU meter's R), the start try, the guard) */
    uint32_t cpu1=(uint32_t)(core1_emu&&video_online)|(video_retire_reason&255u)<<8|(video_launch_ready&255u)<<16|(video_guard.barred?1u:0u)<<24|
        (fm1_p33_timeouts<127u?fm1_p33_timeouts:127u)<<25;   /* (bits 25-31: P33 timeouts since boot, at most 127) */
    const uint32_t w[LSDJ_LINK_RESTART_WORDS]={rec?c->count:0u,c->vec,c->pc,c->rets,c->emu,c->dbg,c->sp,c->uptime_ms,rec?c->early:0u,restart_p3,restart_rst,cpu1};
    for(unsigned i=0;i<LSDJ_LINK_RESTART_WORDS;i++)v[i]=rec||i>=9u?w[i]:0u;
    return restart_kind;
}
#if LSDJ_DEV   /* 0.9.98-dev.20, TEST: dev builds only (0 hang, 1 core reset, 2 chip reset: the main loop does it) */
static void lk_test(uint8_t what){if(!what)hang_test=1;else restart_test=what;}
#define LK_TEST lk_test
#else
#define LK_TEST 0
#endif
static int lk_rv_set(uint32_t v){return lsdj_fx_rv_set(&fx,v);}
static uint32_t lk_rvs_get(void){return lsdj_fx_rvs_word(&fx);}
static int lk_rvs_set(uint32_t v){return lsdj_fx_rvs_set(&fx,v);}
static int lk_feat_set(uint32_t v){lsdj_feat_t t;if(!lsdj_feat_unpack(v,&t))return 0;feat=t;feat_apply();return 1;}
/* The screen mirror: the LCD image as last shown (lsdj_link_px reads the 160x144 picture back
   from it). FM-1_987: not gp_pixels(), which CPU1 draws the next frame into as soon as the
   panels are scaled out (the page then saw torn or missing panels). The main loop writes
   `screen` only right before display_frame, and SCREEN_SYNC / screen_stream run in it too. */
static const volatile uint16_t *lk_screen(uint32_t *shown){*shown=display_count;return screen;}
/* SCREEN_SYNC (USB only): the bands asked for go from the main loop, several rows a pass
   (FM-1_988; 985-987 sent one row a pass, after the SysEx ring had emptied, so a pass's length set
   the rate). A row goes only if it fits the ring whole (ota_wire_send never waits) and the ring holds
   at most SCR_QUEUE packets; while MIDI out (notes, clock) waits, rows wait for the ring to empty so
   it goes first (USB sends SysEx before MIDI): a note waits at most what is queued, ~4 ms. */
static uint32_t scr_bands;static uint8_t scr_row,scr_round;
static uint8_t link_reply[LSDJ_LINK_REPLY_MAX];
/* FM-1_990: with the push bit the FM-1 also sends each new picture by itself (screen_push). */
static lsdj_link_push_t scr_push;
static int lk_screen_stream(uint32_t bands,uint8_t round){
    if(bands&LSDJ_LINK_PUSH)lsdj_link_push_start(&scr_push,screen,display_count,round,fm1_ms);else scr_push.on=0;
    scr_bands=bands&~LSDJ_LINK_PUSH;scr_row=0;scr_round=round;return 1;
}
#define SCR_QUEUE 24u   /* packets: two USB transfers' worth */
static void screen_stream(void){
    for(unsigned rows=0;scr_bands&&rows<12u;rows++){
        uint32_t queued=so_w-so_r;
        if(queued>SCR_QUEUE||(queued&&mo_w!=mo_r))return;
        while(scr_row<LSDJ_LINK_SCREEN_H&&!(scr_bands>>(scr_row>>3)&1u))scr_row++;
        if(scr_row>=LSDJ_LINK_SCREEN_H){scr_bands=0;return;}
        unsigned y=scr_row;
        uint32_t n=lsdj_link_screen_pixels(screen,y,scr_round,link_reply);
        if(queued+(n+2u)/3u>SXQ)return;   /* not whole: next pass (the row is built again then) */
        scr_row++;
        if(!(scr_row&7u))scr_bands&=~(1u<<(y>>3));
        if(ota_wire_send(link_reply,n)){scr_bands=0;return;}   /* USB gone */
    }
}
/* Pushing: a new picture on the LCD, the last one's rows all out: its SCREEN_FRAME, then its rows. */
static void screen_push(void){
    if(!scr_push.on||scr_bands||scr_push.shown==display_count)return;
    uint32_t queued=so_w-so_r,bands;uint16_t h[LSDJ_LINK_SCREEN_BANDS];
    if(queued>SCR_QUEUE||(queued&&mo_w!=mo_r)||queued+22u>SXQ)return;   /* a SCREEN_FRAME: 58 bytes */
    uint32_t n=lsdj_link_push_frame(&scr_push,screen,display_count,fm1_ms,link_reply,&bands,h);
    if(!n)return;
    if(ota_wire_send(link_reply,n)){scr_push.on=0;return;}   /* USB gone */
    scr_round=lsdj_link_push_sent(&scr_push,display_count,bands,h);scr_bands=bands;scr_row=0;
}
/* ---------- presets (0.9.98-dev.6, firmware/lsdj_presets.h) ---------- */
static void preset_capture(lsdj_preset_t *p){   /* everything now */
    lsdj_fx_pack(&fx,&fxu,p->fx);p->settings=lsdj_set_pack(&settings);p->midi=lsdj_midi_pack(&midi);p->feat=lsdj_feat_pack(&feat);
    lsdj_theme_to8(&lsdj_theme_custom,p->theme);
}
/* Every value of a preset is valid (else none of it is applied); its effects into *to. */
static int preset_check(const lsdj_preset_t *p,lsdj_fx_t *to,lsdj_settings_t *st,lsdj_midi_t *m,lsdj_feat_t *f){
    lsdj_fx_ui_t u=fxu;*to=fx;to->rv=0;   /* a copy (its update must not clear the live reverb) */
    return lsdj_fx_unpack_n(to,&u,p->fx,LSDJ_FX_WORDS)&&lsdj_set_unpack(p->settings,st)&&lsdj_midi_unpack(p->midi,m)&&
           lsdj_feat_unpack(p->feat,f);
}
static void preset_title(char l[20],const char *t,unsigned i){unsigned n=lsdj_set_put(l,0,t);l[n++]=(char)('1'+i);l[n]=0;}
/* The settings, MIDI options, switches and custom theme into their records, as the menu keeps them (only what
   changed: a 16-byte record each, the emulator parked meanwhile; after a save that runs). */
static void preset_keep_config(void){
    if(!recovery_flash_ok)return;
    if(play_save){settings_pending=1;return;}
    video_hold();(void)settings_store();(void)theme_store();video_release();
}
/* Slot i: everything as it was kept, the effects gliding over PRESET GLIDE. 1 loaded, 0 not valid, -1 empty. */
static int preset_load(unsigned i){
    static char l1[20],l2[20];
    lsdj_preset_t p;lsdj_fx_t to;lsdj_settings_t st;lsdj_midi_t m;lsdj_feat_t f;
    preset_title(l1,"PRESET ",i);
    if(!lsdj_preset_get(presets_page,i,&p)){lsdj_ov_show(&ov,l1,"EMPTY",fm1_ms);return -1;}
    if(!preset_check(&p,&to,&st,&m,&f)){lsdj_ov_show(&ov,l1,"CANNOT LOAD",fm1_ms);return 0;}
    settings=st;midi=m;lsdj_preset_feat_merge(&feat,&f);
    lsdj_theme_from8(&lsdj_theme_custom,p.theme);
    settings_apply();feat_apply();
    lsdj_glide_start(&glide,&fx.p,&to.p,fm1_ms,lsdj_feat_glide_ms[feat.v[LSDJ_FEAT_GLIDE]&7u]);lsdj_fx_update(&fx);
    preset_cur=(uint8_t)i;presets_page[5]=(uint8_t)i;   /* (kept in flash with the page's next save) */
    preset_keep_config();
    lsdj_set_put(l2,0,p.name);lsdj_ov_show(&ov,l1,l2,fm1_ms);
    return 1;
}
/* Everything now into slot i, named (12 characters), or keeping its name. */
static void preset_save(unsigned i,const char *name){
    static char l1[20],l2[20];
    lsdj_preset_t p,old;preset_capture(&p);
    if(name){for(unsigned k=0;k<LSDJ_PRESET_NAME;k++)p.name[k]=name[k];p.name[LSDJ_PRESET_NAME]=0;}
    else if(lsdj_preset_get(presets_page,i,&old))for(unsigned k=0;k<=LSDJ_PRESET_NAME;k++)p.name[k]=old.name[k];
    else lsdj_preset_default_name(i,p.name);
    lsdj_preset_put(presets_page,i,&p);lsdj_presets_set_current(presets_page,i);preset_cur=(uint8_t)i;presets_dirty=1;
    lsdj_preset_get(presets_page,i,&p);
    preset_title(l1,"SAVED TO ",i);lsdj_set_put(l2,0,p.name);lsdj_ov_show(&ov,l1,l2,fm1_ms);
}
/* The page into flash once it changed: with LSDj stopped at once (erases allowed, as SAVE), while it plays a step
   a frame without erases (as AUTOSAVE); if that needs an erase first, again in 10 s (or once stopped). */
static uint32_t presets_wait;
static void presets_poll(void){
    if(!presets_dirty||play_save||!recovery_flash_ok||link_state.importing)return;
    if(presets_wait&&(int32_t)(presets_wait-fm1_ms)>0)return;
    presets_wait=0;
    if(!ftl_block_changed(&ftl,gp_save_data(),FTL_XBLOCK)){presets_dirty=0;return;}
    int full=(ftl.retry&~FTL_BIT(FTL_XBLOCK))!=0;   /* a failed song save first: all of it, as AUTOSAVE */
    if(gp_silent_frames()>=SILENT_FRAMES){
        if(full){stopped_save(1);return;}
        video_hold();int rc=ftl_save_mask(&ftl,gp_save_data(),FTL_BIT(FTL_XBLOCK));video_release();
        if(rc<0){presets_wait=(fm1_ms+10000u)|1u;lsdj_ov_show(&ov,"PRESETS NOT KEPT","TRYING AGAIN",fm1_ms);}
        return;
    }
    if(!play_save_start_mask(1,full?~(ftl_mask_t)0:FTL_BIT(FTL_XBLOCK)))presets_wait=(fm1_ms+10000u)|1u;
}
/* While the EDIT page is open (Colin, 0.9.98-dev.9): the slots' keys, a kept preset full, an empty slot dim, the
   selected one (the cursor: the SELECT knob's, or the key pressed last) blinking. */
static void presets_lights(void){
    uint32_t lit=0,soft=0;
    for(unsigned i=0;i<LSDJ_PRESETS;i++){
        uint32_t b=1u<<lsdj_preset_key[i];
        if(i==plist_cur){if((fm1_ms/200u)&1u)lit|=b;}
        else if(lsdj_preset_used(presets_page,i))lit|=b;
        else soft|=b;
    }
    if(edit_open&&tempo.held&&!sync_midi){   /* the tap key, blinking on the beat */
        int on=lsdj_armed()?(int)dj_beat:(int)(((uint64_t)fm1_ms*tempo.bpm)%60000u<15000u);
        if(on)lit|=1u<<TAP_KEY;else soft|=1u<<TAP_KEY;
    }
    lights_held_prev=UINT32_MAX;piano_set2(lit,soft);
}
/* the web page's PRESET_* (lsdj_link.h) */
static const uint8_t *lk_presets(void){return presets_page;}
static int lk_preset_put(uint8_t i,const uint8_t b[LSDJ_LINK_PRESET]){
    if(i>=LSDJ_PRESETS||!lsdj_preset_raw_ok(b))return 0;
    if(b[LSDJ_PS_USED]==LSDJ_PRESET_USED){   /* its values too, as a load would check them */
        lsdj_preset_t p;lsdj_fx_t to;lsdj_settings_t st;lsdj_midi_t m;lsdj_feat_t f;
        lsdj_preset_read(b,&p);if(!preset_check(&p,&to,&st,&m,&f))return 0;
    }
    lsdj_preset_put_raw(presets_page,i,b);if(preset_cur==i&&!lsdj_preset_used(presets_page,i))preset_cur=LSDJ_PRESET_NONE;
    presets_dirty=1;return 1;
}
static int lk_preset_load(uint8_t i){return i<LSDJ_PRESETS?preset_load(i):0;}
static int lk_preset_save(uint8_t i,const char *name){if(i>=LSDJ_PRESETS)return 0;preset_save(i,name);return 1;}
#if defined(CART_SLOT_CAPACITY)
#include "lsdj_swap_fm1.h"   /* the fast LSDj swap (0.9.98-dev.6) */
static int lk_slot(unsigned op,const uint8_t *d,uint32_t dn,uint32_t now,uint8_t *out,uint32_t *on){
    return lsdj_swap_op(&swap,&swap_io,op,d,dn,now,out,on);
}
#define LK_SLOT lk_slot,swap_busy
#else
#define LK_SLOT 0,0
#endif
static const lsdj_link_io_t link_io={lk_save,lk_size,lk_pause,lk_store,lk_load,lk_reset,lk_firmware,lk_title,lk_live_known,
    lk_settings_get,lk_settings_set,lk_fx_get,lk_fx_set,lk_theme_get,lk_theme_set,lk_store_config,lk_live,
    lk_midi_get,lk_midi_set,lk_cartridge,lk_mute_set,lk_feat_get,lk_feat_set,lk_screen,lk_screen_stream,lk_rv_get,lk_rv_set,
    lk_pad_set,lk_rvs_get,lk_rvs_set,lk_volume_set,lk_seq_set,lk_song_rows,lk_sync_set,lk_dj_deck,
    lk_presets,lk_preset_put,lk_preset_load,lk_preset_save,LK_SLOT,lk_stream,lk_identify,lk_restart,LK_TEST};
static int app_sysex_frame(const uint8_t *frame,uint32_t size){
#if defined(CART_SLOT_CAPACITY)
    /* no LSDj (the add-your-LSDj screen): only the swap's ops, so the page can put LSDj there */
    if(!lsdj_link_match(frame,size)||(lsdj_absent&&!lsdj_link_slot_frame(frame,size)))return 0;
#else
    if(lsdj_absent||!lsdj_link_match(frame,size))return 0;
#endif
    hang_op=0x100u|frame[3];   /* (the hang recorder: the op being handled, its tag bit with it) */
    ota_wire_send(link_reply,lsdj_link_handle(&link_state,&link_io,frame,size,fm1_ms,link_reply));
    hang_op=0;
    return 1;
}
/* After KNOB 1-4 turned (steps = clicks per knob): MUTE POPUP when a turned effect plays
   on muted channels only; CC OUT sends each turned effect's CC (lsdj_midi.h numbers), per
   channel on the CC FX channels (PU1's: CC FX, or 1 when it is off). */
static void fx_knobs_after(const int32_t st[4]){
    for(unsigned k=0;k<4u;k++){
        unsigned ch=fx_knob_chans(k),e=lsdj_fx_knob(&fxu,k),cc=lsdj_midi_cc_of_fxk(e),base=midi.cc?midi.cc-1u:0u;
        if(!st[k])continue;
        if(feat.v[LSDJ_FEAT_MUTEPOP]&&ch&&(ch&fx.mute)==ch){
            mute_pop_ch=0;while(!((ch>>mute_pop_ch)&1u))mute_pop_ch++;
            mute_pop_until=(fm1_ms+lsdj_ov_ms)|1u;
        }
        if(!feat.v[LSDJ_FEAT_CCOUT]||!cc)continue;
        for(unsigned c=0;c<4u;c++){
            if(ch?!((ch>>c)&1u):c)continue;   /* a shared effect: once, on PU1's channel */
            lsdj_fx_ui_t t=fxu;t.target=(uint8_t)c;
            uint32_t v=lsdj_midi_cc_value(&fx,e,lsdj_fxk_get(&fx,&t,e)),f;
            if(v>127u)continue;   /* a 0.9.98 type: no CC value */
            f=irq_save();
            midi_out_event(0x0Bu|(0xB0u|(base+c))<<8|cc<<16|v<<24);irq_restore(f);
        }
    }
}
/* PAGE LIGHTS: one black key, at the soft level, shows the page: C#4 D#4 F#4 G#4 A#4 C#5 (black keys
   no Game Boy button uses) = the FX page 1..6 while the effects panel shows, else LSDj's screen
   SONG CHAIN PHRASE INSTR TABLE GROOVE (LSDj 9.3.9's screen byte, harness/screen_map.sh; other
   screens and unknown LSDj versions: none). */
static uint32_t page_light(void){
    static const uint8_t key[6]={8,10,13,15,17,20},scr[6]={4,3,1,6,5,2};
    unsigned i=6;
    if(!feat.v[LSDJ_FEAT_KEYLIGHTS])return 0;
    if(lsdj_ov_bars_active(&bars,fm1_ms)&&!cue.held&&!tempo.held){   /* the channel pages (master pages: the mute lights) */
        if(lsdj_fx_on_master(&fxu))return 0;
        i=lsdj_fx_cur(&fxu)-FX_PAGE_FILTER;
    }
    else if(screen_addr){uint8_t s=gp_wram_peek(screen_addr);for(i=0;i<6u&&scr[i]!=s;i++);}
    return i<6u?1u<<key[i]:0u;
}
/* MODE LIGHTS: the power-on sweep again when HOME changes note / button mode, once every key and
   button is let go (a key or button down ends the sweep at once). */
static uint8_t mode_sweep;
/* The DJ layout's OP4 / OP5 (lsdj_djkeys.h), each frame: returns the keys for the rest of the FM-1.
   A press goes to the page as DJ_KEY only when it fits the SysEx ring whole (ota_wire_send would
   otherwise wait, and the frame with it); until then it waits here, a frame at a time. */
static uint8_t dj_pending;   /* LSDJ_DJ_EV_* not sent yet */
static uint32_t dj_frame(void){
    unsigned ev;
    uint32_t keys=lsdj_dj_keys(&djk,key_lo,fm1_ms,&ev);
    if(!lsdj_dj_on(&djk,fm1_ms))dj_pending=0;   /* the page went away: nobody to tell */
    dj_pending|=(uint8_t)ev;
    if((ev&LSDJ_DJ_EV_STOP)&&!lsdj_armed())(void)cue_stop(1);   /* Stop on a stopped deck: its cue cancelled */
    while(dj_pending){
        uint8_t buf[9];unsigned key=dj_pending&LSDJ_DJ_EV_PLAY?0u:1u;
        uint32_t n=lsdj_link_dj_key((uint8_t)key,buf);
        if(so_w-so_r+(n+2u)/3u>SXQ)break;   /* the ring is full: next frame */
        dj_pending&=(uint8_t)~(key?LSDJ_DJ_EV_STOP:LSDJ_DJ_EV_PLAY);
        if(ota_wire_send(buf,n)){dj_pending=0;break;}   /* USB gone */
    }
    dj_mask=lsdj_dj_lights(&djk,fm1_ms,dj_beat,&dj_lit,&dj_soft);
    return keys;
}
static void fm1_input_frame(void){
    if(lsdj_glide_step(&glide,&fx.p,fm1_ms))lsdj_fx_update(&fx);   /* a preset's effects, sliding in */
    if(mode_sweep&&!fm1_in.buttons&&!fm1_in.notes){mode_sweep=0;fm1_led_anim_start(0);}
    led_anim=(uint8_t)leds_busy();
    play_light();cue_frame();seq_frame();
    /* MIDI sync: START presses for the transport (lsdj_midisync.h), whatever is open */
    sync_midi=(uint8_t)(sync_off&&gp_save_data()[sync_off]==LSDJ_SYNC_MIDI);
    if(lsdj_ms_quiet(&msync,fm1_ms)){   /* the clock went quiet while running: as a Stop */
        (void)cue_stop(0);
        lsdj_ov_show(&ov,"MIDI CLOCK STOPPED",sync_auto==LSDJ_SYNC_LSDJ?"LSDJ SYNC: LSDJ":sync_auto?"LSDJ SYNC: KEYBD":"LSDJ STOPPED",fm1_ms);
    }
    /* a Start's press waits while a start row goes into LSDj's cursor (cue_start_ok); the clock's ticks wait
       in the link queue meanwhile (LSDj reads it once armed), so it still starts in step */
    if((msync.want==LSDJ_MS_ARM||msync.want==LSDJ_MS_RESTART)&&!msync.hold&&!msync.gap&&!lsdj_armed()&&!cue_start_ok())sync_btn=0;
    else sync_btn=lsdj_ms_frame(&msync,lsdj_armed())?GP_START:0u;
    if(sync_auto){   /* auto SYNC: back to the user's SYNC once a MIDI Stop has stopped LSDj */
        if(!sync_midi)sync_auto=0;   /* SYNC changed by hand, or another song */
        else if(!msync.running&&msync.want==LSDJ_MS_NONE&&!lsdj_armed()&&sync_set(sync_auto)){
            if(sync_auto==LSDJ_SYNC_KEYBD)kb_octave=-1;
            sync_auto=0;
        }
    }
    uint32_t keys=dj_frame();   /* OP4 / OP5 are the DJ layout's while the page has this FM-1 on a deck */
    if(menu.open){menu_input();return;}
    /* Once per emulated frame: knob taps are timed in frames.
       Keys, PLAY=Start, REC=Select: src/fm1_lsdj_input.h. */
    int32_t enc[FM1_NENC];
    for(unsigned e=0;e<FM1_NENC;e++)enc[e]=fm1_enc_take(e);
    if(cursor_addr)lsdj_fx_cursor_seen(&fxu,gp_wram_peek(cursor_addr));   /* a move ends a SELECT button pick */
    if(tempo_addr){uint8_t b=gp_wram_peek(tempo_addr);lsdj_fx_set_bpm(&fx,b<40u?b+256u:b);}   /* LSDj: 40..295 */
    if(tempo.held){   /* EDIT held: K1 / K2 set the tempo, not effects */
        unsigned b=lsdj_tempo_turn(&tempo,(int)enc[2],(int)enc[3]);enc[2]=enc[3]=enc[4]=enc[5]=0;
        if(b)tempo_apply(b);   /* (the EDIT screen shows it: native_draw) */
    }
    if(cue.held){   /* ARP held: K1 / K2 choose the song row to cue, not effects */
        lsdj_cue_turn(&cue,(int)enc[2],(int)enc[3]);enc[2]=enc[3]=enc[4]=enc[5]=0;
        lsdj_cue_bars(&cue,gp_save_data()+songtab_off,bars.title,bars.big,bars.label,bars.value,bars.caption,bars.level);
        for(unsigned k=0;k<4u;k++)bars.nchoice[k]=0;
        bars.amount_scale=0;
        bars.hot=-1;bars.chan=-1;bars.grey=0;lsdj_ov_bars_keep(&bars,fm1_ms);
    }
    {   /* KNOB 1-4 (encoders 2-5): the page's four effects */
        int32_t st[4]={enc[2],enc[3],enc[4],enc[5]};
        int k=lsdj_fx_knobs(&fx,&fxu,st);
        if(k>=0){fx_knobs_after(st);fx_bars_show(k);}
    }
    if(enc[0]&&edit_open){   /* the EDIT page: the SELECT knob moves the presets' cursor (stopping at the ends) */
        int c=(int)plist_cur+(int)enc[0];
        plist_cur=(uint8_t)(c<0?0:c>=(int)LSDJ_PRESETS?(int)LSDJ_PRESETS-1:c);
    }
    else if(enc[0]){   /* SELECT knob (encoder 0): effects pages, stopping at the ends (PAGE WRAP: round) */
        lsdj_fx_page_turn(&fxu,(int)enc[0],feat.v[LSDJ_FEAT_WRAP]);fx_bars_show(-1);
    }
    if(fx_open&&!cue.held&&!tempo.held)lsdj_ov_bars_keep(&bars,fm1_ms);   /* FX pressed: open until FX again */
    int fx_shown=!cue.held&&!tempo.held&&lsdj_ov_bars_active(&bars,fm1_ms);
    if(fx_shown)fx_bars_fill();
    uint32_t keys_down=keys&~fx_keys_prev;fx_keys_prev=keys;
    if(edit_open){   /* the EDIT page: C4 .. C5 load a preset at once, F3 taps the tempo; LSDj gets no keys, but PLAY
                        still plays (the SELECT / SAVE buttons: below, with the other buttons) */
        if(tempo.held&&!sync_midi&&((keys_down>>TAP_KEY)&1u)){   /* the tap key: tap tempo */
            unsigned b=lsdj_tempo_press(&tempo,lsdj_tempo_of_byte(gp_wram_peek(tempo_addr)),fm1_ms);
            if(b)tempo_apply(b);
        }
        for(unsigned i=0;i<LSDJ_PRESETS;i++)if((keys_down>>lsdj_preset_key[i])&1u){
            tempo.taps=0;   /* ends a tap run */
            plist_cur=(uint8_t)i;(void)preset_load(i);
        }
        presets_lights();
        uint32_t play=(fm1_in.buttons&(1u<<LSDJ_BTN_PLAY))?lsdj_in.play_btn:0u;
        gp_buttons(cue_buttons(sync_btn|play));return;
    }
    if(fx_shown&&lsdj_fx_on_master(&fxu)){   /* a master page: the channel strip; LSDj gets no input meanwhile */
        uint8_t before=fx.mute;
        if(keys_down&&lsdj_fx_hold_keys(&fx,keys_down)){mute_mark(before,1);fx_bars_fill();}
        piano_set(lsdj_fx_hold_lights(&fx));
        gp_buttons(sync_btn);return;
    }
    uint32_t panel_now=fm1_in.buttons,panel_was=lsdj_in.prev_buttons;
    uint8_t mode_was=lsdj_in.mode;int8_t oct_was=lsdj_in.octave;
    input_buttons=lsdj_input_frame(&lsdj_in,keys,panel_now,enc);
    /* On-screen messages for what the FM-1's own buttons just did. */
    if(lsdj_in.mode!=mode_was){
        if(lsdj_in.mode==LSDJ_KEYS_NOTES){int k=keybd_sync();
            lsdj_ov_say(&ov,k==1?LSDJ_MSG_KEYBD_SET:k==0?LSDJ_MSG_NOTE_KEYBD:LSDJ_MSG_NOTE_MODE,fm1_ms);}
        else lsdj_ov_say(&ov,LSDJ_MSG_BUTTON_MODE,fm1_ms);
        mode_sweep=feat.v[LSDJ_FEAT_ANIM];
    }
    else if(lsdj_in.octave!=oct_was)
        lsdj_ov_octave(&ov,lsdj_in.octave<oct_was,lsdj_in.octave,fm1_ms);
    else if(lsdj_in.mode==LSDJ_KEYS_BUTTONS&&(panel_now&~panel_was&3u))
        lsdj_ov_say(&ov,LSDJ_MSG_OCT_BUTTONS,fm1_ms);
    /* Note mode: every key light off. The web page's controller (PAD_SET) joins the keys, lights included. */
    uint32_t web_pad=link_pad_now();
    piano_lights(lsdj_in.mode==LSDJ_KEYS_NOTES?0xFFu:input_buttons|web_pad);
    input_seen|=input_buttons|web_pad;gp_buttons(cue_buttons(input_buttons|web_pad|sync_btn));
}
#endif
static void boot_splash(int display_ok){
#if !GB_SMK37
    const lsdj_theme_t *th=lsdj_theme_of(settings.theme);   /* loaded before the splash: it takes the theme's colours */
    const lsdj_splash_colors_t splash_col=lsdj_splash_of_theme(th->gb,th->accent);
#endif
    uint32_t start=fm1_ticks(),landed=0,landing_frame=0,landed_at=0,next_draw=0;
    for(;;){
        uint32_t ms=(fm1_ticks()-start)/24000u;
        fm1_wdt_feed();
#if !GB_SMK37
        master_poll();
#endif
        int ready=!display_ok||display_ready();
        /* Start the chime after the landing frame has finished its LCD transfer. */
        if(!landed&&ready&&(landing_frame||(!display_ok&&ms>=GD_SPLASH_LAND_MS))){
            ding_position=0;landed=1;landed_at=ms;
        }
        if(landed&&ms>=GD_SPLASH_END_MS&&ms-landed_at>=750u)break;
        if(display_ok&&ready&&ms>=next_draw){
#if GB_SMK37
            gd_splash_draw(screen,ms);
#else
            lsdj_splash_draw(screen,ms,gd_splash_y(ms)-84,BURRITO_RELEASE,&splash_col);
#endif
            display_frame();next_draw=ms+33u;
            if(ms>=GD_SPLASH_LAND_MS)landing_frame=1;
        }
    }
    while(display_ok&&!display_ready())fm1_wdt_feed();
}
#if defined(CART_SLOT_CAPACITY)
/* No LSDj in the slot: the release file on GitHub / The Firmware Hub (the template as built, slot empty),
   or a slot that does not check out. Say how to add one, and keep USB and the update loader running so
   the web page, or any updater, can install firmware; the boot counts as healthy (no recovery loop). */
static void no_lsdj(int display_ok){
    lsdj_absent=1;
    input_init();recovery_init();(void)swap_setup();fm1_irq_enable_all();
    if(display_ok){
        const lsdj_splash_colors_t *c=&lsdj_splash_default;
        lsdj_splash_draw(screen,1600u,0,BURRITO_RELEASE,c);
        lsdj_ov_text_c(screen,LSDJ_OV_W/2u,148u,"NO LSDJ ON THIS FM-1 YET",c->accent,1u);
        lsdj_ov_text_c(screen,LSDJ_OV_W/2u,159u,"ADD YOUR OWN WITH THE WEB PAGE:",c->text,1u);
        lsdj_ov_text_c(screen,LSDJ_OV_W/2u,169u,"DREAMSOFBACON.GITHUB.IO/LSDJ-BURRITO",c->text,1u);
        while(!display_ready())fm1_wdt_feed();
        display_frame();
        while(!display_ready())fm1_wdt_feed();
    }
    uint32_t start=fm1_ms;
    for(;;){
        fm1_wdt_feed();recovery_service();
        lsdj_swap_poll(&swap,&swap_io,fm1_ms);   /* a swap the page left, END's restart */
        if(fm1_ms-start>5000u)smk37_bootguard_healthy(&gb_bootguard);
    }
}
#endif
/* MIDI clock out (CLOCK OUT): LSDj leading (SYNC = LSDJ, playing) sends one link byte a
   tick; each goes out as a MIDI clock (F8) when that moment of the sound is heard, Start
   before the first, Stop when they stop (lsdj_midi.h). */
static lsdj_mco_t mco;
static void midi_out_byte(uint8_t b){
    if(midi.clock_out==LSDJ_OUT_USB){uint32_t f=irq_save();midi_out_event(0x0Fu|(uint32_t)b<<8);irq_restore(f);}
}
static void midi_clock_out(void){
    uint32_t pos,now=sound_clock();
    while(gp_master_tick_peek(&pos)&&(int32_t)(now-pos)>=0){
        gp_master_tick_drop();
        if(!midi.clock_out)continue;
        uint8_t b[2];unsigned n=lsdj_mco_tick(&mco,fm1_ms,b);
        for(unsigned i=0;i<n;i++)midi_out_byte(b[i]);
    }
    if(lsdj_mco_poll(&mco,fm1_ms)&&midi.clock_out)midi_out_byte(0xFCu);
    if(!midi.clock_out)mco.running=0;
    static uint8_t told;   /* CLOCK OUT on, LSDj playing, but not leading: say how, once */
    if(midi.clock_out&&!told&&sync_off&&lsdj_armed()&&gp_save_data()[sync_off]!=LSDJ_SYNC_LSDJ){
        told=1;lsdj_ov_show(&ov,"MIDI CLOCK OUT: SET","LSDJ SYNC TO LSDJ",fm1_ms);
    }
}
static void fm1_fault(const fm1_crash_t *c){(void)c;video_retire();audio_stop();fm1_reboot();}
/* 0.9.98-dev.20, the hang recorder (stability: Colin's FM-1 restarted by the watchdog while idle on the DJ page,
   2026-11-21, and nothing said where CPU0 was). Both periodic interrupts (the scan timer, the sound) look at the
   watchdog's feed count: unmoved for HANG_MS, CPU0 is stuck in a loop that never feeds it. The crash record is
   written then as a crash with vector HANG_VEC (pc: where CPU0 was; rets: the link op being handled, 0x100 | op;
   sp: CPU1's heartbeat; psr: the feed count), and the FM-1 restarts as after a crash (the crash guard as ever),
   before the watchdog's 8 s would (which may leave nothing). A hang with interrupts off, or in a higher interrupt,
   is not seen: the watchdog still restarts it (RESTART: why 2, no record). Armed once the main loop runs. */
#define HANG_VEC 254u
#define HANG_MS 6000u


static uint32_t hang_fed,hang_at,hang_passes;
static void hang_check(uint32_t pc){
    if(!hang_on)return;
    uint32_t f=fm1_wdt_fed,now=fm1_ticks();
    if(f!=hang_fed){hang_fed=f;hang_at=now;hang_passes=loop_passes;return;}
    if(now-hang_at<HANG_MS*24000u)return;
    (void)irq_save();hang_on=0;
    int rec=fm1_crash.magic==FM1_CRASH_MAGIC;
    uint32_t count=rec?fm1_crash.count:0u,early=rec?fm1_crash.early:0u;
    fm1_crash.magic=FM1_CRASH_MAGIC;fm1_crash.count=count+1u;fm1_crash.vec=HANG_VEC;fm1_crash.pc=pc;
    fm1_crash.rets=hang_op;fm1_crash.emu=fm1_p33_timeouts;   /* (a hang: P33 timeouts since boot, dev.21) */
    fm1_crash.dbg=loop_passes-hang_passes;   /* (dev.21: main-loop passes in the stall: 0-1 stuck or starved, thousands: running unfed) */fm1_crash.sp=gp_core1.heartbeat;
    fm1_crash.psr=f;fm1_crash.icfg=fm1_icfg();fm1_crash.uptime_ms=fm1_ms;
    for(unsigned i=0;i<4u;i++)fm1_crash.etm[i]=FM1_ETM_PC(i);
    fm1_crash.early=fm1_ms<3000u?early+1u:0u;
    fm1_fault(&fm1_crash);
}
extern uint32_t _data_start[],_data_end[],_data_load[],_bss_start[],_bss_end[];
extern uint32_t _pool_start[],_pool_end[],_rt_start[],_rt_end[],_rt_load[];
extern uint32_t _dsp_start[],_dsp_end[],_dsp_load[];
static void copy(uint32_t*d,uint32_t*end,const uint32_t*s){while(d<end)*d++=*s++;}
static void zero(uint32_t*d,uint32_t*end){while(d<end)*d++=0;}
/* 0.9.98-dev.19: why the last run ended, said at boot and over the link (RESTART): 1 a crash (fm1_crash, the record
   the fault handler leaves in .noinit, newer than the last one said), 2 the watchdog (P3_RST_SRC bit 2), 0 neither
   (power on, an install, a planned restart). The record itself is never cleared: its `early` count is the crash-loop
   guard's. Colin's FM-1 restarted during DJ use and came back on CPU0 (R0, video_guard) with nothing saying why. */
typedef struct{uint32_t magic,count;}restart_seen_t;
restart_seen_t restart_seen __attribute__((section(".noinit")));   /* (not static: see fm1_crash) */

static void restart_note(uint32_t p3,uint32_t rst,uint32_t cold){
    int rec=fm1_crash.magic==FM1_CRASH_MAGIC;
    int fresh=rec&&(restart_seen.magic!=0x52535452u||restart_seen.count!=fm1_crash.count);
    restart_kind=(uint8_t)(cold?0u:fresh?(fm1_crash.vec==HANG_VEC?3u:1u):(p3&4u)&&!(rst&0x20u)?2u:0u);   /* (P3_RST_SRC keeps a watchdog's bit through core resets: an install after one is not one, dev.21) */   /* 3: a hang (0.9.98-dev.20) */restart_p3=p3;restart_rst=rst;
    restart_seen.magic=0x52535452u;restart_seen.count=rec?fm1_crash.count:0u;
}
void gb_cstart(const uint32_t *parameters){
    fm1_core1_stop();fm1_p33_timeouts=0;fm1_reset_reason();
    uint32_t cold=fm1_boot.p3_rst&1u,boot_p3=fm1_boot.p3_rst,boot_rst=fm1_boot.rst_src;   /* (.bss is zeroed below) */
    fm1_wdt_arm(0x0d);
    if(smk37_bootguard_begin(&gb_bootguard,cold))fm1_enter_uboot();
#if GB_SMK37
    smk37_boot_capture(parameters);
#else
    (void)parameters;
#endif
    zero(_bss_start,_bss_end);zero(_pool_start,_pool_end);
    copy(_data_start,_data_end,_data_load);copy(_rt_start,_rt_end,_rt_load);
    copy(_dsp_start,_dsp_end,_dsp_load);__asm__ volatile("csync":::"memory");
    restart_note(boot_p3,boot_rst,cold);
#if GB_SMK37
    smk37_time_init();
#else
    fm1_time_init();
#endif
    fm1_irq_init();fm1_mailbox_clear();
    int display_ok=display_init();
#if !GB_SMK37
    save_display_ok=display_ok;
#endif
    /* Volatile header read: the public template's ROM slot is patched in the
       browser, so the compiler must not fold its original header bytes. */
    const volatile uint8_t *cart_header=cartridge;
#if defined(CART_SLOT_CAPACITY)
    int slot_error=lsdj_slot_parse(cart_header,CART_SLOT_CAPACITY,&cart_slot);
    cart_slot_valid=(uint8_t)(slot_error==LSDJ_SLOT_OK);
    if(!slot_error)gp_set_bank_map(cart_slot.bank_map,cart_slot.logical_banks,cart_slot.start,cart_slot.len);
    if(slot_error||gp_load(cartridge+cart_slot.data_off,cart_slot.logical_banks*LSDJ_SLOT_BANK)){
#elif defined(CART_SPARSE_BANKS)
    /* Sparse cartridge (tools/build.py): only code + chosen kit banks are stored. */
    (void)cart_header;gp_set_bank_map(cart_bank_map,CART_SPARSE_BANKS,0,0);
    uint32_t cart_size=CART_SPARSE_BANKS*16384u;
    if(gp_load(cartridge,cart_size)) {
#else
    uint32_t cart_size=cart_header[0x148]<=4?(32768u<<cart_header[0x148]):0;
    if(!cart_size||cart_size>sizeof cartridge||gp_load(cartridge,cart_size)) {
#endif
#if defined(CART_SLOT_CAPACITY)
        no_lsdj(display_ok);   /* never returns */
#endif
        /* Invalid embedded cartridge: allow bootguard/watchdog recovery. */
        for(;;);
    }
    input_init();
#if !GB_SMK37
    master_boot();
#endif
    splash_active=1;ding_position=GD_DING_FRAMES;
    audio_start();fm1_irq_enable_all();
#if !GB_SMK37
    /* Before LSDj's first frame (after the splash): it reads its songs from
       cartridge RAM at boot. Needs the panel scan running for the light blinks. */
    lsdj_save_boot();
    preset_cur=(uint8_t)lsdj_presets_current(presets_page);
    theme_load();   /* the custom theme, before the settings choose a theme */
    lsdj_set_unpack(ftl.has_settings?ftl.settings:0u,&settings);settings_apply();
    lsdj_midi_unpack(((ftl.rec_has>>MIDI_REC)&1u)?ftl.rec[MIDI_REC]:0u,&midi);   /* (defaults if none) */
    lsdj_feat_unpack(((ftl.rec_has>>FEAT_REC)&1u)?ftl.rec[FEAT_REC]:0u,&feat);
    lsdj_fx_init(&fx,fx_echo);lsdj_fx_set_reverb(&fx,fx_reverb);lsdj_fx_ui_init(&fxu);fx_load();feat_apply();gp_set_fx(fx_hook);cursor_detect();
    fm1_led_key(SAVE_BUTTON,1);
#endif
    boot_splash(display_ok);
    fm1_led_anim_start(0);   /* boot done: the light sweep (leds_busy) */
    for(unsigned i=0;i<4;i++)gp_frame();
    splash_active=0;
    recovery_init();
#if defined(CART_SLOT_CAPACITY)
    (void)swap_setup();   /* the fast LSDj swap: this FM-1's slot (lsdj_swap_fm1.h) */
#endif
#if !GB_SMK37
    core1_emu=1;   /* the emulator moves to CPU1; if CPU1 does not start, CPU0 keeps it */
#endif
    video_start(cold);
    uint32_t drawn=0,last=fm1_ticks(),elapsed=0,seconds=0;
#if !GB_SMK37
    if(songs_loaded)lsdj_ov_say(&ov,LSDJ_MSG_LOADED,fm1_ms);
    /* 0.9.98-dev.20: CPU1 didn't start (R1): LSDj runs on CPU0, too slow with the effects, until a power-off; said
       instead of the sound going bad with nothing on the screen (Colin, 2026-11-21). First, over a restart message
       (dev.21: after Colin's dev.20 install the false WATCHDOG one hid it); the restart is in the page's Log too */
    if(!video_online&&video_retire_reason==1u){
        lsdj_ov_show(&ov,"CPU1 DIDN'T START","TURN OFF AND ON",fm1_ms);
        ov.until_ms=(fm1_ms+15000u)|1u;
    }
    else if(restart_kind){   /* why it restarted (restart_note), for 10 s: "RESTARTED: CRASH" / "AT 0200ABCD" */
        char l2[20]="AT ";
        for(unsigned k=0;k<8u;k++)l2[3+k]="0123456789ABCDEF"[(fm1_crash.pc>>(28u-4u*k))&15u];
        l2[11]=0;
        lsdj_ov_show(&ov,restart_kind==1u?"RESTARTED: CRASH":restart_kind==3u?"RESTARTED: HANG":"RESTARTED: WATCHDOG",restart_kind!=2u?l2:"CPU0 STOPPED",fm1_ms);
        ov.until_ms=(fm1_ms+10000u)|1u;
    }
    cpu.start=fm1_ticks();
#endif
    hang_on=1;   /* the hang recorder from here (hang_check) */
    for(;;){
        loop_passes++;   /* (the hang recorder: passes during a stall) */
#if LSDJ_DEV
        if(hang_test)for(;;)video_barrier();   /* TEST HANG: stuck, interrupts on, the watchdog not fed */
        if(restart_test){   /* TEST CORE / CHIP: a planned restart (as swap_restart), by a core or a chip reset */
            fm1_delay_ms(50);video_stop();audio_stop();gb_bootguard.pending=0;usb_detach();fm1_delay_ms(30);
            if(restart_test==1u)fm1_core_reset();else fm1_reboot();
        }
#endif
        uint32_t now=fm1_ticks();elapsed+=now-last;last=now;
        int worked=0;   /* CPU meter: a pass that does nothing counts as idle */
        if(elapsed>=24000000){elapsed-=24000000;seconds++;}
        fm1_wdt_feed();
#if !GB_SMK37
        master_poll();
#endif
        recovery_service();
        screen_push();screen_stream();
        lsdj_link_poll(&link_state,&link_io,fm1_ms);   /* an import whose page went away */
#if defined(CART_SLOT_CAPACITY)
        lsdj_swap_poll(&swap,&swap_io,fm1_ms);         /* a swap the page left, END's restart */
#endif
        import_screen();
#if LSDJ_SLOT_PROBE
        slot_probe_status();
        {static uint32_t held_at;   /* SAVE held 3 s: the slot test (once) */
         if(fm1_in.buttons&(1u<<SAVE_BUTTON)){if(!held_at)held_at=fm1_ms|1u;else if(held_at!=1u&&fm1_ms-held_at>3000u){held_at=1u;slot_probe_write();}}
         else held_at=0;}
#endif
#if !GB_SMK37
        midi_clock_out();
#endif
#if !GB_SMK37
        {
            static uint32_t prev_panel;
            uint32_t panel=fm1_in.buttons;
            if(panel&~prev_panel&(1u<<SAVE_BUTTON)){   /* SAVE: the songs; on the EDIT page, everything into the preset at the cursor */
                if(edit_open)preset_save(plist_cur,0);else lsdj_save_button();
            }
            if(panel&~prev_panel&(1u<<SEQ_BUTTON))seq_button();
            if(songrow_addr&&((panel^prev_panel)&(1u<<ARP_BUTTON)))cue_button((panel>>ARP_BUTTON)&1u);
            if(panel&~prev_panel&(1u<<EDIT_BUTTON)&&!menu.open)edit_page(!edit_open);   /* EDIT: the EDIT page, open / closed */
            if(panel&~prev_panel&(1u<<FX_BUTTON)&&!menu.open){   /* FX: the master pages open / closed (the EDIT page closed) */
                edit_page(0);
                if(fx_open){fx_open=0;lsdj_fx_master(&fxu,0);bars.until_ms=0;}
                else{fx_open=1;lsdj_fx_master(&fxu,1);fx_bars_show(-1);}
            }
            if(panel&~prev_panel&(1u<<CHAN_BUTTON)&&!menu.open&&edit_open){   /* the EDIT page: SELECT loads the preset at the cursor */
                tempo.taps=0;(void)preset_load(plist_cur);
            }
            else if(panel&~prev_panel&(1u<<CHAN_BUTTON)&&!menu.open){   /* SELECT button: the effects channel, PU1 .. NOI, cursor */
                if(fx_open){fx_open=0;lsdj_fx_master(&fxu,0);}   /* to the channel pages */
                if(!lsdj_fx_chmode(&fxu))lsdj_fx_pick_next(&fxu);   /* KNOBS = CHANNELS: each knob is a channel already */
                fx_bars_show(-1);
            }
            if(panel&~prev_panel&(1u<<GLO_BUTTON)){
                if(!menu.open){lsdj_menu_open(&menu);fx_open=0;lsdj_fx_master(&fxu,0);bars.until_ms=0;edit_page(0);}   /* the effects panel and the EDIT page go */
                else{
                    menu.open=0;
                    if(menu.changed){   /* keep them: a 16-byte record, the emulator parked meanwhile */
                        int rc=-8;
                        if(play_save){settings_pending=1;rc=0;}   /* written when the save is done */
                        else if(recovery_flash_ok){video_hold();rc=settings_store();video_release();}
                        lsdj_ov_say(&ov,rc?LSDJ_MSG_SETTINGS_FAILED:LSDJ_MSG_SETTINGS_SAVED,fm1_ms);
                    }
                }
            }
            prev_panel=panel;
            {   /* CPU meter: underruns since the last pass */
                static uint32_t underruns_seen;
                uint32_t u=audio_underruns;cpu.underrun_count+=u-underruns_seen;underruns_seen=u;
            }
            cpu.core1=(uint8_t)(core1_emu&&video_online);cpu.reason=(uint8_t)video_retire_reason;
            {   /* the emulator fell back to CPU0 (CPU1 did not start, or stopped): too slow with the
                   effects, the sound crackles. Say so once each time, and how to get CPU1 back. */
                static uint32_t told=0;
                if(!(core1_emu&&video_online)&&video_fallbacks!=told&&fm1_ms>6000u){
                    told=video_fallbacks;lsdj_ov_show(&ov,"CPU1 STOPPED: SOUND","MAY CRACKLE. OFF+ON",fm1_ms);
                }
            }
            {   /* BATTERY: low (no bars, not on USB): say so once */
                static uint8_t low_told;unsigned b=battery_level();
                if(b==0u&&!low_told&&feat.v[LSDJ_FEAT_BATTERY]){low_told=1;lsdj_ov_show(&ov,"BATTERY LOW","PLUG IN USB SOON",fm1_ms);}
                else if(b!=0u&&b!=0xFFu&&(b&0x80u||b>=2u))low_told=0;
            }
            if(lsdj_cpu_poll(&cpu,fm1_ticks())&&settings.meter&&!menu.open){
                static char l1[20],l2[20];
                static unsigned meter_n;   /* every 4th second: the audio clock (lsdj_clock.h) */
                if(++meter_n%4u==0u){lsdj_clk_t cc;uint32_t f=irq_save();cc=clk;irq_restore(f);lsdj_clk_lines(&cc,l1,l2);}   /* (a whole copy: the interrupts write it) */
                else lsdj_cpu_lines(&cpu,l1,l2);
                lsdj_ov_show(&ov,l1,l2,fm1_ms);
            }
        }
#endif
#if !GB_SMK37
        int emu1=core1_emu&&video_online;   /* the emulator runs on CPU1 */
#else
        int emu1=0;
#endif
        static uint32_t seen_frames,seen_busy,hb,hb_at;
        if(!emu1){hb_at=fm1_ticks();seen_frames=gp_core1.frames;seen_busy=gp_core1.busy_ticks;}
#if !GB_SMK37
        if(emu1){
            /* Input for the frame CPU1 is about to emulate, and the CPU meter. */
            uint32_t f=gp_core1.frames;
            if(f!=seen_frames){
                fm1_input_frame();
                play_save_step();autosave_poll();presets_poll();
                uint32_t busy=gp_core1.busy_ticks;
                cpu.emu+=busy-seen_busy;cpu.frames+=f-seen_frames;
                if(gp_core1.last_ticks>cpu.worst)cpu.worst=gp_core1.last_ticks;
                seen_busy=busy;seen_frames=f;
                cpu.snd+=gp_snd_take_ticks();cpu.renders+=gp_snd_take_renders();
                worked=1;
            }
            /* A finished picture: scale it here (CPU0), then let CPU1 draw again. */
            if(display_ok&&gp_core1.pic_seq!=gp_core1.pic_ack&&display_ready()){
                uint32_t t0=fm1_ticks();video_barrier();
                native_draw();video_scale_local(gp_pixels(),screen);
                video_barrier();gp_core1.pic_ack=gp_core1.pic_seq;
                /* panels and messages: in the picture (native_draw) */
                display_frame();display_count++;
                cpu.lcd+=fm1_ticks()-t0;worked=1;
            }
            /* CPU1 watchdog: no progress for 0.5 s, or a CPU1 fault: emulate on CPU0. */
            uint32_t h=gp_core1.heartbeat;
            if(h!=hb){hb=h;hb_at=fm1_ticks();}
            else if((uint32_t)(fm1_ticks()-hb_at)>12000000u||fm1_core1_fault.count!=video_faults){
                video_retire_reason=5;video_retire();
            }
        }
#endif
        if(!emu1&&gp_audio_queued()<GP_AUDIO_TARGET){
#if GB_SMK37
            input_buttons=smk_input_frame();input_seen|=input_buttons;gp_buttons(input_buttons);
#else
            fm1_input_frame();
#endif
            uint32_t t0=fm1_ticks();
            /* Only the frame that will be sent to the LCD is drawn (every pic_every-th: SCREEN RATE). */
            gp_render(gp_frame_count()+1u-drawn>=gp_core1.pic_every);
            gp_frame();
            lsdj_cpu_frame(&cpu,fm1_ticks()-t0);worked=1;
#if !GB_SMK37
            play_save_step();autosave_poll();presets_poll();
#endif
            cpu.snd+=gp_snd_take_ticks();cpu.renders+=gp_snd_take_renders();
        }
        if(!emu1 && display_ok && video_complete()){
            uint32_t t0=fm1_ticks();
#if !GB_SMK37
            /* panels and messages: in the picture (native_draw) */
#endif
            display_frame();display_count++;
            cpu.lcd+=fm1_ticks()-t0;worked=1;
        }
        if(!emu1 && display_ok && !video_pending && gp_frame_count()-drawn>=gp_core1.pic_every && display_ready()){
            uint32_t t0=fm1_ticks();
            native_draw();video_submit(gp_pixels());drawn=gp_frame_count();
            if(!video_online){
#if !GB_SMK37
                /* panels and messages: in the picture (native_draw) */
#endif
                display_frame();display_count++;
            }
            cpu.lcd+=fm1_ticks()-t0;worked=1;
        }
        if(!worked)cpu.idle+=fm1_ticks()-now;
        if(seconds>=30 && scan_count>100 && audio_count>100 && gp_frame_count()>100)
            smk37_bootguard_healthy(&gb_bootguard);
        if(gp_error()) {audio_stop();fm1_reboot();}
    }
}
