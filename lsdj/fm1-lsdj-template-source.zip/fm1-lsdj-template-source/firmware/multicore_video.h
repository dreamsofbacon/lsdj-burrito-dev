/* SPDX-License-Identifier: GPL-3.0-only
 * AC79 CPU1 launch follows the retained Felucca fm1_multicore.h and crt0.S.
 * IRQs, USB, audio, GB/APU state and LCD DMA remain exclusively on CPU0. */
#define GB_VIDEO_RAM __attribute__((section(".dsp_text"),noinline))
#define GB_VIDEO_BARRIER() __asm__ volatile("csync" ::: "memory")
#include "video_job.h"
static gb_video_job_t video_job;
#if GB_SMK37
static uint16_t video_source[GB_VIDEO_PIXELS] __attribute__((section(".pool"),aligned(32)));
#else
/* FM-1: CPU1 runs the emulator (gp_core1_step) and CPU0 scales pictures from
   gp_pixels(), so CPU1's scaling job never runs and needs no 46 KiB source copy. */
static uint16_t video_source[1];
#endif
static uint32_t video_stacks[2048] __attribute__((section(".cpu1_stacks"),aligned(32),used));
static volatile uint32_t video_ready;
/* 1: CPU1 runs the emulator (gp_core1_step) instead of scaling pictures. */
static volatile uint32_t core1_emu;
volatile uint32_t video_stage;
static volatile uint32_t video_core,video_worker_jobs,video_work_max_ticks;
static uint32_t video_launch_ready,video_retire_reason,video_retire_ticks;
static uint32_t video_launch_con,video_launch_pc,video_launch_emu,video_launch_dbg;
static uint32_t video_online,video_pending,video_started,video_faults,video_jobs,video_fallbacks;
volatile struct {uint32_t magic,barred,running;} video_guard __attribute__((section(".noinit")));
extern void gb_core1_start(void);
extern uint8_t _cpu1_stacks_lo[],_cpu1_stacks_hi[];
static void video_barrier(void){GB_VIDEO_BARRIER();}
/* XIP-to-SRAM calls exceed the pi32v2 short branch range. */
static void video_scale_local(const uint16_t *src,uint16_t *out){
 void (*volatile fn)(const uint16_t*,uint16_t*)=gb_video_scale;fn(src,out);
}
static uint32_t video_hash_local(const uint16_t *src){
 uint32_t (*volatile fn)(const uint16_t*)=gb_video_hash;return fn(src);
}
void __attribute__((section(".dsp_text"),noreturn,used)) gb_core1_main(void){
 video_stage=3;GB_VIDEO_BARRIER();
 uint32_t lo=(uint32_t)(uintptr_t)_cpu1_stacks_lo+256u,hi=(uint32_t)(uintptr_t)_cpu1_stacks_hi-1u;
 *(volatile uint32_t*)0x1EEF2D8u=hi;*(volatile uint32_t*)0x1EEF2DCu=lo;
 *(volatile uint32_t*)0x1EEF2E0u=hi;*(volatile uint32_t*)0x1EEF2E4u=lo;
 *(volatile uint32_t*)0x1EEF2D0u=(*(volatile uint32_t*)0x1EEF2D0u&~((1u<<2)|(0x1fu<<16)))|(1u<<3);
 uint32_t core;__asm__ volatile("%0 = cnum" : "=r"(core));
 video_core=core;video_stage=4;GB_VIDEO_BARRIER();video_ready=1;GB_VIDEO_BARRIER();
 for(;;){
#if !GB_SMK37
  gp_core1_step();continue;                  /* FM-1: the emulator, in RAM */
#else
  if(core1_emu){gp_core1_step();continue;}
#endif
  if(!video_job.request||video_job.request==video_job.complete)continue;
  uint32_t start=*(volatile uint32_t*)0x10804u;
  int done=gb_video_work(&video_job,video_source,screen);
  if(done>0){
   uint32_t ticks=*(volatile uint32_t*)0x10804u-start;
   if(ticks>video_work_max_ticks)video_work_max_ticks=ticks;
   video_worker_jobs++;GB_VIDEO_BARRIER();
  }
 }
}
/* Before CPU1 is stopped (SAVE, a firmware update, a fault), a running emulator
   is parked between frames: it then reads nothing but gp_core1 in RAM, so the
   flash may be written. 100 ms at most; a hung CPU1 is stopped anyway. */
/* Park the emulator on CPU1 between frames (it then reads only gp_core1, in
   RAM, so the flash may be written). 1 = parked, or nothing runs on CPU1; 0 =
   not parked within `ticks` (the request is withdrawn). */
static int core1_park(uint32_t ticks){
 if(!(core1_emu&&video_online))return 1;
 gp_core1.pause_gen++;video_barrier();gp_core1.pause_req=1;
 uint32_t t0=fm1_ticks();
 while(gp_core1.paused_gen!=gp_core1.pause_gen)
  if((uint32_t)(fm1_ticks()-t0)>=ticks){video_barrier();gp_core1.pause_req=0;return 0;}
 video_barrier();return 1;
}
static void core1_unpark(void){video_barrier();gp_core1.pause_req=0;}
static void video_stop(void){
 if(core1_emu&&video_online)(void)core1_park(2400000u);   /* 100 ms; a hung CPU1 is stopped anyway */
 fm1_core1_stop();video_barrier();video_online=0;video_pending=0;video_guard.running=0;
 gp_core1.pause_req=0;
}
static void video_retire(void){
 video_stop();video_guard.barred=1;video_fallbacks++;
}
/* Flash writes (SAVE, settings, the web page's STORE): CPU1 is parked between
   frames (it then reads only gp_core1, in RAM) instead of stopped. On the FM-1 a
   stopped CPU1 did not start again (2026-10-25, on the device: the restart never
   reached gb_core1_start), so each save left the emulator on CPU0, too slow with
   the effects: crackle until power-off. */
static void video_hold(void){
 if(!(core1_emu&&video_online))return;
 if(!core1_park(2400000u)){video_retire_reason=6;video_retire();}   /* not parked in 100 ms: stopped, as before */
}
static void video_release(void){if(core1_emu&&video_online)core1_unpark();}
static void video_start(uint32_t cold){
 if(cold||video_guard.magic!=0x47445634u){video_guard.magic=0x47445634u;video_guard.barred=video_guard.running=0;}
 if(video_guard.running)video_guard.barred=1;
 if(video_guard.barred)return;
 video_guard.running=1;video_faults=fm1_core1_fault.count;
 /* Up to three tries, CPU1 held in reset longer each time (0, 1, 20 ms): a start
    after a warm reset (an install) failed on the device. video_launch_ready = the
    try that worked (1..3), 0 none: read over USB (diagnostics 7D 'G' 'D'). */
 static const uint32_t hold_ticks[3]={0u,24000u,480000u};
 uint32_t tries=0;video_online=0;
 while(!video_online&&tries<3u){
  fm1_core1_stop();
  {uint32_t t=fm1_ticks();while((uint32_t)(fm1_ticks()-t)<hold_ticks[tries])video_barrier();}
  tries++;
  video_stage=video_core=0;video_ready=0;video_job.request=video_job.complete=video_job.error=0;
  for(uint32_t i=0;i<32;i++)*(volatile uint32_t*)(0x1EEF300u+4*i)=0;
  *(volatile uint32_t*)0x1EEF3C0u|=1u; /* CPU1 branch trace for startup diagnostics. */
  *(volatile uint32_t*)0x01C7FFF8u=(uint32_t)(uintptr_t)gb_core1_start;
  uint32_t div=*(volatile uint32_t*)0x10008u;
  *(volatile uint32_t*)0x10008u=div|8u;video_barrier();
  *(volatile uint32_t*)0x1EEE004u|=8u;*(volatile uint32_t*)0x1EEE004u&=~2u;
  uint32_t start=fm1_ticks();
  while(!video_ready&&(uint32_t)(fm1_ticks()-start)<240000u)video_barrier();
  video_barrier();video_online=video_ready!=0&&video_core==1u;
  video_launch_con=*(volatile uint32_t*)0x1EEE004u;
  video_launch_pc=*(volatile uint32_t*)0x1EEF3C4u;
  video_launch_emu=*(volatile uint32_t*)0x1EEF2D4u;video_launch_dbg=FM1_DBG_MSG;
  *(volatile uint32_t*)0x10008u=div;
 }
 video_launch_ready=video_online?tries:0u;
 if(!video_online){video_retire_reason=1;video_retire();}
}
static void video_submit(const uint16_t *pixels){
#if !GB_SMK37
 video_scale_local(pixels,screen);return;   /* FM-1: always on CPU0 (CPU1 emulates) */
#endif
 if(!video_online){video_scale_local(pixels,screen);return;}
 for(unsigned i=0;i<GB_VIDEO_PIXELS;i++)video_source[i]=pixels[i];
 video_job.hash=video_hash_local(video_source);
 uint32_t next=video_job.request+1u;if(!next)next=1;
 video_job.request_inverse=~next;video_job.error=0;video_started=fm1_ticks();video_pending=next;
 video_barrier();video_job.request=next;video_barrier();
}
/* Returns a complete, stable buffer; a bad worker is held before fallback. */
static int video_complete(void){
 if(!video_pending)return 0;
 video_barrier();
 uint32_t elapsed=(uint32_t)(fm1_ticks()-video_started);
 int fault=fm1_core1_fault.count!=video_faults;
 int result=gb_video_poll(&video_job,video_pending,elapsed,240000u,fault);
 if(result<0){
  video_retire_reason=fault?2:video_job.error?3:4;video_retire_ticks=elapsed;
  video_retire();video_scale_local(video_source,screen);return 1;
 }
 if(result>0){video_barrier();video_pending=0;video_jobs++;return 1;}
 return 0;
}
