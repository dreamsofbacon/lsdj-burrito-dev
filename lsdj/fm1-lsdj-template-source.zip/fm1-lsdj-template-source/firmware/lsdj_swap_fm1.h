/* SPDX-License-Identifier: GPL-3.0-only */
/* The fast LSDj swap on the FM-1 (firmware/lsdj_swap.h, 0.9.98-dev.6): the slot's flash, the chip key, LSDj
   paused and the FM-1 restarted. Included by board.c after the link's hooks (it uses link_state, the save
   store and the screen). Slot builds only (CART_SLOT_CAPACITY).

   The flash write guard (fm1_recovery.h FL_SWAP_OK) opens one sector of the slot around that sector's own
   erase or program, and each is checked against the slot's bounds here first; the slot itself is checked once
   (swap_setup): whole sectors, after all the code (_etext) and before the RAM code's load image (_rt_load). */
#include "lsdj_swap.h"
static lsdj_swap_t swap;
/* The sector buffer: 4 KiB of the screen buffer, the part the save import borrows (board.c LSDJ_SAVE_BUF), since
   neither RAM nor the pool has 4 KiB to spare. Used only while LSDj is paused and CPU1 parked (lsdj_swap.h calls
   swap_begin first): the swap's screen (upd_screen) draws through the buffer's first 10 KiB only, and LSDj's next
   picture covers the whole LCD image again if it carries on. */
#define swap_buf LSDJ_SAVE_BUF
static uint8_t swap_held;   /* LSDj paused and CPU1 parked by swap_begin */
extern uint32_t _etext[],_rt_load[];

static uint32_t swap_flash(void){return (uint32_t)(uintptr_t)cartridge-0x02000000u+0x4000u;}   /* XIP 0x02000000 = flash 0x4000 */
/* once, at start: 1 if this FM-1 can swap (else the link's slot ops answer status 1) */
static int swap_setup(void){
    uintptr_t at=(uintptr_t)cartridge;
    if(!recovery_flash_ok||at<(uintptr_t)_etext||at+CART_SLOT_CAPACITY>(uintptr_t)_rt_load)return 0;
    return lsdj_swap_init(&swap,cartridge,swap_flash(),CART_SLOT_CAPACITY,swap_buf);
}
static int swap_in_slot(uint32_t off,uint32_t n){
    return swap.sectors&&off>=swap.flash&&n<=swap.sectors*LSDJ_SWAP_SECTOR&&off-swap.flash<=swap.sectors*LSDJ_SWAP_SECTOR-n;
}

/* The chip key from the flash head, as the update loader finds it (vendor/felucca/firmware/loader/ldr_core.c
   ldr_chip_key); lsdj_swap.h then proves it on the slot's first sector before anything is erased. */
static int swap_key(uint32_t *key){
    uint8_t e[32],blob[34];
    for(uint32_t off=32;off<0x400u;off+=32u){
        if(ota_fread(off,e,32))return -1;
        ota_jl_enc(e,32);
        if(ota_crc16(e+2,30,0)!=ota_rd16(e))return -2;
        if(!ota_memeq(e+16,(const uint8_t*)"isd_config.ini",15)){
            if(ota_rd16(e+14))return -3;   /* the last entry, not found */
            continue;
        }
        if(ota_fread(ota_rd32(e+4),blob,34)||ota_crc16(blob,32,0)!=ota_rd16(blob+32))return -4;
        uint32_t sum=0,k=0;
        for(unsigned i=0;i<16u;i++)sum+=blob[i];
        sum&=0xFFu;sum=sum>=0xE0u?0xAAu:sum<=0x10u?0x55u:sum;
        for(unsigned i=0;i<16u;i++)if((uint32_t)(blob[16+i]^blob[15-i])<sum)k|=1u<<i;
        *key=k;return 0;
    }
    return -3;
}
static int swap_read(uint32_t off,uint8_t *p,uint32_t n){return ota_fread(off,p,n);}
static int swap_erase(uint32_t off){
    if(!swap_in_slot(off,LSDJ_SWAP_SECTOR)||(off&0xFFFu))return -1;
    uint32_t took;swap_open_lo=off;int rc=fl_erase4k(off,&took);swap_open_lo=0;
    fm1_wdt_feed();return rc;
}
static int swap_prog(uint32_t off,const uint8_t *p,uint32_t n){
    if(!swap_in_slot(off,n)||(off&0xFFFu)+n>LSDJ_SWAP_SECTOR)return -1;
    swap_open_lo=off&~0xFFFu;int rc=fl_write(off,p,n);swap_open_lo=0;
    return rc;
}
/* BEGIN: the songs and effects stored (the swap ends in a restart), LSDj paused, CPU1 parked */
static int swap_begin(void){
    if(link_state.importing||play_save)return -1;
    if(!lsdj_absent){
        gp_pause(1);video_hold();
        int rc=ftl_save_now(&ftl,gp_save_data());
        if(rc>=0&&fx_store()<0)rc=-1;
        if(rc<0){video_release();gp_pause(0);return -1;}
        gp_save_clean();
    }
    while(save_display_ok&&!display_ready())fm1_wdt_feed();   /* no LCD transfer still reading the screen buffer */
    swap_held=1;
    upd_screen("CHANGING LSDJ",0,0);
    return 0;
}
static void swap_resume(void){   /* nothing changed */
    if(!swap_held)return;
    swap_held=0;
    if(lsdj_absent)return;   /* (the add-your-LSDj screen stays as drawn: its own loop draws nothing) */
    lcd_fill(0,0,240,240,0);upd_status_shown=0;   /* as ota_show: LSDj draws the middle rows again */
    video_release();gp_pause(0);
}
static void swap_progress(uint32_t done,uint32_t total){
    upd_screen("CHANGING LSDJ",total?(int32_t)(done*100u/total):0,0);
}
/* as an install's last step (ota_commit): the SPL starts the app again, which checks the new slot */
static void swap_restart(void){
    upd_screen("DONE. RESTARTING",100,0);
    video_stop();audio_stop();gb_bootguard.pending=0;usb_detach();fm1_delay_ms(30);fm1_core_reset();
}
static const lsdj_swap_io_t swap_io={swap_key,swap_read,swap_erase,swap_prog,swap_begin,swap_resume,swap_restart,swap_progress};
static int swap_busy(void){return swap.on||swap.restart;}
