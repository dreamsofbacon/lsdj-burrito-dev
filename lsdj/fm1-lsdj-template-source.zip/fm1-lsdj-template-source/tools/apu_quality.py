"""0.9.98-dev.27: MiniGB's sound nearer a real DMG (used by prepare_apu.py; the vendor copy stays intact).

Colin (2026-11-27): "nowhere near as good as an original, FPGA or even PC emulators". Three things MiniGB gets wrong,
each fixed small enough for the RAM the firmware has left:
 1. aliasing: each sample was meant to be the box average of the channel over its 1/44100 s, but the weight,
    (pos - prev_pos) / freq_inc, is an integer division of a smaller number by a bigger one: always 0. So every channel
    was point-sampled, and its harmonics above 22 kHz folded back as tones that aren't in the music (the fizz on high
    pulses, the WAV and the noise). Here each level's time is weighted by a triangle two samples wide (a box twice
    over: its fold-back falls twice as fast as one box's) and added up, in units of freq_inc >> k (k so that the
    products fit 32 bits); the part for the next sample is carried to it. tests/apu_quality.c measures it.
 2. the WAV volume (NR32) was applied twice: wave_sample shifts by it, then the sample was divided by 1 / 2 / 4 again;
    50 % played at 25 %, 25 % at about 6 %.
 3. the output stage: each channel's DAC gives 0 .. its volume (not a swing round zero), and the DMG's output capacitor
    takes the DC off (SameBoy's charge factor 0.999958 a clock: about 0.99601 a sample at 44.1 kHz, a one-pole
    high-pass near 28 Hz). Done per channel (linear: the same sum), so the split channels the effects get stay round
    zero, mutes don't click, and the peak to peak is MiniGB's.
The pulse and noise channels share one function (the RAM: the noise's own copy of the loop didn't fit).
"""

# the stereo add, exactly as prepare_apu.MIX (split_channels swaps it for APU_OUT)
MIX = ("\t\tsamples[i + 0] += sample * c->on_left * ctx->vol_l;\n"
       "\t\tsamples[i + 1] += sample * c->on_right * ctx->vol_r;\n")

HEAD = """
/* (dev.27) the triangle's part carried to the next sample, per channel, in output units */
static int32_t apu_carry[4];
#define update_noise(ctx, s, n) update_square(ctx, s, 3u, n)   /* (the noise shares the pulses' function) */
/* a place in the sample (pos, 0 .. freq_inc) in 1024ths, by a reciprocal taken once a render: no division per
   sample (a first cut divided 8 times a sample, and CPU1's frames ran long) */
#define APU_T(p) ((((p) >> k) * inv) >> 14)
static inline __attribute__((always_inline)) unsigned apu_k(uint32_t f) {
    unsigned k = 0;
    while ((f >> k) > (1u << 15)) k++;
    return k;
}
"""

# a pulse (ch 0, 1) or the noise (ch 3): high or low between steps
TWO_LEVEL = """static void update_square(struct minigb_apu_ctx *ctx, audio_sample_t *samples,
        const unsigned ch2, unsigned frames)
{
    struct chan *c = &ctx->chans[ch2];
    int32_t *carry = &apu_carry[ch2];

    if (ch2 == 3 && c->freq >= 14)
        c->enabled = 0;
    if (!c->powered || !c->enabled) {
        *carry = 0;
        return;
    }

    if (ch2 == 3) {
        static const uint8_t lfsr_div_lut[] = { 8, 16, 32, 48, 64, 80, 96, 112 };
        /* (LSDJ Burrito) exact, as set_note_freq: 4194304 x 105 fits 32 bits; the whole Hz first was up to 12 %
           off on the slow noises */
        c->freq_inc = DMG_CLOCK_FREQ_U * (uint32_t)(FREQ_INC_REF / AUDIO_SAMPLE_RATE) /
            ((uint32_t)lfsr_div_lut[c->noise.lfsr_div] << c->freq);
    } else
        set_note_freq(c);
    const uint32_t f = c->freq_inc;
    const unsigned k = apu_k(f);
    const uint32_t inv = (1u << 24) / ((f >> k) ? (f >> k) : 1u);

    for (uint_fast16_t i = 0; i < frames * 2u; i += 2) {
        int32_t sample = *carry;
        *carry = 0;
        update_len(ctx, c);
        if (!c->enabled)
            return;

        update_env(c);
        if (!c->volume)
            continue;

        if (ch2 == 0)
            update_sweep(c);

        /* in 1024ths of the sample: s1 the time high; s2 each high part times (its start + its end), so the
           triangle's share for the next sample is s2 / 2048 */
        uint32_t pos = 0, prev_pos = 0, s1 = 0, s2 = 0;

        while (update_freq(c, &pos)) {
            if (c->val > 0) {
                uint32_t a = APU_T(prev_pos), b = APU_T(pos);
                s1 += b - a; s2 += (b - a) * (b + a);
            }
            if (ch2 == 3) {
                c->noise.lfsr_reg = (c->noise.lfsr_reg << 1) | (c->val >= VOL_INIT_MAX/MAX_CHAN_VOLUME);
                unsigned t = c->noise.lfsr_wide ? 13 : 5;
                c->val = !(((c->noise.lfsr_reg >> (t + 1)) ^ (c->noise.lfsr_reg >> t)) & 1) ?
                    VOL_INIT_MAX / MAX_CHAN_VOLUME : VOL_INIT_MIN / MAX_CHAN_VOLUME;
            } else {
                c->square.duty_counter = (c->square.duty_counter + 1) & 7;
                c->val = (c->square.duty & (1 << c->square.duty_counter)) ?
                    VOL_INIT_MAX / MAX_CHAN_VOLUME : VOL_INIT_MIN / MAX_CHAN_VOLUME;
            }
            prev_pos = pos;
        }
        if (c->val > 0) {
            uint32_t a = APU_T(prev_pos);
            s1 += 1024u - a; s2 += (1024u - a) * (1024u + a);
        }
        /* the DAC: 0 .. volume at MiniGB's peak to peak (2 x 273 x 15 / 4) */
        int32_t all = (int32_t)s1, next = (int32_t)(s2 >> 11);
        if (next > all) next = all;
        const int32_t amp = (int32_t)(2 * (VOL_INIT_MAX / MAX_CHAN_VOLUME)) * c->volume / 4;
        sample += (all - next) * amp >> 10;
        *carry = next * amp >> 10;
""" + MIX + """    }
}

"""

WAVE = """static void update_wave(struct minigb_apu_ctx *ctx, audio_sample_t *samples, unsigned frames)
{
    struct chan *c = &ctx->chans[2];
    int32_t *carry = &apu_carry[2];

    if (!c->powered || !c->enabled || !c->volume) {
        *carry = 0;
        return;
    }

    set_note_freq(c);
    c->freq_inc *= 2;
    const uint32_t f = c->freq_inc;
    const unsigned k = apu_k(f);
    const uint32_t inv = (1u << 24) / ((f >> k) ? (f >> k) : 1u);

    for (uint_fast16_t i = 0; i < frames * 2u; i += 2) {
        int32_t sample = *carry;
        *carry = 0;
        update_len(ctx, c);
        if (!c->enabled)
            return;

        /* as the pulse's, each part times its level (0 .. 15, NR32's shift done) */
        uint32_t pos = 0, prev_pos = 0, s1 = 0, s2 = 0;

        c->wave.sample = wave_sample(ctx, c->val, c->volume);

        while (update_freq(c, &pos)) {
            uint32_t a = APU_T(prev_pos), b = APU_T(pos);
            s1 += (b - a) * c->wave.sample; s2 += (b - a) * (b + a) * c->wave.sample;
            c->val = (c->val + 1) & 31;
            c->wave.sample = wave_sample(ctx, c->val, c->volume);
            prev_pos = pos;
        }
        {
            uint32_t a = APU_T(prev_pos);
            s1 += (1024u - a) * c->wave.sample; s2 += (1024u - a) * (1024u + a) * c->wave.sample;
        }
        /* the DAC: 0 .. 15 at MiniGB's step (AUDIO_SAMPLE_MAX / 64 / 4), the volume once (wave_sample); 64ths of a
           level (s1: 1024ths x level; s2 / 2048: 1024ths x level for the next sample) */
        int32_t all = (int32_t)(s1 >> 4), next = (int32_t)(s2 >> 15);
        if (next > all) next = all;
        sample += (all - next) * (AUDIO_SAMPLE_MAX / 64) / 256;
        *carry = next * (AUDIO_SAMPLE_MAX / 64) / 256;
""" + MIX + """    }
}

"""


def fix_quality(text):
    """The triangle-weighted channels (little fold-back), the WAV volume once, unipolar DACs (see the top)."""
    for start, end, new in (('static void update_square(', 'static uint8_t wave_sample(', TWO_LEVEL),
                            ('static void update_wave(', 'static void update_noise(', WAVE),
                            ('static void update_noise(', '/**\n * SDL2 style', '')):
        assert text.count(start) == 1, start
        a = text.index(start); b = text.index(end, a)
        text = text[:a] + new + text[b:]
    assert 'div[c->volume]' not in text and text.count(MIX) == 2
    inc = '#include "minigb_apu.h"\n'
    assert text.count(inc) == 1
    return text.replace(inc, inc + HEAD)


HP_STATE = """#define APU_HP_K 261   /* (dev.27) 65536 x (1 - 0.999958^(4194304 / 44100)): the DMG's output capacitor */
static int32_t apu_hp_x[4], apu_hp_y[4];   /* per channel (split) or per side; y kept x16 */
static inline __attribute__((always_inline)) int16_t apu_hp(unsigned j, int32_t x) {
    int32_t y = apu_hp_y[j];
    y += ((x - apu_hp_x[j]) << 4) - ((y * APU_HP_K) >> 16);
    apu_hp_x[j] = x; apu_hp_y[j] = y;
    y >>= 4;
    return (int16_t)(y > 32767 ? 32767 : y < -32768 ? -32768 : y);
}
"""

HP_RUN = """    if (apu_split) {
        for (unsigned f = 0; f < frames; f++)
            for (unsigned j = 0; j < 4; j++)
                apu_split[f * 5u + j] = apu_hp(j, apu_split[f * 5u + j]);
    }
#if !(defined(GB_HARDWARE) && !GB_SMK37)   /* (the FM-1 always splits) */
    else {
        for (unsigned f = 0; f < frames * 2u; f++)
            stream[f] = apu_hp(f & 1u, stream[f]);
    }
#endif
"""


def fix_output_stage(text):
    """The high-pass after the four channels, on the split or on the stereo stream (after split_channels)."""
    tail = '\tupdate_noise(ctx, stream, frames);\n\tif (apu_split) {\n'
    assert text.count(tail) == 1
    text = text.replace(tail, '\tupdate_noise(ctx, stream, frames);\n' + HP_RUN +
                        '\tif (apu_split) {\n', 1)
    inc = 'void minigb_apu_split(int16_t *out) { apu_split = out; }\n'
    assert text.count(inc) == 1
    return text.replace(inc, inc + HP_STATE)


def reset_hp(text):
    """minigb_apu_audio_init clears the high-pass and the carries too (a reset starts from silence)."""
    sig = 'void minigb_apu_audio_init(struct minigb_apu_ctx *ctx)\n{\n'
    assert text.count(sig) == 1
    return text.replace(sig, sig + '\tmemset(apu_hp_x, 0, sizeof apu_hp_x); memset(apu_hp_y, 0, sizeof apu_hp_y);'
                        ' memset(apu_carry, 0, sizeof apu_carry);\n')
