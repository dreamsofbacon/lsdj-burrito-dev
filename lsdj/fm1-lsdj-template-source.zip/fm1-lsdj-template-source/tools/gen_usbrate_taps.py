#!/usr/bin/env python3
# SPDX-License-Identifier: GPL-3.0-only
"""firmware/lsdj_usbrate_taps.h: the USB audio resampler's taps (firmware/lsdj_usbrate.h), printed as C.
8 taps of a Kaiser-windowed sinc (beta 7, cutoff 0.47 of the sample rate, each phase's taps summing to 1) at 65
places 0, 1/64 .. 1 between the 4th and 5th input frame, Q14. The resampler steps between neighbouring phases
linearly. Within about 0.05 dB to 10 kHz and 0.2 dB at 12 kHz at every place (a 4-point cubic dips 0.7 dB at 10 kHz half way, so the
treble would flutter as the place sweeps round, about 18 times a second at the FM-1's 0.04 %)."""
import math
N, P, BETA, FC = 8, 64, 7.0, 0.47

def i0(x):
    s = t = 1.0
    for k in range(1, 40):
        t *= (x / 2 / k) ** 2
        s += t
    return s

def phase(t):
    taps = []
    for k in range(N):
        x = k - (N // 2 - 1) - t                  # the 4th tap (k = 3) is the frame before the place
        sinc = 1.0 if abs(x) < 1e-12 else math.sin(2 * math.pi * FC * x) / (2 * math.pi * FC * x)
        win = i0(BETA * math.sqrt(max(0.0, 1 - (x / (N / 2)) ** 2))) / i0(BETA)
        taps.append(sinc * win)
    s = sum(taps)
    q = [round(v / s * 16384) for v in taps]
    q[N // 2 - 1 + (1 if t >= 0.5 else 0)] += 16384 - sum(q)   # (the rounding onto the nearest tap: sums to 1 exactly)
    return q

print('/* SPDX-License-Identifier: GPL-3.0-only */')
print('/* Made by tools/gen_usbrate_taps.py: the USB audio resampler\'s taps (lsdj_usbrate.h), Q14, 65 places x 8. */')
print('#pragma once')
print('#include <stdint.h>')
print('static const int16_t lsdj_ur_taps[65][8] = {')
for p in range(P + 1):
    print('    {' + ', '.join(str(v) for v in phase(p / P)) + '},')
print('};')
