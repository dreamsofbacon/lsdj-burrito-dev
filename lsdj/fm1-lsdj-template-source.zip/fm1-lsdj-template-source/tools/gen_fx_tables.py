#!/usr/bin/env python3
# SPDX-License-Identifier: GPL-3.0-only
"""The tables of firmware/lsdj_fx.h's 0.9.98 channel effects (44.1 kHz). Prints them as C.
PHASER: a first-order all-pass's coefficient (t - 1) / (t + 1), t = tan(pi f / 44100), Q14, f = 100 Hz * 60^(i / 127).
VOWEL: for each CUTOFF 0..127, the three formants' trapezoidal SVF coefficients (A. Simper: a1 a2 a3, Q13, Q 4):
A E I O U at Melodee's formants (via Optimist's FRMT), geometric between them, the five vowels spread over 0..127."""
import math
FS = 44100.0
def ph(i):
    t = math.tan(math.pi * 100.0 * 60.0 ** (i / 127.0) / FS)
    return int(round((t - 1) / (t + 1) * 16384))
V = [(800, 1150, 2900), (400, 1700, 2600), (300, 2200, 3000), (500, 800, 2800), (350, 650, 2700)]
def vowel(ci):
    p = ci * 4.0 / 127.0                       # 0 .. 4: A .. U
    v = min(int(p), 3); fr = p - v
    out = []
    for k in range(3):
        f = V[v][k] * (V[v + 1][k] / V[v][k]) ** fr
        g = int(4096 * math.tan(math.pi * f / FS)); den = 4096 + ((g * (g + 1024)) >> 12)
        a1 = (4096 << 13) // den; a2 = (a1 * g) >> 12; a3 = (a2 * g) >> 12
        out += [a1, a2, a3]
    return out
print("static const int16_t lsdj_fx_ph_a[128] = {")
for i in range(0, 128, 16): print("    " + ", ".join(str(ph(j)) for j in range(i, i + 16)) + ",")
print("};")
print("static const int16_t lsdj_fx_vowel[128][9] = {")
for i in range(0, 128, 4): print("    " + ", ".join("{" + ", ".join(map(str, vowel(j))) + "}" for j in range(i, i + 4)) + ",")
print("};")
