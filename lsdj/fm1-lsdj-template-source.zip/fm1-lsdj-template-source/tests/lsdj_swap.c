/* SPDX-License-Identifier: GPL-3.0-only */
/* firmware/lsdj_swap.h: the fast LSDj swap. A simulated 1 MiB flash (the app area encrypted with the chip key,
   an XIP view that decrypts it), real version 2 slots (src/lsdj_slot.h), and a power cut after every flash
   operation: the FM-1 must always start, with the new LSDj, the old one, or none (the add-your-LSDj screen). */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "lsdj_slot.h"
#include "lsdj_swap.h"

static int bad;
#define CHECK(c) do { if (!(c)) { printf("FAIL %s:%d %s\n", __FILE__, __LINE__, #c); bad++; } } while (0)

#define KEY      0x980Fu
#define SLOT_AT  0x14000u               /* as 0.9.98-dev.6 */
#define SECTORS  121u
#define CAP      (SECTORS * LSDJ_SWAP_SECTOR)
static uint8_t raw[0x100000], code0[0x100000];
static uint8_t xip[CAP];                /* the slot as the CPU reads it */
static uint8_t buf[LSDJ_SWAP_SECTOR];
static long ops, cut_at = -1;            /* flash operations so far; the power goes after this many (-1: never) */
static int dead, fail_prog, fail_erase, fail_all, keyrc, began, resumed, restarted;
static uint32_t prog_done, prog_total;

static void xip_sync(uint32_t off, uint32_t n) {   /* what the SFC decrypts (fl_inval drops the old lines) */
    for (uint32_t a = off & ~31u; a < off + n; a += 32u) {
        if (a < SLOT_AT || a >= SLOT_AT + CAP) continue;
        memcpy(xip + (a - SLOT_AT), raw + a, 32);
        lsdj_swap_sfc(xip + (a - SLOT_AT), 32, a - LSDJ_SWAP_APP_LO, KEY);
    }
}
static int in_slot(uint32_t off, uint32_t n) { return off >= SLOT_AT && off + n <= SLOT_AT + CAP; }
static int f_key(uint32_t *k) { *k = KEY; return keyrc; }
static int f_read(uint32_t off, uint8_t *p, uint32_t n) { if (dead) return -1; memcpy(p, raw + off, n); return 0; }
static int f_erase(uint32_t off) {
    if (dead) return -1;
    CHECK(in_slot(off, 4096) && !(off & 4095u));
    if (!in_slot(off, 4096)) return -1;
    if (cut_at >= 0 && ops >= cut_at) {                    /* cut mid-erase: half of it done */
        for (uint32_t i = 0; i < 2048; i++) raw[off + i] = (uint8_t)(raw[off + i] | (uint8_t)rand());
        xip_sync(off, 4096); dead = 1; return -1;
    }
    ops++;
    if (fail_all || (fail_erase && !--fail_erase)) return -1;
    memset(raw + off, 0xff, 4096); xip_sync(off, 4096);
    return 0;
}
static int f_prog(uint32_t off, const uint8_t *p, uint32_t n) {
    if (dead) return -1;
    CHECK(in_slot(off, n) && (off & 255u) + n <= 256u);
    if (!in_slot(off, n)) return -1;
    if (cut_at >= 0 && ops >= cut_at) {                    /* cut mid-program: some bytes */
        for (uint32_t i = 0; i < n / 3u; i++) raw[off + i] &= p[i];
        xip_sync(off, n); dead = 1; return -1;
    }
    ops++;
    if (fail_prog && !--fail_prog) { raw[off] &= (uint8_t)~p[0]; xip_sync(off, n); return 0; }   /* a bad write */
    for (uint32_t i = 0; i < n; i++) raw[off + i] &= p[i];   /* NOR: bits only go to 0 */
    xip_sync(off, n);
    return 0;
}
static int f_begin(void) { began++; return 0; }
static void f_resume(void) { resumed++; }
static void f_restart(void) { restarted++; }
static void f_progress(uint32_t d, uint32_t t) { prog_done = d; prog_total = t; }
static const lsdj_swap_io_t io = {f_key, f_read, f_erase, f_prog, f_begin, f_resume, f_restart, f_progress};

/* a version 2 slot: banks of seed-dependent lengths and bytes, CRCs right; capacity bytes, 0xFF after */
static void make_slot(uint8_t *w, unsigned seed, unsigned banks) {
    memset(w, 0xff, CAP);
    memcpy(w, "LSDJSLOT", 8);
    w[8] = 2; w[9] = 0; w[10] = 32; w[11] = 0; w[12] = (uint8_t)banks; w[13] = 0; w[14] = 1; w[15] = 0;
    for (unsigned b = 0; b < 128; b++) w[20 + b] = b < banks ? (uint8_t)b : 0xff;
    memset(w + 148, 0, 252 - 148);
    w[148] = 1;
    uint32_t at = 0, table = 8u * banks, data_off = LSDJ_SLOT_HDR + table;
    srand(seed);
    for (unsigned b = 0; b < banks; b++) {
        uint32_t n = b < 13 ? 16384u : 4000u + (uint32_t)(rand() % 12000);
        uint8_t *t = w + LSDJ_SLOT_HDR + 8u * b;
        t[0] = (uint8_t)at; t[1] = (uint8_t)(at >> 8); t[2] = (uint8_t)(at >> 16); t[3] = (uint8_t)(at >> 24);
        t[4] = (uint8_t)n; t[5] = (uint8_t)(n >> 8); t[6] = 0; t[7] = 0;
        for (uint32_t i = 0; i < n; i++) w[data_off + at + i] = (uint8_t)(b < 13 ? (i * 7u + b) : (rand() ^ seed));
        at += n;
    }
    w[153] = (uint8_t)at; w[154] = (uint8_t)(at >> 8); w[155] = (uint8_t)(at >> 16); w[156] = (uint8_t)(at >> 24);
    uint32_t c = lsdj_slot_crc32(0, w + LSDJ_SLOT_HDR, data_off + at - LSDJ_SLOT_HDR);
    w[16] = (uint8_t)c; w[17] = (uint8_t)(c >> 8); w[18] = (uint8_t)(c >> 16); w[19] = (uint8_t)(c >> 24);
    c = lsdj_slot_crc32(0, w, 252);
    w[252] = (uint8_t)c; w[253] = (uint8_t)(c >> 8); w[254] = (uint8_t)(c >> 16); w[255] = (uint8_t)(c >> 24);
}

/* the flash as an install leaves it: some code bytes everywhere, this slot, the app area encrypted */
static void install(const uint8_t *slot) {
    srand(99);
    for (uint32_t i = 0; i < sizeof raw; i++) raw[i] = (uint8_t)rand();
    memcpy(raw + SLOT_AT, slot, CAP);
    lsdj_swap_sfc(raw + LSDJ_SWAP_APP_LO, LSDJ_SWAP_APP_HI - LSDJ_SWAP_APP_LO, 0, KEY);
    memcpy(code0, raw, sizeof raw);
    xip_sync(SLOT_AT, CAP);
    ops = 0; cut_at = -1; dead = 0; fail_prog = fail_erase = fail_all = 0; keyrc = 0;
    began = resumed = restarted = 0; prog_done = prog_total = 0;
}

static uint32_t now;
static int op(lsdj_swap_t *s, unsigned o, const uint8_t *d, uint32_t dn, uint8_t *out, uint32_t *on) {
    now += 5;
    return lsdj_swap_op(s, &io, o, d, dn, now, out, on);
}
static int write_sector(lsdj_swap_t *s, const uint8_t *img, unsigned k) {
    uint8_t d[2 + LSDJ_SWAP_PART], out[128]; uint32_t on; int st = 0;
    for (unsigned p = 0; p < LSDJ_SWAP_PARTS && !st; p++) {
        d[0] = (uint8_t)k; d[1] = (uint8_t)p;
        memcpy(d + 2, img + k * LSDJ_SWAP_SECTOR + p * LSDJ_SWAP_PART, LSDJ_SWAP_PART);
        st = op(s, LSDJ_SWAP_WRITE, d, sizeof d, out, &on);
    }
    return st;
}
/* which sectors differ, as the page finds out from INFO */
static unsigned differing(lsdj_swap_t *s, const uint8_t *img, uint8_t *diff) {
    uint8_t out[128], d[1]; uint32_t on; unsigned n = 0;
    for (unsigned first = 0; first < SECTORS; first += LSDJ_SWAP_SUMS) {
        d[0] = (uint8_t)first;
        CHECK(op(s, LSDJ_SWAP_INFO, d, 1, out, &on) == 0);
        CHECK(lsdj_swap_rd32(out) == CAP && out[4] == SECTORS && out[5] == first);
        for (unsigned k = first; k < SECTORS && k < first + LSDJ_SWAP_SUMS; k++) {
            uint32_t want = lsdj_swap_crc32(0, img + k * LSDJ_SWAP_SECTOR, LSDJ_SWAP_SECTOR);
            diff[k] = lsdj_swap_rd32(out + 6 + 4 * (k - first)) != want;
            n += diff[k];
        }
    }
    return n;
}
/* the whole swap, as the page does it; 0 = ok, else the first bad status */
static int swap(lsdj_swap_t *s, const uint8_t *img) {
    uint8_t diff[SECTORS], d[5], out[128]; uint32_t on, crc = lsdj_swap_crc32(0, img, CAP);
    unsigned n = differing(s, img, diff);
    if (!n) return 0;
    d[0] = (uint8_t)crc; d[1] = (uint8_t)(crc >> 8); d[2] = (uint8_t)(crc >> 16); d[3] = (uint8_t)(crc >> 24); d[4] = (uint8_t)n;
    int st = op(s, LSDJ_SWAP_BEGIN, d, 5, out, &on);
    for (unsigned k = 1; k < SECTORS && !st; k++) if (diff[k]) st = write_sector(s, img, k);
    if (!st && diff[0]) st = write_sector(s, img, 0);
    if (!st) st = op(s, LSDJ_SWAP_END, 0, 0, out, &on);
    return st;
}
/* power on: what the firmware finds in the slot. 1 new, 2 old, 0 none (add your LSDj); the code untouched */
static int boot(const uint8_t *old, const uint8_t *nw) {
    lsdj_slot_t sl;
    for (uint32_t i = 0; i < sizeof raw; i++)
        if ((i < SLOT_AT || i >= SLOT_AT + CAP) && raw[i] != code0[i]) { CHECK(!"code changed"); return -1; }
    if (lsdj_slot_parse(xip, CAP, &sl) != LSDJ_SLOT_OK) return 0;
    if (!memcmp(xip, nw, sl.total)) return 1;
    if (!memcmp(xip, old, sl.total)) return 2;
    CHECK(!"a slot that checks out but is neither");
    return -1;
}

static uint8_t A[CAP], B[CAP], C[CAP];

int main(void) {
    lsdj_swap_t s;
    uint8_t out[128], d[2 + LSDJ_SWAP_PART]; uint32_t on;
    {   /* the cipher: the packager's (vendor/felucca/tools/fm1pkg_make.py sfc, key 0x980F) */
        static const char *v1 = "0f3e7cdebe71eef6eacd823a4faa40932861d3b052990e061b1f16032c7dffdd"
                                "270e7cbe1e51ced6caeda21a6fab223700709154fa884ce2924cd0ef946dbf3d";
        static const char *v2 = "f0c0812264c993062c59b3468d3a75cab469f2c48913274f9f3f5ebd7bf7effe";
        uint8_t b[64]; char h[129];
        for (unsigned i = 0; i < 64; i++) b[i] = (uint8_t)i;
        lsdj_swap_sfc(b, 64, 0x10000u - 0x4000u, KEY);
        for (unsigned i = 0; i < 64; i++) sprintf(h + 2 * i, "%02x", b[i]);
        CHECK(!strcmp(h, v1));
        memset(b, 0xff, 32);
        lsdj_swap_sfc(b, 32, 0x8C000u - 0x4000u, KEY);
        for (unsigned i = 0; i < 32; i++) sprintf(h + 2 * i, "%02x", b[i]);
        CHECK(!strcmp(h, v2));
    }
    make_slot(A, 1, 30); make_slot(B, 2, 30); make_slot(C, 3, 22);
    {   /* init: whole sectors inside the encrypted app area only */
        CHECK(lsdj_swap_init(&s, xip, SLOT_AT, CAP, buf));
        CHECK(!lsdj_swap_init(&s, xip, SLOT_AT + 256, CAP, buf));
        CHECK(!lsdj_swap_init(&s, xip, SLOT_AT, CAP - 256, buf));
        CHECK(!lsdj_swap_init(&s, xip, 0x90000, 0x4000, buf));
        CHECK(!lsdj_swap_init(&s, xip, 0x3000, 0x1000, buf));
        d[0] = 0; CHECK(lsdj_swap_op(&s, &io, LSDJ_SWAP_INFO, d, 1, 0, out, &on) == LSDJ_SWAP_BAD);
    }
    {   /* A to B: only the sectors that differ, then the FM-1 restarts on B */
        install(A); lsdj_swap_init(&s, xip, SLOT_AT, CAP, buf);
        CHECK(boot(A, B) == 2);
        CHECK(swap(&s, B) == 0);
        CHECK(began == 1 && !resumed && !restarted && prog_total && prog_done == prog_total);
        lsdj_swap_poll(&s, &io, now + 100); CHECK(!restarted);
        lsdj_swap_poll(&s, &io, now + LSDJ_SWAP_RESTART_MS); CHECK(restarted == 1);
        CHECK(boot(A, B) == 1);
        uint8_t e[CAP]; memcpy(e, B, CAP); lsdj_swap_sfc(e, CAP, SLOT_AT - LSDJ_SWAP_APP_LO, KEY);
        CHECK(!memcmp(raw + SLOT_AT, e, CAP));   /* as an install would have written it */
        d[0] = 0; CHECK(op(&s, LSDJ_SWAP_INFO, d, 1, out, &on) == LSDJ_SWAP_STATE);   /* restarting */
    }
    {   /* B to C (fewer banks), and then to the same again: nothing to send */
        install(B); lsdj_swap_init(&s, xip, SLOT_AT, CAP, buf);
        CHECK(swap(&s, C) == 0 && boot(B, C) == 1);
        lsdj_swap_init(&s, xip, SLOT_AT, CAP, buf);
        uint8_t diff[SECTORS]; CHECK(differing(&s, C, diff) == 0);
    }
    {   /* to an empty template and from one (the add-your-LSDj screen's slot: all 0xFF) */
        static uint8_t E[CAP]; memset(E, 0xff, CAP);
        install(E); lsdj_swap_init(&s, xip, SLOT_AT, CAP, buf);
        CHECK(boot(E, A) == 0);
        CHECK(swap(&s, A) == 0 && boot(E, A) == 1);
    }
    {   /* the wrong key, or none: status 4, nothing erased, LSDj carries on (paused only for the check) */
        install(A); lsdj_swap_init(&s, xip, SLOT_AT, CAP, buf);
        uint32_t crc = lsdj_swap_crc32(0, B, CAP);
        uint8_t q[5] = {(uint8_t)crc, (uint8_t)(crc >> 8), (uint8_t)(crc >> 16), (uint8_t)(crc >> 24), 3};
        raw[SLOT_AT + 100] ^= 1;   /* the raw bytes no longer match the plain view encrypted */
        CHECK(op(&s, LSDJ_SWAP_BEGIN, q, 5, out, &on) == LSDJ_SWAP_FLASH && began == 1 && resumed == 1 && ops == 0);
        raw[SLOT_AT + 100] ^= 1;
        keyrc = -3;
        CHECK(op(&s, LSDJ_SWAP_BEGIN, q, 5, out, &on) == LSDJ_SWAP_FLASH && began == 2 && resumed == 2 && ops == 0);
        d[0] = 0; CHECK(op(&s, LSDJ_SWAP_INFO, d, 1, out, &on) == 0);   /* not left half begun */
        keyrc = 0;
        began = resumed = 0;
        q[4] = 0; CHECK(op(&s, LSDJ_SWAP_BEGIN, q, 5, out, &on) == LSDJ_SWAP_BAD);
        q[4] = SECTORS + 1; CHECK(op(&s, LSDJ_SWAP_BEGIN, q, 5, out, &on) == LSDJ_SWAP_BAD);
        CHECK(op(&s, LSDJ_SWAP_BEGIN, q, 4, out, &on) == LSDJ_SWAP_BAD);
        CHECK(boot(A, B) == 2);
    }
    {   /* order and lengths */
        install(A); lsdj_swap_init(&s, xip, SLOT_AT, CAP, buf);
        memset(d, 0, sizeof d);
        CHECK(op(&s, LSDJ_SWAP_WRITE, d, sizeof d, out, &on) == LSDJ_SWAP_STATE);   /* no BEGIN */
        CHECK(op(&s, LSDJ_SWAP_END, 0, 0, out, &on) == LSDJ_SWAP_STATE);
        uint8_t q[5] = {0, 0, 0, 0, 2};
        CHECK(op(&s, LSDJ_SWAP_BEGIN, q, 5, out, &on) == 0 && began == 1);
        CHECK(op(&s, LSDJ_SWAP_BEGIN, q, 5, out, &on) == LSDJ_SWAP_STATE);
        d[0] = 0; CHECK(op(&s, LSDJ_SWAP_INFO, d, 1, out, &on) == LSDJ_SWAP_STATE);
        d[0] = 5; d[1] = 1; CHECK(op(&s, LSDJ_SWAP_WRITE, d, sizeof d, out, &on) == LSDJ_SWAP_BAD);   /* part 1 first */
        d[0] = SECTORS; d[1] = 0; CHECK(op(&s, LSDJ_SWAP_WRITE, d, sizeof d, out, &on) == LSDJ_SWAP_BAD);
        d[0] = 5; d[1] = 32; CHECK(op(&s, LSDJ_SWAP_WRITE, d, sizeof d, out, &on) == LSDJ_SWAP_BAD);
        d[0] = 5; d[1] = 0; CHECK(op(&s, LSDJ_SWAP_WRITE, d, sizeof d - 1, out, &on) == LSDJ_SWAP_BAD);
        CHECK(op(&s, LSDJ_SWAP_WRITE, d, sizeof d, out, &on) == 0);
        CHECK(op(&s, LSDJ_SWAP_WRITE, d, sizeof d, out, &on) == 0);                 /* the last part again */
        d[1] = 2; CHECK(op(&s, LSDJ_SWAP_WRITE, d, sizeof d, out, &on) == LSDJ_SWAP_BAD);   /* a gap */
        CHECK(ops == 0);                                                             /* nothing written yet */
        CHECK(write_sector(&s, B, 0) == 0);                                          /* the header: kept */
        CHECK(ops == 0);
        d[0] = 31; d[1] = 31; d[0] = 0;
        memcpy(d + 2, B + 31 * LSDJ_SWAP_PART, LSDJ_SWAP_PART);
        CHECK(op(&s, LSDJ_SWAP_WRITE, d, sizeof d, out, &on) == 0);                 /* its last part again */
        CHECK(write_sector(&s, B, 7) == LSDJ_SWAP_STATE);                            /* another after the header */
        CHECK(op(&s, LSDJ_SWAP_END, d, 1, out, &on) == LSDJ_SWAP_BAD);
        /* END with the header only: written, the CRC (of 0 given) does not match: status 3, a restart */
        CHECK(op(&s, LSDJ_SWAP_END, 0, 0, out, &on) == LSDJ_SWAP_CRC);
        lsdj_swap_poll(&s, &io, now + 1000); CHECK(restarted == 1);
        CHECK(boot(A, B) == 0);   /* B's header over A's data: the data CRC fails, no LSDj, never a crash */
    }
    {   /* BEGIN then END, nothing sent: LSDj carries on */
        install(A); lsdj_swap_init(&s, xip, SLOT_AT, CAP, buf);
        uint8_t q[5] = {0, 0, 0, 0, 1};
        CHECK(op(&s, LSDJ_SWAP_BEGIN, q, 5, out, &on) == 0);
        CHECK(op(&s, LSDJ_SWAP_END, 0, 0, out, &on) == 0 && resumed == 1);
        lsdj_swap_poll(&s, &io, now + 100000); CHECK(!restarted && ops == 0);
        CHECK(op(&s, LSDJ_SWAP_BEGIN, q, 5, out, &on) == 0 && began == 2);         /* and again */
    }
    {   /* the page goes away: before any write LSDj carries on; after one, a restart (to no LSDj) */
        install(A); lsdj_swap_init(&s, xip, SLOT_AT, CAP, buf);
        uint8_t q[5] = {0, 0, 0, 0, 3};
        CHECK(op(&s, LSDJ_SWAP_BEGIN, q, 5, out, &on) == 0);
        lsdj_swap_poll(&s, &io, now + LSDJ_SWAP_TIMEOUT_MS / 2); CHECK(!resumed);
        lsdj_swap_poll(&s, &io, now + LSDJ_SWAP_TIMEOUT_MS + 1); CHECK(resumed == 1 && !restarted);
        CHECK(op(&s, LSDJ_SWAP_BEGIN, q, 5, out, &on) == 0);
        CHECK(write_sector(&s, B, 9) == 0);
        lsdj_swap_poll(&s, &io, now + LSDJ_SWAP_TIMEOUT_MS + 1);
        lsdj_swap_poll(&s, &io, now + LSDJ_SWAP_TIMEOUT_MS + 1 + LSDJ_SWAP_RESTART_MS); CHECK(restarted == 1 && resumed == 1);
        CHECK(boot(A, B) == 0);
    }
    {   /* flash errors: a sector that does not read back is written again, then status 4; the page resends it */
        install(A); lsdj_swap_init(&s, xip, SLOT_AT, CAP, buf);
        fail_prog = 3;                         /* one bad page: the second try is good */
        CHECK(swap(&s, B) == 0 && boot(A, B) == 1);
        install(A); lsdj_swap_init(&s, xip, SLOT_AT, CAP, buf);
        uint8_t diff[SECTORS]; unsigned n = differing(&s, B, diff);
        uint32_t crc = lsdj_swap_crc32(0, B, CAP);
        uint8_t q[5] = {(uint8_t)crc, (uint8_t)(crc >> 8), (uint8_t)(crc >> 16), (uint8_t)(crc >> 24), (uint8_t)n};
        CHECK(op(&s, LSDJ_SWAP_BEGIN, q, 5, out, &on) == 0);
        fail_erase = 1;                        /* the header's erase fails: status 4 */
        CHECK(write_sector(&s, B, 3) == LSDJ_SWAP_FLASH);
        CHECK(write_sector(&s, B, 3) == 0);    /* sent again: the header erased this time, then sector 3 */
        fail_erase = 1;                        /* sector 4's first erase fails: its second try works */
        CHECK(write_sector(&s, B, 4) == 0);
        fail_all = 1;                          /* sector 5: both tries fail: status 4 */
        CHECK(write_sector(&s, B, 5) == LSDJ_SWAP_FLASH);
        fail_all = 0;
        CHECK(write_sector(&s, B, 5) == 0);
        for (unsigned k = 1; k < SECTORS; k++) if (diff[k] && k != 3 && k != 4 && k != 5) CHECK(write_sector(&s, B, k) == 0);
        CHECK(write_sector(&s, B, 0) == 0);
        fail_all = 1;                          /* END: the header cannot be written: status 4, END again */
        CHECK(op(&s, LSDJ_SWAP_END, 0, 0, out, &on) == LSDJ_SWAP_FLASH);
        lsdj_swap_poll(&s, &io, now + LSDJ_SWAP_RESTART_MS * 2); CHECK(!restarted);
        fail_all = 0;
        CHECK(op(&s, LSDJ_SWAP_END, 0, 0, out, &on) == 0);
        lsdj_swap_poll(&s, &io, now + LSDJ_SWAP_RESTART_MS); CHECK(restarted == 1);
        CHECK(boot(A, B) == 1);
    }
    {   /* the power goes after every flash operation (mid-erase or mid-program): it always starts */
        install(A); lsdj_swap_init(&s, xip, SLOT_AT, CAP, buf);
        CHECK(swap(&s, B) == 0);
        long total = ops, seen[3] = {0, 0, 0};
        for (long cut = 0; cut <= total; cut++) {
            install(A); lsdj_swap_init(&s, xip, SLOT_AT, CAP, buf); cut_at = cut;
            swap(&s, B);
            int b = boot(A, B);
            CHECK(b >= 0);
            if (b >= 0) seen[b]++;
            CHECK(b == (cut < total ? 0 : 1));      /* nothing checks out until the header's page 0, the last */
        }
        CHECK(seen[0] == total && seen[1] == 1 && seen[2] == 0);
        printf("power cuts: %ld points, %ld no LSDj, %ld new\n", total + 1, seen[0], seen[1]);
        /* and after the cut, the swap again from the add-your-LSDj state */
        install(A); lsdj_swap_init(&s, xip, SLOT_AT, CAP, buf); cut_at = total / 2;
        swap(&s, B); dead = 0; cut_at = -1;
        CHECK(boot(A, B) == 0);
        lsdj_swap_init(&s, xip, SLOT_AT, CAP, buf);
        CHECK(swap(&s, B) == 0 && boot(A, B) == 1);
    }
    printf("%s lsdj_swap\n", bad ? "FAIL" : "PASS");
    return bad != 0;
}
