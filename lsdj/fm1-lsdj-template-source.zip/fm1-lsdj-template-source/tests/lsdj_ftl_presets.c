/* SPDX-License-Identifier: GPL-3.0-only */
/* Host test for the save store's block 32, the presets page (firmware/lsdj_ftl.h, 0.9.98-dev.6): an empty page is
   never written; a page saved alone, with the songs, while playing (no erase) and cut off at every flash op comes
   back whole or as before, songs untouched; a build without the page's RAM loads the songs and keeps the page;
   compaction carries it. Usage: lsdj_ftl_presets */
#include <assert.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

static uint8_t flash[0x100000];
static long ops_left = -1;
static unsigned long outside, erase_total;
static int cut(void) { if (ops_left == 0) return 1; if (ops_left > 0) ops_left--; return 0; }
static int sim_erase(uint32_t off) {
    if (cut()) return -9;
    if ((off & 0xFFFu) || off < 0x97000u || off + 0x1000u > 0xE0000u) { outside++; return -1; }
    erase_total++;
    memset(flash + off, 0xFF, 0x1000u); return 0;
}
static int sim_write(uint32_t off, const uint8_t *p, uint32_t n) {
    if (off < 0x97000u || off + n > 0xE0000u) { outside++; return -1; }
    for (uint32_t i = 0; i < n; i++) {
        if ((i & 255u) == 0 && cut()) {
            uint32_t torn = (uint32_t)rand() % 256u;
            for (uint32_t k = 0; k < torn && i + k < n; k++) flash[off + i + k] &= p[i + k];
            return -9;
        }
        flash[off + i] &= p[i];
    }
    return 0;
}
static int sim_read(uint32_t off, uint8_t *p, uint32_t n) { memcpy(p, flash + off, n); return 0; }
#define LSDJ_FL_ERASE(off) sim_erase(off)
#define LSDJ_FL_WRITE(off, p, n) sim_write(off, p, n)
#define LSDJ_FL_READ(off, p, n) sim_read(off, p, n)
#define LSDJ_FL_IDLE() ((void)0)
#include "../firmware/lsdj_ftl.h"

#define PAGE 1040u   /* lsdj_presets.h's page: a 16-byte head and 8 slots of 128 */
static uint8_t ram[131072], prev[131072], boot_ram[131072];
static uint8_t page[PAGE], page_prev[PAGE], empty[PAGE];
static ftl_t F, B;

static void fill(uint8_t *p, uint32_t n) { for (uint32_t i = 0; i < n; i++) p[i] = (uint8_t)rand(); }
/* a reboot (with the page's RAM): songs and page as wanted */
static int reboot_is(const uint8_t *want_ram, const uint8_t *want_page) {
    static uint8_t keep[PAGE]; memcpy(keep, page, PAGE);
    memset(boot_ram, 0, sizeof boot_ram);
    int ok = ftl_boot(&B, boot_ram) == 1 && !memcmp(boot_ram, want_ram, sizeof boot_ram) && !memcmp(page, want_page, PAGE);
    memcpy(page, keep, PAGE);
    return ok;
}

int main(void) {
    memset(flash, 0xFF, sizeof flash); memset(empty, 0xFF, sizeof empty);
    srand(77);
    fill(ram, sizeof ram);
    ftl_x_set(page, PAGE);
    assert(ftl_format(&F, ram, NULL) == 0);
    assert(ftl_boot(&F, ram) == 1 && !memcmp(page, empty, PAGE));
    assert(!(ftl_changed(&F, ram) & FTL_BIT(FTL_XBLOCK)) && ftl_save_now(&F, ram) == 0);
    puts("no presets page stored: an empty page, never written                ok");

    /* the page alone (as board.c after EDIT+SELECT+key): songs untouched */
    fill(page, PAGE); memcpy(prev, ram, sizeof ram);
    assert(ftl_changed(&F, ram) == FTL_BIT(FTL_XBLOCK));
    assert(ftl_save_mask(&F, ram, FTL_BIT(FTL_XBLOCK)) == 1 && ftl_changed(&F, ram) == 0);
    assert(reboot_is(prev, page));
    /* the songs alone: the page as stored before */
    memcpy(page_prev, page, PAGE); page[5] ^= 1u; ram[4096 * 3 + 9] ^= 1u;
    assert(ftl_save_mask(&F, ram, ~FTL_BIT(FTL_XBLOCK)) == 1 && ftl_changed(&F, ram) == FTL_BIT(FTL_XBLOCK));
    assert(reboot_is(ram, page_prev));
    /* SAVE (everything) */
    assert(ftl_save_now(&F, ram) == 1 && reboot_is(ram, page));
    puts("page saved alone, songs alone, both with SAVE                        ok");

    /* while playing: ftl_begin + a step a frame, never an erase */
    for (int round = 0; round < 50; round++) {
        assert(ftl_boot(&F, ram) == 1);
        while (ftl_count(&F, FTL_DIRTY)) ftl_step(&F, ram, 1);
        fill(page + (uint32_t)rand() % (PAGE - 8u), 8);
        assert(ftl_begin(&F, ftl_changed(&F, ram) & FTL_BIT(FTL_XBLOCK)) == 0);
        unsigned long e0 = erase_total; int committed = 0;
        while (ftl_busy(&F)) { int r = ftl_step(&F, ram, 0); assert(r >= 0); committed |= r == 1; }
        assert(committed && erase_total == e0 && reboot_is(ram, page));
    }
    puts("page saved while playing: 50 saves, no erase                        ok");

    /* power cut at each flash op of a page save: the old page or the new, songs intact */
    {
        unsigned o = 0, n = 0;
        for (long at = 0;; at++) {
            assert(ftl_boot(&F, ram) == 1);   /* what is stored now: songs and page */
            memcpy(page_prev, page, PAGE); memcpy(prev, ram, sizeof ram);
            fill(page, PAGE);
            static uint8_t want[PAGE]; memcpy(want, page, PAGE);
            ops_left = at; int r = ftl_save_mask(&F, ram, FTL_BIT(FTL_XBLOCK)); int finished = ops_left != 0; ops_left = -1;
            if (reboot_is(prev, page_prev)) o++; else { assert(reboot_is(prev, want)); n++; }
            if (finished) { assert(r == 1 && reboot_is(prev, want)); break; }
        }
        printf("power cut during a page save: old page %u times, new %u times, songs intact  ok\n", o, n);
    }

    /* a build without the page's RAM: songs load, the page's sector stays live through saves and erases */
    {
        assert(ftl_boot(&F, ram) == 1);
        memcpy(page_prev, page, PAGE);
        ftl_x_set(NULL, 0);
        assert(ftl_boot(&F, boot_ram) == 1 && !memcmp(boot_ram, ram, sizeof ram));
        assert(!(ftl_changed(&F, ram) & FTL_BIT(FTL_XBLOCK)));
        for (int i = 0; i < 40; i++) { ram[(uint32_t)rand() % sizeof ram] ^= 0x10u; assert(ftl_save_now(&F, ram) == 1); }
        uint32_t gen0 = F.map_gen;
        for (uint32_t i = 0; F.map_gen == gen0 && i < 400; i++) assert(ftl_put_record(&F, 1, 0xC0000000u + i) == 0);
        assert(F.map_gen != gen0);   /* compacted without the page's RAM */
        ftl_x_set(page, PAGE); memset(page, 0, PAGE);
        assert(reboot_is(ram, page_prev));
        puts("without the page's RAM: songs load, page kept through 40 saves and a compaction  ok");
    }
    /* compaction with it: carried */
    {
        assert(ftl_boot(&F, ram) == 1);
        uint32_t gen0 = F.map_gen;
        for (uint32_t i = 0; F.map_gen == gen0 && i < 400; i++) assert(ftl_put_record(&F, 2, 0xD0000000u + i) == 0);
        assert(F.map_gen != gen0 && reboot_is(ram, page));
        puts("compaction carries the page                                          ok");
    }
    assert(outside == 0);
    puts("all flash access inside 0x97000..0xE0000                             ok");
    puts("lsdj_ftl_presets test passed");
    return 0;
}
