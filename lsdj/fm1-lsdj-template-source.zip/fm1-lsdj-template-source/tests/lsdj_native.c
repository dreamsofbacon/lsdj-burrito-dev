/* SPDX-License-Identifier: GPL-3.0-only */
/* Host test for firmware/lsdj_native.h: the panel stays inside the 160x144 picture
   and LSDj's right panel (columns 16..19), uses LSDj's font tiles for its
   characters, inverts the turned knob's value. Real LSDj: harness/native_shots.sh. */
#include <assert.h>
#include <stdio.h>
#include <string.h>
#include "lsdj_native.h"
#include "lsdj_fx_ui.h"
#include "lsdj_theme.h"

static uint16_t buf[160 * 144 + 2 * 1024];
static uint8_t vram[0x2000];
static const uint16_t shades[4] = {0x1111, 0x2222, 0x3333, 0x4444};
#define CANARY 0x5A5Au

int main(void) {
    uint16_t *px = buf + 1024;
    for (unsigned i = 0; i < sizeof vram; i++) vram[i] = (uint8_t)(i * 7u + 3u);   /* any "font" */
    lsdj_nat_t n = {px, vram, 0xC3, 0xE4, shades};
    /* tiles: letters, digits, the few symbols */
    assert(lsdj_nat_tile('A') == 0x0E && lsdj_nat_tile('Z') == 0x27 && lsdj_nat_tile('0') == 0x04 && lsdj_nat_tile('9') == 0x0D);
    assert(lsdj_nat_tile('-') == 0x28 && lsdj_nat_tile('/') == 0x47 && lsdj_nat_tile(' ') == 0x03 && lsdj_nat_tile('+') == 0x3C && lsdj_nat_tile('#') == 0x29);
    assert(lsdj_nat_field_tile('0') == 0x49 && lsdj_nat_field_tile('A') == 0x53 && lsdj_nat_field_tile(' ') == 0x48 && lsdj_nat_field_tile('/') == 0x47);
    assert(lsdj_nat_tile('(') == 0x03);
    static uint8_t echo[LSDJ_FX_ECHO_LEN]; lsdj_fx_t fx; lsdj_fx_ui_t u; lsdj_fx_init(&fx, echo); lsdj_fx_ui_init(&u); u.cursor_ch = 3;
    for (unsigned pg = 0; pg < LSDJ_FX_PAGES; pg++)
        for (int hot = -1; hot < 4; hot++) {
            for (unsigned i = 0; i < 1024; i++) buf[i] = buf[1024 + 160 * 144 + i] = CANARY;
            for (unsigned i = 0; i < 160 * 144; i++) px[i] = 0x7777;
            lsdj_ov_bars_t b; memset(&b, 0, sizeof b);
            u.page = (uint8_t)pg; b.hot = (int8_t)hot; b.chan = 3;
            lsdj_fx_bars(&fx, &u, hot, b.title, b.big, b.label, b.value, b.caption, b.level);
            lsdj_fx_bar_choices(&fx, &u, b.nchoice, b.pick, b.choice);
            b.amount_scale = 1;
            lsdj_nat_bars(&n, &b, 0xFD20);
            for (unsigned i = 0; i < 1024; i++) assert(buf[i] == CANARY && buf[1024 + 160 * 144 + i] == CANARY);
            for (unsigned y = 0; y < 144; y++) for (unsigned x = 120; x < 160; x++) assert(px[y * 160 + x] == 0x7777);   /* right panel and screen map kept */
            assert(strlen(b.title) <= LSDJ_NAT_COLS && strlen(b.big) <= LSDJ_NAT_COLS);
            for (unsigned k = 0; k < 4; k++) assert(strlen(b.label[k]) <= 5 && strlen(b.value[k]) <= 5);
        }
    /* A list and a message stay inside the picture too. */
    {
        char lines[9][20] = {"SETTINGS", "PRESETS: UP/DOWN", "A", "B", "C", "D", "E", "F", "SELECT=PICK K1=SET"};
        for (unsigned i = 0; i < 1024; i++) buf[i] = buf[1024 + 160 * 144 + i] = CANARY;
        lsdj_nat_list(&n, (const char (*)[20])lines, 9, 2);
        lsdj_nat_message(&n, "SETTINGS NOT SAVED", "FLASH ERROR");
        lsdj_nat_mode(&n, 2, 1);
        for (unsigned i = 0; i < 1024; i++) assert(buf[i] == CANARY && buf[1024 + 160 * 144 + i] == CANARY);
    }
    /* A list longer than rows 2..16 scrolls: with the last of 20 entries selected it
       shows entries 5..19, exactly as a 15-entry list of those with the last selected. */
    {
        static char big[22][20], part[17][20];
        static uint16_t a[160 * 144];
        for (unsigned i = 0; i < 22; i++) snprintf(big[i], 20, "LINE %u", i);
        memcpy(part[0], big[0], 20); memcpy(part[16], big[21], 20);
        for (unsigned i = 0; i < 15; i++) memcpy(part[1 + i], big[1 + 5 + i], 20);
        lsdj_nat_list(&n, (const char (*)[20])big, 22, 19); memcpy(a, px, sizeof a);
        lsdj_nat_list(&n, (const char (*)[20])part, 17, 14);
        assert(!memcmp(a, px, sizeof a));
        lsdj_nat_list(&n, (const char (*)[20])big, 22, 3); memcpy(a, px, sizeof a);   /* near the top: no scroll */
        memcpy(part[1], big[1], 20); for (unsigned i = 0; i < 15; i++) memcpy(part[1 + i], big[1 + i], 20);
        lsdj_nat_list(&n, (const char (*)[20])part, 17, 3);
        assert(!memcmp(a, px, sizeof a));
    }
    /* The always-shown names: only the bottom two rows, columns 0..14; the page map:
       only LSDj's screen map (columns 15..19, rows 15..17). */
    for (unsigned pg = 0; pg < LSDJ_FX_PAGES; pg++) {
        for (unsigned i = 0; i < 160 * 144; i++) px[i] = 0x7777;
        char names[4][7]; u.page = (uint8_t)pg; lsdj_fx_names(&u, names);
        for (unsigned k = 0; k < 4; k++) {
            if (lsdj_fx_page_knob[pg][k] == FXK_NONE) assert(!names[k][0]);
            else assert(strlen(names[k]) >= 3 && strlen(names[k]) <= 6);
        }
        lsdj_nat_names(&n, (const char (*)[7])names, (int)pg - 1, 0xFD20);
        { unsigned seen = 0;   /* the names on the bars' colour: the hot one full, the others half */
          for (unsigned i = 0; i < 160 * 144; i++) seen |= (px[i] == 0xFD20) | (px[i] == lsdj_nat_mix(0xFD20, lsdj_nat_col(&n, 0))) << 1;
          assert(seen == (pg >= 1 && pg <= 4 && names[pg - 1][0] ? 3u : 2u)); }
        for (unsigned y = 0; y < 144; y++) for (unsigned x = 0; x < 160; x++)
            assert((px[y * 160 + x] != 0x7777) == (y >= 128 && x < 120));
        for (unsigned i = 0; i < 160 * 144; i++) px[i] = 0x7777;
        lsdj_nat_pagemap(&n, lsdj_fx_page_letters, pg);
        for (unsigned y = 0; y < 144; y++) for (unsigned x = 0; x < 160; x++)
            if (!(y >= 120 && x >= 120)) assert(px[y * 160 + x] == 0x7777);
        uint16_t actual[64];
        unsigned x0 = 8u * (15u + pg % 5u), y0 = 8u * (16u + pg / 5u);
        for (unsigned y = 0; y < 8; y++) memcpy(actual + y * 8, px + (y0 + y) * 160 + x0, 16);
        lsdj_nat_tile_at(&n, 15u + pg % 5u, 16u + pg / 5u, lsdj_nat_field_tile(lsdj_fx_page_letters[pg]) + 0x45);
        for (unsigned y = 0; y < 8; y++) assert(!memcmp(actual + y * 8, px + (y0 + y) * 160 + x0, 16));
    }
    assert(strlen(lsdj_fx_page_letters) == LSDJ_FX_PAGES);
    /* 0..127 values show as two hex digits, as LSDj's. */
    { char v[6]; fx.p.ch[3][FXP_CUTOFF] = 0x4F; u.page = 0; lsdj_fxk_value(&fx, &u, FXK_CUTOFF, v); assert(!strcmp(v, "4F")); }
    /* Eight 0x10 segments: exact boundaries, partial fill and full-scale 7F. */
    n.lcdc |= 0x10;
    for (unsigned v = 0; v < 128u; v++) {
        lsdj_ov_bars_t b = {0}; b.amount_scale = 1; b.hot = -1; b.chan = -1;
        strcpy(b.label[0], "CT"); b.level[0] = (uint8_t)v;
        lsdj_nat_bars(&n, &b, 0xFD20);
        for (unsigned step = 0; step < 8u; step++) {
            unsigned part = v > step * 16u ? v - step * 16u : 0u;
            if (part > 16u) part = 16u;
            unsigned expected = (part * 11u + 15u) / 16u;
            unsigned fill = lsdj_nat_amount_fill(v, step);
            assert(fill == expected);
            if (v) assert(fill >= lsdj_nat_amount_fill(v - 1u, step));
            if (v == step * 16u) assert(fill == 0);
            if (v >= (step + 1u) * 16u || v == 127u) assert(fill == 11);
            unsigned top = 16u + (7u - step) * 12u, counted = 0;
            for (unsigned y = 0; y < 12u; y++) {
                uint16_t pixel = px[(top + y) * 160u + 24u];
                assert(pixel == (y >= 12u - expected ? 0xFD20 : shades[0]));
                counted += pixel == 0xFD20;
            }
            assert(counted == expected);
        }
    }
    assert(lsdj_nat_amount_fill(255, 7) == 11);
    /* Every preset's accent remains distinct from every background shade.
       Channel selection must not tint any pixels of the native panel. */
    unsigned min_distance = 9999u;
    static uint16_t no_tint[160 * 144];
    for (unsigned t = 0; t < LSDJ_THEME_PRESETS; t++) for (unsigned s = 0; s < 4u; s++)
        for (int target = -1; target < 4; target++) {
            const lsdj_theme_t *theme = &lsdj_themes[t];
            lsdj_nat_t themed = n; themed.shade = theme->gb; themed.bgp = (uint8_t)s;
            lsdj_ov_bars_t b = {0}; b.amount_scale = 1; b.hot = -1; b.chan = (int8_t)target;
            strcpy(b.label[0], "CT"); b.level[0] = 64;
            lsdj_nat_bars(&themed, &b, theme->accent);
            uint16_t fill = px[110u * 160u + 24u], gap = px[100u * 160u + 24u];
            assert(fill == theme->accent && gap == theme->gb[s]);
            unsigned distance = lsdj_theme_dist(fill, gap);
            assert(distance >= 150u);
            if (distance < min_distance) min_distance = distance;
            if (target < 0) memcpy(no_tint, px, sizeof no_tint);
            else assert(!memcmp(no_tint, px, sizeof no_tint));
        }
    printf("PASS: accent fill across %u theme entries/all shades: RGB distance min %u; no channel tint\n",
           LSDJ_THEME_PRESETS, min_distance);
    /* Text on the bars' colour (the selected choice, the knobs' names) reads on every theme: at least 3:1 on the
       accent and on the names' half accent (WCAG's ratio, gamma 2). */
    for (unsigned i = 0; i < LSDJ_THEME_PRESETS; i++) {
        if (i == LSDJ_THEME_CUSTOM) continue;
        const lsdj_theme_t *t = &lsdj_themes[i];
        uint16_t box[2] = {t->accent, lsdj_nat_mix(t->accent, t->gb[0])};
        for (unsigned j = 0; j < 2u; j++) {
            uint16_t q[2] = {t->gb[0], t->gb[3]};
            lsdj_nat_t m = n; m.px = q; m.shade = t->gb; m.bgp = 0xE4;
            lsdj_nat_box(&m, 0, 0, 2, 1, box[j]);
            uint64_t e = 829069u, a = lsdj_nat_luma(box[j]), k = lsdj_nat_luma(q[1]);
            uint64_t hi = (a > k ? a : k) + e, lo = (a > k ? k : a) + e;
            assert(q[0] == box[j] && hi >= 3u * lo);
        }
    }
    /* Each mode is drawn once, its names plain; only the selected one on the bars' colour (its band of the column). */
    for (unsigned count = 2; count <= LSDJ_OV_CHOICES; count++) for (unsigned pick = 0; pick < count; pick++) {
        static uint16_t expected[160 * 144];
        lsdj_ov_bars_t b = {0}; b.amount_scale = 1; b.hot = -1; b.chan = -1;
        strcpy(b.label[0], "TY"); b.nchoice[0] = (uint8_t)count; b.pick[0] = (uint8_t)pick;
        for (unsigned i = 0; i < count; i++) { b.choice[0][i][0] = 'A' + (char)i; b.choice[0][i][1] = '0' + (char)i; }
        lsdj_nat_bars(&n, &b, 0xFD20);
        lsdj_nat_t ref = n; ref.px = expected;
        unsigned rows = count <= 3u ? 4u : count <= 6u ? 2u : 1u;
        for (unsigned i = 0; i < count; i++) {
            unsigned row = 14u - (i + 1u) * rows + (rows - 1u) / 2u;
            unsigned top = 14u - (i + 1u) * rows;
            lsdj_nat_clear(&ref, 3, top, 2, rows);
            lsdj_nat_text(&ref, 3, row, b.choice[0][i], 2, 0);
            if (i == pick) lsdj_nat_box(&ref, 24u, top * 8u + (rows > 1u), 16u, rows * 8u - 2u * (rows > 1u), 0xFD20);
            for (unsigned y = top * 8u; y < (top + rows) * 8u; y++)
                assert(!memcmp(&px[y * 160u + 24u], &expected[y * 160u + 24u], 16u * sizeof(uint16_t)));
            unsigned acc = 0;
            for (unsigned y = top * 8u; y < (top + rows) * 8u; y++) for (unsigned x = 24u; x < 40u; x++) acc += px[y * 160u + x] == 0xFD20;
            assert(i == pick ? acc > (rows == 1u ? 32u : 16u * 8u) : acc == 0);   /* (a one-row box: 16 x 8, most of it the name) */
        }
    }
    /* BATTERY (FM-1_981): every level is text, each different, none the blank value field (which looks like
       LSDj's panel background: a full battery drew nothing visible); unknown draws nothing. */
    {   static uint16_t cell[6][3 * 8 * 8], blank[3 * 8 * 8];
        const unsigned lv[6] = {0, 1, 2, 3, 0x83, 0xFF};
        lsdj_nat_t m = n;
        for (unsigned i = 0; i < 7; i++) {
            for (unsigned p = 0; p < 160u * 144u; p++) px[p] = 0x7777;
            if (i < 6) lsdj_nat_battery(&m, 17, 15, lv[i]); else lsdj_nat_text(&m, 17, 15, "   ", 3, 1);   /* the old filled cells */
            uint16_t *o = i < 6 ? cell[i] : blank;
            for (unsigned y = 0; y < 8; y++) memcpy(&o[y * 24], &px[(15 * 8 + y) * 160 + 17 * 8], 24 * sizeof(uint16_t));
        }
        for (unsigned i = 0; i < 5; i++) {
            assert(memcmp(cell[i], blank, sizeof blank));
            for (unsigned j = i + 1; j < 5; j++) assert(memcmp(cell[i], cell[j], sizeof blank));
        }
        for (unsigned k = 0; k < 3 * 64; k++) assert(cell[5][k] == 0x7777);
    }
    /* The FM-1's number (IDENTIFY, 0.9.98-dev.19): over the whole picture, inside it; one digit at 12x, two at 9x,
       centred; "FM-1" on row 1; LSDj's digit tiles scaled (each tile pixel a block of one shade). 0 / 100: nothing. */
    {
        static uint16_t one[160 * 144];
        for (unsigned no = 1; no <= 99; no++) {
            for (unsigned i = 0; i < 1024; i++) buf[i] = buf[1024 + 160 * 144 + i] = CANARY;
            for (unsigned i = 0; i < 160 * 144; i++) px[i] = 0x7777;
            lsdj_nat_big(&n, no);
            for (unsigned i = 0; i < 1024; i++) assert(buf[i] == CANARY && buf[1024 + 160 * 144 + i] == CANARY);
            for (unsigned i = 0; i < 160 * 144; i++) assert(px[i] != 0x7777);   /* the whole picture covered */
            unsigned s = no < 10 ? 12u : 9u, k = no < 10 ? 1u : 2u, x0 = (160u - k * 8u * s) / 2u, y0 = 28u + (116u - 8u * s) / 2u;
            assert(y0 >= 22u && y0 + 8u * s <= 144u && x0 + k * 8u * s <= 160u);   /* below "FM-1" (rows 6..21), inside */
            /* one ink, black or white, whichever stands out more from the background */
            uint16_t ink = lsdj_nat_big_ink(&n);
            assert(ink == (lsdj_nat_luma(lsdj_nat_col(&n, 0)) > 4000000u ? 0x0000u : 0xFFFFu));
            /* each digit, and "FM-1" at 2x: block (bx, by) the background where the tile is, else the ink */
            const char *cap = "FM-1";
            for (unsigned d = 0; d < k + 4u; d++) {
                int cp = d >= k;   /* (the caption's letters after the digits) */
                int t = lsdj_nat_tile(cp ? cap[d - k] : (char)('0' + (k == 2u && d == 0 ? no / 10u : no % 10u)));
                unsigned ss = cp ? 2u : s, xx = cp ? 48u + (d - k) * 16u : x0 + d * 8u * s, yy = cp ? 6u : y0;
                for (unsigned by = 0; by < 8; by++) for (unsigned bx = 0; bx < 8; bx++) {
                    uint8_t lo = vram[0x1000 + t * 16 + by * 2], hi = vram[0x1000 + t * 16 + by * 2 + 1];
                    unsigned i = ((lo >> (7 - bx)) & 1u) | (((hi >> (7 - bx)) & 1u) << 1);
                    uint16_t want = i ? ink : lsdj_nat_col(&n, 0);
                    for (unsigned dy = 0; dy < ss; dy++) for (unsigned dx = 0; dx < ss; dx++)
                        assert(px[(yy + by * ss + dy) * 160 + xx + bx * ss + dx] == want);
                }
            }
            if (no == 1) memcpy(one, px, sizeof one);
            if (no == 7) assert(memcmp(one, px, sizeof one));
        }
        for (unsigned i = 0; i < 160 * 144; i++) px[i] = 0x7777;
        lsdj_nat_big(&n, 0); lsdj_nat_big(&n, 100);
        for (unsigned i = 0; i < 160 * 144; i++) assert(px[i] == 0x7777);
    }
    puts("PASS: LSDj-style drawing: bounds, right panel, font, theme-accent segments at all 128 values, 2-6 choice selections on the bars' colour, names on it, battery, the FM-1's number big");
    return 0;
}
