/* SPDX-License-Identifier: GPL-3.0-only */
/* firmware/usb_rejoin.h: the update loader rejoins USB until the host configures it, never after. */
#include <stdio.h>
#include <string.h>
#include "usb_rejoin.h"

static int bad;
#define CHECK(c) do { if (!(c)) { printf("FAIL %s:%d %s\n", __FILE__, __LINE__, #c); bad++; } } while (0)

/* rejoin times (ms) over [0, end) with the bus up and never configured, polled every 1 ms */
static int times(usb_rejoin_t *r, uint32_t start, uint32_t end, uint32_t *out, int max)
{
    int n = 0;
    for (uint32_t t = start; t < end; t++)
        if (usb_rejoin_due(r, t, 1, 0, 0) && n < max)
            out[n++] = t;
    return n;
}

int main(void)
{
    {   /* never set up: 6, +12, +24, then every 30 s */
        usb_rejoin_t r; memset(&r, 0, sizeof r);
        uint32_t at[8];
        int n = times(&r, 100, 100 + 6000 + 12000 + 24000 + 30000 + 30000 + 1, at, 8);
        CHECK(n == 5);
        CHECK(at[0] == 6100 && at[1] == 18100 && at[2] == 42100 && at[3] == 72100 && at[4] == 102100);
        CHECK(r.rejoins == 5);
    }
    {   /* configured in time: never */
        usb_rejoin_t r; memset(&r, 0, sizeof r);
        int due = 0;
        for (uint32_t t = 0; t < 200000; t++)
            due |= usb_rejoin_due(&r, t, 1, t >= 800, 0);
        CHECK(!due && r.done);
    }
    {   /* configured after one rejoin, then unconfigured (a bus reset mid-write): still never again */
        usb_rejoin_t r; memset(&r, 0, sizeof r);
        int n = 0;
        for (uint32_t t = 0; t < 300000; t++)
            n += usb_rejoin_due(&r, t, 1, t >= 7000 && t < 9000, 0);
        CHECK(n == 1);
    }
    {   /* no SIE (usb.up 0): nothing; once up, 6 s from then */
        usb_rejoin_t r; memset(&r, 0, sizeof r);
        int due = 0;
        for (uint32_t t = 0; t < 20000; t++)
            due |= usb_rejoin_due(&r, t, 0, 0, 0);
        CHECK(!due);
        uint32_t at[2];
        CHECK(times(&r, 20000, 26001, at, 2) == 1 && at[0] == 26000);
    }
    {   /* detached on purpose (UBOOT, the end of an install): nothing */
        usb_rejoin_t r; memset(&r, 0, sizeof r);
        int due = 0;
        for (uint32_t t = 0; t < 100000; t++)
            due |= usb_rejoin_due(&r, t, 1, 0, 1);
        CHECK(!due);
    }
    {   /* ldr_ms wraps (after ~49 days, never in practice): still 6 s */
        usb_rejoin_t r; memset(&r, 0, sizeof r);
        uint32_t t0 = 0xFFFFF000u, at[1];
        int n = 0;
        for (uint32_t i = 0; i <= 6000; i++)
            if (usb_rejoin_due(&r, t0 + i, 1, 0, 0) && n < 1) at[n++] = t0 + i;
        CHECK(n == 1 && at[0] == t0 + 6000u);
    }
    printf("%s usb_rejoin\n", bad ? "FAIL" : "PASS");
    return bad != 0;
}
