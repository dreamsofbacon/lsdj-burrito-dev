/* SPDX-License-Identifier: GPL-3.0-only */
/* Host test for firmware/lsdj_cue.h. */
#include <assert.h>
#include <stdio.h>
#include <string.h>
#include "lsdj_cue.h"
#include "lsdj_overlay.h"

static void fits(const char *t, unsigned max) { assert(strlen(t) <= max); for (const char *c = t; *c; c++) assert(strchr(lsdj_ov_chars, *c)); }

int main(void) {
    lsdj_cue_t q; memset(&q, 0, sizeof q);
    uint8_t all[4] = {1, 1, 1, 1}, none[4] = {0, 0, 0, 0}, rows[4] = {3, 3, 3, 3};
    uint16_t a[8]; uint8_t v[8];
    /* Opens on the next row; a press alone cues nothing. */
    lsdj_cue_open(&q, all, rows); assert(q.held && q.row == 4 && lsdj_cue_lit(&q));
    assert(!lsdj_cue_release(&q) && !q.pending && !lsdj_cue_lit(&q));
    assert(lsdj_cue_frame(&q, all, rows, 0xC200, 0xC17C, a, v) == 0);
    /* Stopped: opens on row 00. */
    lsdj_cue_open(&q, none, rows); assert(q.row == 0); lsdj_cue_release(&q);
    /* K1 +5, K2 -1 (16 back, wraps): row 4 + 5 - 16 = F9; let go cues. */
    lsdj_cue_open(&q, all, rows);
    lsdj_cue_turn(&q, 5, 0); lsdj_cue_turn(&q, 0, -1); assert(q.row == 0xF9 && q.turned);
    assert(lsdj_cue_release(&q) && q.pending && lsdj_cue_lit(&q));
    /* Playing: one batch, each channel row-1 and chain place 15. */
    unsigned n = lsdj_cue_frame(&q, all, rows, 0xC200, 0xC17C, a, v);
    assert(n == 8 && !q.pending && q.waiting);
    for (unsigned c = 0; c < 4; c++) {
        assert(a[2 * c] == 0xC200 + c && v[2 * c] == 0xF8);
        assert(a[2 * c + 1] == 0xC17C + c && v[2 * c + 1] == 15);
    }
    /* Lit until a channel is on the row. */
    assert(lsdj_cue_frame(&q, all, rows, 0xC200, 0xC17C, a, v) == 0 && q.waiting);
    rows[0] = 0xF9; lsdj_cue_frame(&q, all, rows, 0xC200, 0xC17C, a, v); assert(!q.waiting && !lsdj_cue_lit(&q));
    /* Row 00: written as FF (LSDj wraps to 00). Live mode: only playing channels. */
    uint8_t wav[4] = {0, 0, 1, 0};
    lsdj_cue_open(&q, wav, rows); q.row = 0xFF; lsdj_cue_turn(&q, 1, 0); assert(q.row == 0); lsdj_cue_release(&q);
    n = lsdj_cue_frame(&q, wav, rows, 0xC200, 0xC17C, a, v);
    assert(n == 2 && a[0] == 0xC202 && v[0] == 0xFF && a[1] == 0xC17E && v[1] == 15);
    /* Pending while stopped: written when playing starts. */
    lsdj_cue_open(&q, none, rows); lsdj_cue_turn(&q, 2, 0); lsdj_cue_release(&q);
    assert(lsdj_cue_frame(&q, none, rows, 0xC200, 0xC17C, a, v) == 0 && q.pending);
    assert(lsdj_cue_frame(&q, all, rows, 0xC200, 0xC17C, a, v) == 8 && v[0] == 1);
    /* Gives up waiting after ~4 s. */
    for (int i = 0; i < 300; i++) lsdj_cue_frame(&q, all, rows, 0xC200, 0xC17C, a, v);
    assert(!q.waiting);
    /* The pop-up: chains on the row, "--" for none. */
    {
        static uint8_t song[1024]; memset(song, 0xFF, sizeof song);
        song[8 * 4 + 0] = 0x42; song[8 * 4 + 2] = 0x19;
        char title[20], big[20], label[4][7], value[4][6], caption[4][4]; uint8_t level[4];
        lsdj_cue_open(&q, all, rows); q.row = 8;
        lsdj_cue_bars(&q, song, title, big, label, value, caption, level);
        assert(!strcmp(title, "CUE ROW 08") && !strcmp(value[0], "42") && !strcmp(value[1], "--") && !strcmp(value[2], "19"));
        assert(level[0] == 127 && level[1] == 0 && !strcmp(label[3], "NS"));
        fits(title, 17); fits(big, 19); for (int c = 0; c < 4; c++) { fits(label[c], 5); fits(value[c], 5); }
        lsdj_cue_turn(&q, 1, 0); lsdj_cue_bars(&q, song, title, big, label, value, caption, level); fits(big, 19);
    }
    /* 0.9.98-dev.16: a cue while stopped is the start row. */
    {
        lsdj_cue_t s; memset(&s, 0, sizeof s); uint8_t put = 0xEE;
        uint8_t r0[4] = {0, 0, 0, 0}, r7[4] = {7, 7, 7, 7};
        /* MIDI cue 07 while stopped: the start row (ARP lit), nothing written. */
        assert(lsdj_cue_pc(&s, 7, 1, 2, &put) == 0 && s.pending);
        assert(lsdj_cue_play(&s, none, 2, &put) == 0 && s.start_set && s.start == 7 && !s.pending && lsdj_cue_lit(&s));
        assert(lsdj_cue_frame(&s, none, r0, 0xC200, 0xC17C, a, v) == 0);
        /* START: the cursor (on 02) to 07 first; START waits until it reads 07, then goes. */
        assert(lsdj_cue_gate(&s, 2, &put) == 2 && put == 7 && s.moved && s.cursor_was == 2);
        assert(lsdj_cue_gate(&s, 2, &put) == 2 && put == 7);   /* not landed yet: again */
        assert(lsdj_cue_gate(&s, 7, &put) == 1);
        /* LSDj plays from 07: the cursor back to 02, done; no jump at the next bar. */
        put = 0xEE; assert(lsdj_cue_play(&s, all, 7, &put) == 1 && put == 2 && !s.start_set && !s.moved);
        assert(lsdj_cue_frame(&s, all, r7, 0xC200, 0xC17C, a, v) == 0 && !s.pending && !lsdj_cue_lit(&s));
        /* the cursor already on the row: nothing written, nothing put back */
        lsdj_cue_stop(&s, 0, &put); lsdj_cue_play(&s, none, 0, &put);
        lsdj_cue_pc(&s, 5, 1, 5, &put); lsdj_cue_play(&s, none, 5, &put);
        assert(lsdj_cue_gate(&s, 5, &put) == 1 && lsdj_cue_play(&s, all, 5, &put) == 0);
        /* Gives up waiting for the cursor after 8 frames (START goes anyway). */
        lsdj_cue_play(&s, none, 0, &put);   /* (stops: cleared) */
        assert(!s.start_set);
        lsdj_cue_pc(&s, 9, 1, 0, &put); lsdj_cue_play(&s, none, 0, &put);
        int g = 0, k; for (k = 0; k < 20 && !(g & 1); k++) g = lsdj_cue_gate(&s, 0, &put);
        assert((g & 1) && k == 10);   /* the write, 8 frames waiting, then START */
        /* Started without the cursor moved (e.g. no cursor address): the old cue, the row at the next bar. */
        lsdj_cue_stop(&s, 0, &put); lsdj_cue_play(&s, none, 0, &put);
        lsdj_cue_pc(&s, 0x10, 1, 0, &put); lsdj_cue_play(&s, none, 0, &put);
        assert(lsdj_cue_play(&s, all, 0, &put) == 0 && s.pending && s.row == 0x10 && !s.start_set);
        assert(lsdj_cue_frame(&s, all, r0, 0xC200, 0xC17C, a, v) == 8 && v[0] == 0x0F);
        /* LSDj stopping clears every cue (the jump still waiting too). */
        assert(s.waiting); lsdj_cue_play(&s, none, 0, &put); assert(!s.waiting && !s.pending && !lsdj_cue_lit(&s));
        lsdj_cue_play(&s, all, 0, &put); lsdj_cue_pc(&s, 3, 0, 0, &put); assert(s.pending);   /* playing: cued ... */
        lsdj_cue_play(&s, none, 0, &put); assert(!s.pending && !s.start_set);                /* ... stopped first: gone */
        /* Stopped: the same row again cancels; another row replaces it. */
        lsdj_cue_pc(&s, 4, 1, 0, &put); lsdj_cue_play(&s, none, 0, &put); assert(s.start == 4);
        lsdj_cue_pc(&s, 6, 1, 0, &put); lsdj_cue_play(&s, none, 0, &put); assert(s.start_set && s.start == 6);
        assert(lsdj_cue_pc(&s, 6, 1, 0, &put) == 1 && !s.start_set && !s.pending && !lsdj_cue_lit(&s));
        /* Stop (MIDI Stop, the DJ Stop key): clears it; said only when there was one. */
        lsdj_cue_pc(&s, 6, 1, 0, &put); lsdj_cue_play(&s, none, 0, &put);
        assert(lsdj_cue_stop(&s, 0, &put) == 1 && !lsdj_cue_lit(&s) && lsdj_cue_stop(&s, 0, &put) == 0);
        /* Stopped between the cursor write and LSDj starting: the cursor goes back. */
        lsdj_cue_pc(&s, 6, 1, 1, &put); lsdj_cue_play(&s, none, 1, &put); lsdj_cue_gate(&s, 1, &put);
        put = 0xEE; assert(lsdj_cue_stop(&s, 6, &put) == 3 && put == 1);
        /* ARP while stopped: opens on the start row; turned and let go, the new start row. */
        lsdj_cue_pc(&s, 0x20, 1, 0, &put); lsdj_cue_play(&s, none, 0, &put);
        lsdj_cue_open(&s, none, r0); assert(s.row == 0x20);
        lsdj_cue_turn(&s, 1, 0); assert(lsdj_cue_release(&s)); lsdj_cue_play(&s, none, 0, &put);
        assert(s.start_set && s.start == 0x21);
    }
    puts("PASS: song row cue: choose (K1, K2 by 16), let go to cue, one batch per playing channel, waits for play; "
         "stopped, the start row (cursor for START, back after), Stop or the same row again cancels");
    return 0;
}
