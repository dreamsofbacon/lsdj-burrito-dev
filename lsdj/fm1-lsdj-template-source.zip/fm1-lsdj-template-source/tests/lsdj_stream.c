/* SPDX-License-Identifier: GPL-3.0-only */
/* firmware/lsdj_stream.h: the read stream's frames decode to the bytes asked for, whole, in order; USB-MIDI packets
   end a frame with CIN 5/6/7 and continue with 4; a frame once begun goes out whole (yield only between frames);
   a stop lets the frame going out finish; nothing when not started. */
#include <assert.h>
#include <stdio.h>
#include <string.h>
#include "../firmware/lsdj_stream.h"

static uint8_t src[131072 + 999], got[131072 + 999], seen[131072 + 999];
static uint8_t msg[512]; static unsigned mn;

/* one STREAM_DATA message: its bytes into got (checked) */
static void decode(void) {
    assert(mn >= 16 && msg[0] == 0xf0 && msg[1] == 0x7d && msg[2] == 'G' && msg[3] == 'S' && msg[4] == LSDJ_STREAM_OP && msg[5] == 0);
    assert(msg[mn - 1] == 0xf7);
    for (unsigned i = 1; i + 1 < mn; i++) assert(msg[i] < 128);
    uint32_t off = 0;
    for (unsigned b = 0; b < 4; b++) off |= (uint32_t)(msg[7 + 2 * b] | msg[8 + 2 * b] << 7) << (8 * b);
    unsigned k = 15, at = off;
    while (k < mn - 1) {
        uint8_t h = msg[k++];
        for (unsigned i = 0; i < 7 && k < mn - 1; i++) { got[at] = (uint8_t)(msg[k++] | ((h >> i) & 1) << 7); assert(!seen[at]); seen[at++] = 1; }
    }
}
/* the packets into messages, as a host's USB-MIDI does */
static unsigned run(lsdj_stream_t *s, int yield_every, unsigned *frames) {
    uint32_t pkt; unsigned pkts = 0; *frames = 0; mn = 0;
    for (;;) {
        int y = yield_every && !lsdj_stream_mid(s) && (pkts % 3u == 1u);   /* a note waiting now and then */
        if (!lsdj_stream_next(s, &pkt, y)) { if (y) { pkts++; continue; } break; }
        unsigned cin = pkt & 15u, k = cin == 4u || cin == 7u ? 3u : cin - 4u;
        assert(cin >= 4u && cin <= 7u);
        for (unsigned i = 0; i < k; i++) msg[mn++] = (uint8_t)(pkt >> (8 + 8 * i));
        if (cin != 4u) { decode(); mn = 0; ++*frames; }
        else assert(lsdj_stream_mid(s) || !lsdj_stream_busy(s) || 1);
        pkts++;
        assert(pkts < 1000000u);
    }
    assert(mn == 0);   /* no frame left part way */
    return pkts;
}

int main(void) {
    for (unsigned i = 0; i < sizeof src; i++) src[i] = (uint8_t)(i * 37u + (i >> 8) * 11u);
    lsdj_stream_t s; memset(&s, 0, sizeof s);
    uint32_t pkt; unsigned frames;
    assert(!lsdj_stream_next(&s, &pkt, 0) && !lsdj_stream_busy(&s));   /* not started: nothing */

    /* the whole songs: 131072 bytes, every one once, as they are */
    lsdj_stream_start(&s, src, 0, 0, 131072u);
    unsigned pkts = run(&s, 0, &frames);
    assert(frames == (131072u + LSDJ_STREAM_BYTES - 1u) / LSDJ_STREAM_BYTES);
    for (unsigned i = 0; i < 131072u; i++) assert(seen[i] && got[i] == src[i]);
    assert(!lsdj_stream_busy(&s));
    printf("songs: %u frames, %u packets (%.2f bytes a data byte; 2.00 by READ)\n", frames, pkts, pkts * 4.0 / 131072 * 3 / 4);

    /* a part of it, odd lengths (the last frame shorter, its last group too), with notes waiting between frames */
    for (uint32_t len = 1; len < 300; len += 13) {
        memset(seen, 0, sizeof seen);
        lsdj_stream_start(&s, src, 1, 1000, 1000 + len);
        run(&s, 1, &frames);
        for (unsigned i = 0; i < sizeof seen; i++) assert(seen[i] == (i >= 1000 && i < 1000 + len));
        for (unsigned i = 1000; i < 1000 + len; i++) assert(got[i] == src[i]);
    }

    /* a stop part way: the frame going out finishes, then nothing */
    memset(seen, 0, sizeof seen);
    lsdj_stream_start(&s, src, 0, 0, 10000);
    for (unsigned i = 0; i < 5; i++) assert(lsdj_stream_next(&s, &pkt, 0));
    assert(lsdj_stream_mid(&s));
    lsdj_stream_start(&s, src, 0, 0, 0);   /* stop */
    mn = 0; { uint32_t p; unsigned n = 0; while (lsdj_stream_next(&s, &p, 0)) n++; assert(n > 0 && !lsdj_stream_busy(&s)); }
    assert(!lsdj_stream_next(&s, &pkt, 0));

    /* yield at a frame's end only: never inside one */
    lsdj_stream_start(&s, src, 0, 0, 500);
    assert(lsdj_stream_next(&s, &pkt, 0) && lsdj_stream_mid(&s));
    while (lsdj_stream_mid(&s)) assert(lsdj_stream_next(&s, &pkt, 1));   /* mid frame: yield ignored */
    assert(!lsdj_stream_next(&s, &pkt, 1) && lsdj_stream_busy(&s));       /* between frames: yields */
    printf("lsdj_stream: PASS (whole songs, odd lengths, notes between frames, stop, yield only between frames)\n");
    return 0;
}
