/* SPDX-License-Identifier: GPL-3.0-only */
/* Host test: the Game Boy sound core (build/minigb_apu.c, tools/prepare_apu.py) plays notes in tune.
   Each pulse / wave note is played for 100 s and its cycles counted on the channel's own output (the split):
   the frequency must be the DMG's, 131072 / (2048 - x) (pulse) or 65536 / (2048 - x) (wave), within 0.5 cent.
   Before 0.9.98 MiniGB rounded each frequency down to a whole Hz first: up to ~3.4 cents flat.
   Build: gcc -std=c99 -O2 tests/apu_pitch.c build/minigb_apu.c -Ivendor/peanut-gb -Isrc \
          -DMINIGB_APU_AUDIO_FORMAT_S16SYS -DAUDIO_SAMPLE_RATE=44100 -lm */
#include <assert.h>
#include <math.h>
#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#include <stdbool.h>
#include "minigb_apu.h"

void minigb_apu_split(int16_t *out);
void minigb_apu_render(struct minigb_apu_ctx *ctx, audio_sample_t *stream, unsigned frames);

#define RATE 44100.0
#define BLOCK 1024u
static struct minigb_apu_ctx A;

/* cents between what one channel played (rising crossings over `secs`) and `want` Hz */
static double play(int ch, unsigned x, double want, double secs) {
    static int16_t split[BLOCK * 5u]; static audio_sample_t mix[BLOCK * 2u];
    minigb_apu_audio_init(&A);
    minigb_apu_split(split);
    minigb_apu_audio_write(&A, 0xFF26, 0x80); minigb_apu_audio_write(&A, 0xFF24, 0x77); minigb_apu_audio_write(&A, 0xFF25, 0xFF);
    if (ch == 0) {
        minigb_apu_audio_write(&A, 0xFF10, 0x00); minigb_apu_audio_write(&A, 0xFF11, 0x80);   /* no sweep, 50 % duty */
        minigb_apu_audio_write(&A, 0xFF12, 0xF0); minigb_apu_audio_write(&A, 0xFF13, (uint8_t)(x & 0xFF));
        minigb_apu_audio_write(&A, 0xFF14, (uint8_t)(0x80 | (x >> 8)));
    } else {                                   /* wave: one cycle a square (16 high, 16 low) */
        minigb_apu_audio_write(&A, 0xFF1A, 0x00);
        for (unsigned i = 0; i < 16; i++) minigb_apu_audio_write(&A, (uint16_t)(0xFF30 + i), i < 8 ? 0xFF : 0x00);
        minigb_apu_audio_write(&A, 0xFF1A, 0x80); minigb_apu_audio_write(&A, 0xFF1C, 0x20);
        minigb_apu_audio_write(&A, 0xFF1D, (uint8_t)(x & 0xFF)); minigb_apu_audio_write(&A, 0xFF1E, (uint8_t)(0x80 | (x >> 8)));
    }
    long n = (long)(secs * RATE), first = -1, last = -1, cycles = 0; int prev = 0;
    for (long done = 0; done < n; done += BLOCK) {
        minigb_apu_render(&A, mix, BLOCK);
        for (unsigned i = 0; i < BLOCK; i++) {
            int v = split[i * 5u + (ch ? 2u : 0u)], up = v > 0;
            if (up && !prev) { if (first < 0) first = done + i; else cycles++; last = done + i; }
            prev = up;
        }
    }
    double got = cycles * RATE / (double)(last - first);
    return 1200.0 * log2(got / want);
}

int main(void) {
    double worst = 0;
    static const unsigned xs[] = {44, 300, 1046, 1546, 1797, 1923, 1985};   /* ~C2 .. C7 for the pulse */
    for (unsigned k = 0; k < sizeof xs / sizeof xs[0]; k++) {
        double sq = play(0, xs[k], 131072.0 / (2048 - xs[k]), 100), wv = play(1, xs[k], 65536.0 / (2048 - xs[k]), 100);
        printf("x %4u: pulse %8.2f Hz %+6.2f cents, wave %8.2f Hz %+6.2f cents\n", xs[k], 131072.0 / (2048 - xs[k]), sq,
               65536.0 / (2048 - xs[k]), wv);
        if (fabs(sq) > worst) worst = fabs(sq);
        if (fabs(wv) > worst) worst = fabs(wv);
    }
    printf("worst %.3f cents\n", worst);
    assert(worst < 0.5);
    puts("PASS apu pitch: pulse and wave notes at the DMG's frequencies within 0.5 cent (100 s each)");
    return 0;
}
