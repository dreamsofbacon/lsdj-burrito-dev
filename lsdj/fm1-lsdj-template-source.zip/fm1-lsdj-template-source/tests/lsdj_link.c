/* SPDX-License-Identifier: GPL-3.0-only */
/* Host test for firmware/lsdj_link.h, with fake hardware: info, song export,
   import (good, bad crc, flash failure, out of order, timeout), settings,
   effects, custom theme, store, live data; every reply is valid 7-bit SysEx. */
#include <assert.h>
#include <stdint.h>
#include <stdio.h>
#include <string.h>
#include "lsdj_link.h"

#define SIZE 131072u
static uint8_t ram[SIZE], flash[SIZE];
static int paused, resets, fail_store, stores, config_stores;
static uint32_t settings = 0x5A000000u, fxw[LSDJ_LINK_FX_WORDS];
static uint16_t theme[8];
static uint8_t *io_save(void) { return ram; }
static uint32_t io_size(void) { return SIZE; }
static void io_pause(int on) { paused = on; }
static int io_store(void) { if (fail_store) return -1; memcpy(flash, ram, SIZE); stores++; return 0; }
static int io_load(void) { memcpy(ram, flash, SIZE); return 0; }
static void io_reset(void) { resets++; }
static const char *io_fw(void) { return "FM-1_955"; }
static const char *io_title(void) { return "LSDj-v9.3.9"; }
static int io_known(void) { return 1; }
static uint32_t io_sget(void) { return settings; }
static int io_sset(uint32_t v) { if (v >> 24 != 0x5A) return 0; settings = v; return 1; }
static void io_fget(uint32_t w[LSDJ_LINK_FX_WORDS]) { memcpy(w, fxw, sizeof fxw); }
static int io_fset(const uint32_t *w, unsigned n) {
    if ((n != LSDJ_LINK_FX_WORDS && n != LSDJ_LINK_FX_WORDS_OLD) || ((w[10] >> 16) & 0xFF) != 0xF2) return 0;
    memcpy(fxw, w, 4 * n); return 1;   /* 11 words replace the first 11, the rest stay (as board.c does) */
}
static void io_tget(uint16_t c[8]) { memcpy(c, theme, sizeof theme); }
static void io_tset(const uint16_t c[8]) { memcpy(theme, c, sizeof theme); }
static int io_cstore(void) { config_stores++; return 0; }
static void io_live97(lsdj_link_live_t *l) { l->page = 2; l->cursor_ch = 3; l->bpm = 170; l->mute = 5; l->freeze = 1; l->playing = 0xF; l->battery = 0x82; }
static void io_live(lsdj_link_live_t *l) { io_live97(l); for (int c = 0; c < 4; c++) { l->rows[c] = (uint8_t)(4 * c + 3); l->songrows[c] = (uint8_t)(0x10 + c); } l->sync = 3; l->seq = 1; l->level = 100;
    for (int c = 0; c < 4; c++) { l->chainpos[c] = (uint8_t)c; l->chainlen[c] = (uint8_t)(4 + c); } }
static int level = 127, seq_live = 0, seq_known = 1; static uint8_t songtab[256 * 4];
static int io_vol(uint8_t v) { level = v; return 1; }
static int io_seq(uint8_t v) { if (!seq_known) return 0; seq_live = v; return 1; }
static int sync_now = 0, sync_playing = 0;   /* 0.9.98-dev.2: SYNC_SET */
static int io_sync(uint8_t v) { if (v != 5 && v != 3) return 0; if (sync_playing) return -1; sync_now = v; return 1; }
static int io_song(uint8_t row, uint8_t out[4 * LSDJ_LINK_SONG_WINDOW]) { for (unsigned i = 0; i < 4 * LSDJ_LINK_SONG_WINDOW; i++) out[i] = row * 4u + i < sizeof songtab ? songtab[row * 4u + i] : 0xFF; return 1; }
static uint32_t midi_word = 0x4D000009u;
static uint32_t io_mget(void) { return midi_word; }
static int io_mset(uint32_t v) { if (v >> 24 != 0x4D) return 0; midi_word = v; return 1; }
static uint8_t cartridge[256 + 2 * 16384];
static int cart_available = 1;
static const volatile uint8_t *io_cart(uint32_t *len) { *len = sizeof cartridge; return cart_available ? cartridge : 0; }
static uint8_t mute_now, freeze_now;
static int io_mute(uint8_t m, uint8_t f) { if (m > 15 || f > 1) return 0; mute_now = m; freeze_now = f; return 1; }
static uint32_t feat_word = 0x460001C6u;
static uint32_t io_eget(void) { return feat_word; }
static int io_eset(uint32_t v) { if (v >> 24 != 0x46) return 0; feat_word = v; return 1; }
static uint16_t pic[LSDJ_LINK_SCREEN_W * LSDJ_LINK_SCREEN_H];
/* FM-1_987: the link reads the LCD image; this scales pic as src/video_job.h gb_video_scale does. */
static uint16_t lcd_img[240u * 216u];
static const uint16_t *scaled(void) {
    for (unsigned y = 0; y < 216u; y++) for (unsigned x = 0; x < 240u; x++) {
        uint16_t c = pic[(y * 2u / 3u) * LSDJ_LINK_SCREEN_W + (x / 3u) * 2u + (x % 3u == 2u)];
        lcd_img[y * 240u + x] = (uint16_t)(c >> 8 | c << 8);
    }
    return lcd_img;
}
static const volatile uint16_t *io_screen(uint32_t *shown) { *shown = 4242; return scaled(); }
static uint32_t stream_bands = 0xDEAD; static int stream_ok = 1;   /* 0: a link that cannot stream */
static uint8_t stream_round;
static int io_stream(uint32_t bands, uint8_t round) { if (!stream_ok) return 0; stream_bands = bands; stream_round = round; return 1; }
static uint32_t rv_word = 0x00404000u;   /* 0.9.97: mix 0, size 64, tone 64, input ALL */
static uint32_t io_rget(void) { return rv_word; }
static int io_rset(uint32_t v) { if ((v & 255u) > 127u || ((v >> 8) & 255u) > 127u || ((v >> 16) & 255u) > 127u || (v >> 24) > 1u) return 0; rv_word = v; return 1; }
static uint32_t rvs_word;   /* 0.9.97-dev.7: the reverb sends */
static uint32_t io_vsget(void) { return rvs_word; }
static int io_vsset(uint32_t v) { for (int c = 0; c < 4; c++) if (((v >> (8 * c)) & 255u) > 127u) return 0; rvs_word = v; return 1; }
static int dj_now = -1;   /* 0.9.98-dev.4: DJ_DECK */
static int io_dj(uint8_t v) { if (v > 3) return 0; dj_now = v; return 1; }
static uint8_t ident_no, ident_s;   /* 0.9.98-dev.19: IDENTIFY */
static int io_ident(uint8_t no, uint8_t s) { ident_no = no; ident_s = s; return 1; }
static uint8_t io_restart(uint32_t v[LSDJ_LINK_RESTART_WORDS]) { for (uint32_t i = 0; i < LSDJ_LINK_RESTART_WORDS; i++) v[i] = 0x02000000u + i * 0x01010101u; return 1; }
static int kept_has;   /* 0.9.98-dev.22: LAST_RESTART */
static int io_last(uint32_t v[LSDJ_LINK_LAST_WORDS]) { for (unsigned i = 0; i < LSDJ_LINK_LAST_WORDS; i++) v[i] = 0x52030101u + i; return kept_has; }
static int hangs, tested[3];   /* 0.9.98-dev.20: TEST */
static void io_test(uint8_t what) { tested[what]++; hangs = tested[0]; }
/* 0.9.98-dev.6: the presets page (lsdj_presets.h) */
static uint8_t ppage[LSDJ_PRESETS_PAGE];
static int loaded_slot = -1, saved_slot = -1; static char saved_name[16];
static const uint8_t *io_presets(void) { return ppage; }
static int io_pput(uint8_t i, const uint8_t b[LSDJ_LINK_PRESET]) { if (!lsdj_preset_raw_ok(b)) return 0; lsdj_preset_put_raw(ppage, i, b); return 1; }
static int io_pload(uint8_t i) { if (!lsdj_preset_used(ppage, i)) return -1; loaded_slot = i; return 1; }
static int io_psave(uint8_t i, const char *name) {
    lsdj_preset_t p; memset(&p, 0, sizeof p); p.fx[0] = 0xABCDu;
    if (name) memcpy(p.name, name, LSDJ_PRESET_NAME); else lsdj_preset_default_name(i, p.name);
    lsdj_preset_put(ppage, i, &p); saved_slot = i; strcpy(saved_name, name ? name : "");
    return 1;
}
static int pad_now = -1;   /* 0.9.97: the web page's controller */
static void io_pset(uint8_t b) { pad_now = b; }
static const lsdj_link_io_t io = {io_save, io_size, io_pause, io_store, io_load, io_reset, io_fw, io_title, io_known,
                                  io_sget, io_sset, io_fget, io_fset, io_tget, io_tset, io_cstore, io_live, io_mget, io_mset, io_cart, io_mute,
                                  io_eget, io_eset, io_screen, io_stream, io_rget, io_rset, io_pset, io_vsget, io_vsset, io_vol, io_seq, io_song, io_sync, io_dj,
                                  io_presets, io_pput, io_pload, io_psave};
/* A SCREEN_PIXELS message -> row (or -1), px; checks the framing. Status in *status. */
static int unpixels(const uint8_t *m, uint32_t n, uint16_t px[LSDJ_LINK_SCREEN_W], unsigned *status) {
    assert(n >= 10 && m[0] == 0xf0 && m[1] == 0x7d && m[2] == 'G' && m[3] == 'S' && m[4] == LSDJ_LINK_SCREEN_PIXELS && m[n - 1] == 0xf7);
    for (uint32_t i = 1; i < n - 1; i++) assert(m[i] < 128);
    *status = m[5];
    assert(m[6] == 99);   /* the round */
    uint32_t acc = 0, i = 7; unsigned bits = 0;
#define TAKE(w, out) do { while (bits < (w)) { assert(i < n - 1); acc |= (uint32_t)m[i++] << bits; bits += 7; } (out) = acc & ((1u << (w)) - 1u); acc >>= (w); bits -= (w); } while (0)
    unsigned row, np1, pal[16]; TAKE(8, row);
    if (*status) { assert(i == n - 1); return (int)row; }
    TAKE(4, np1); unsigned np = np1 + 1, w = np > 8 ? 4 : np > 4 ? 3 : np > 2 ? 2 : np > 1 ? 1 : 0;
    for (unsigned k = 0; k < np; k++) TAKE(16, pal[k]);
    for (unsigned x = 0; x < LSDJ_LINK_SCREEN_W; x++) { unsigned k = 0; if (w) TAKE(w, k); assert(k < np); px[x] = (uint16_t)pal[k]; }
    assert(i == n - 1 && bits < 7);   /* nothing left over */
#undef TAKE
    return (int)row;
}
/* 0.9.98-dev.6, the fast LSDj swap: what io->slot was given; it answers 3 bytes */
static unsigned slot_op = 99, slot_dn, slot_status, swap_running;
static uint8_t slot_d[140];
static int io_slot(unsigned op, const uint8_t *d, uint32_t dn, uint32_t now, uint8_t *out, uint32_t *on) {
    (void)now; slot_op = op; slot_dn = dn; memcpy(slot_d, d, dn);
    out[0] = 0xAB; out[1] = (uint8_t)op; out[2] = 0x80; *on = 3;
    return (int)slot_status;
}
static int io_busy(void) { return (int)swap_running; }
/* firmware before FM-1_979: no feature switches */
static const lsdj_link_io_t io_old = {io_save, io_size, io_pause, io_store, io_load, io_reset, io_fw, io_title, io_known,
                                      io_sget, io_sset, io_fget, io_fset, io_tget, io_tset, io_cstore, io_live97, io_mget, io_mset, io_cart, io_mute};
static lsdj_link_t st;
/* READ_STREAM (0.9.98-dev.14): an io with a stream; what the page asked */
static uint8_t st_what = 9; static uint32_t st_off, st_len;
static int io_rstream(uint8_t what, uint32_t off, uint32_t len, uint32_t *total) {
    *total = what ? 4096u : SIZE; if (off > *total) return 0;
    st_what = what; st_off = off; st_len = len; return 1;
}
static lsdj_link_io_t io_s;
static uint8_t reply[LSDJ_LINK_REPLY_MAX];
static uint32_t rn;

static int req(uint8_t op, const uint8_t *data, uint32_t n, uint32_t now) {
    uint8_t q[4 + 2 * 140] = {0x7d, 'G', 'S', op};
    for (uint32_t i = 0; i < n; i++) { q[4 + 2 * i] = data[i] & 127; q[5 + 2 * i] = data[i] >> 7; }
    assert(lsdj_link_match(q, 4 + 2 * n));
    rn = lsdj_link_handle(&st, &io, q, 4 + 2 * n, now, reply);
    assert(reply[0] == 0xf0 && reply[4] == op && reply[rn - 1] == 0xf7 && rn <= LSDJ_LINK_REPLY_MAX);
    for (uint32_t i = 1; i < rn - 1; i++) assert(reply[i] < 128);
    return reply[5];
}
static uint32_t rd(uint32_t i) { return reply[6 + 2 * i] | (uint32_t)reply[7 + 2 * i] << 7; }
static uint32_t rd16(uint32_t i) { return rd(i) | rd(i + 1) << 8; }
static uint32_t rd32(uint32_t i) { return rd(i) | rd(i + 1) << 8 | rd(i + 2) << 16 | rd(i + 3) << 24; }
static void le32(uint8_t *p, uint32_t v) { for (int i = 0; i < 4; i++) p[i] = (uint8_t)(v >> (8 * i)); }
static int begin(uint32_t len, uint32_t crc, uint32_t now) { uint8_t b[8]; le32(b, len); le32(b + 4, crc); return req(LSDJ_LINK_BEGIN, b, 8, now); }
static int chunk(const uint8_t *src, uint32_t off, uint32_t now) {
    uint8_t b[4 + LSDJ_LINK_CHUNK]; le32(b, off); memcpy(b + 4, src + off, LSDJ_LINK_CHUNK);
    return req(LSDJ_LINK_CHUNK_OP, b, sizeof b, now);
}

int main(void) {
    static uint8_t song[SIZE], other[SIZE], got[SIZE];
    for (uint32_t i = 0; i < SIZE; i++) { song[i] = (uint8_t)(i * 31 + 7); other[i] = (uint8_t)(i ^ 0xa5); }
    memcpy(ram, song, SIZE); memcpy(flash, song, SIZE);
    for (unsigned i = 0; i < sizeof cartridge; i++) cartridge[i] = (uint8_t)(i * 19u);
    assert(req(LSDJ_LINK_CART_INFO, 0, 0, 0) == LSDJ_LINK_OK);
    assert(rd32(0) == sizeof cartridge && rd32(4) == lsdj_link_le32(cartridge + 252) && rd32(8) == lsdj_link_le32(cartridge + 16));
    for (uint32_t off = 0; off < sizeof cartridge; off += LSDJ_LINK_CART_CHUNK) {
        uint8_t b[4]; le32(b, off);
        for (unsigned retry = 0; retry < 2; retry++) {
            assert(req(LSDJ_LINK_CART_READ, b, 4, 0) == LSDJ_LINK_OK && rd32(0) == off);
            unsigned count = sizeof cartridge - off;
            if (count > LSDJ_LINK_CART_CHUNK) count = LSDJ_LINK_CART_CHUNK;
            assert(rn == 7 + 2 * (count + 4));
            for (unsigned i = 0; i < count; i++) assert(rd(4 + i) == cartridge[off + i]);
        }
    }
    { uint8_t b[4];
      const uint32_t bad[] = {1, sizeof cartridge, 0xffffffb0u, 0xffffffffu};
      for (unsigned i = 0; i < sizeof bad / sizeof bad[0]; i++) {
          le32(b, bad[i]); assert(req(LSDJ_LINK_CART_READ, b, 4, 0) == LSDJ_LINK_BAD);
      }
      assert(req(LSDJ_LINK_CART_READ, b, 3, 0) == LSDJ_LINK_BAD);
      assert(req(LSDJ_LINK_CART_INFO, b, 1, 0) == LSDJ_LINK_BAD);
      cart_available = 0;
      assert(req(LSDJ_LINK_CART_INFO, 0, 0, 0) == LSDJ_LINK_BAD);
      assert(req(LSDJ_LINK_CART_READ, b, 4, 0) == LSDJ_LINK_BAD);
      cart_available = 1;
    }
    assert(!paused && !resets && !stores && !config_stores);
    assert(!memcmp(ram, song, SIZE) && !memcmp(flash, song, SIZE));

    /* INFO */
    assert(req(LSDJ_LINK_INFO, 0, 0, 0) == LSDJ_LINK_OK);
    assert(rd(0) == LSDJ_LINK_PROTOCOL);
    { char fw[9] = {0}, ti[17] = {0}; for (int i = 0; i < 8; i++) fw[i] = (char)rd(1 + i); for (int i = 0; i < 16; i++) ti[i] = (char)rd(9 + i);
      assert(!strcmp(fw, "FM-1_955") && !strcmp(ti, "LSDj-v9.3.9")); }
    assert(rd32(25) == SIZE && rd32(29) == lsdj_link_crc32(song, SIZE) && rd(33) == 0 && rd(34) == (1 | LSDJ_LINK_FLAG_TAGS | LSDJ_LINK_FLAG_PRESETS | LSDJ_LINK_FLAG_FX98));
    assert(rd32(35) == LSDJ_BUILD_ID);   /* the build ID (0.9.98-dev.9; 0 here: not named) */

    /* Export */
    for (uint32_t off = 0; off < SIZE; off += LSDJ_LINK_CHUNK) {
        uint8_t b[4]; le32(b, off); assert(req(LSDJ_LINK_READ, b, 4, 0) == LSDJ_LINK_OK);
        for (uint32_t i = 0; i < LSDJ_LINK_CHUNK; i++) got[off + i] = (uint8_t)rd(i);
    }
    assert(!memcmp(got, song, SIZE));
    { uint8_t b[4]; le32(b, 100); assert(req(LSDJ_LINK_READ, b, 4, 0) == LSDJ_LINK_BAD); }

    /* Import: stored first, chunks in order, commit restarts LSDj */
    assert(begin(SIZE, lsdj_link_crc32(other, SIZE), 0) == LSDJ_LINK_OK && paused && stores == 1);
    assert(req(LSDJ_LINK_READ, (const uint8_t[4]){0}, 4, 0) == LSDJ_LINK_STATE);
    assert(req(LSDJ_LINK_CART_INFO, 0, 0, 0) == LSDJ_LINK_STATE);
    assert(req(LSDJ_LINK_CART_READ, (const uint8_t[4]){0}, 4, 0) == LSDJ_LINK_STATE);
    assert(chunk(other, 256, 1) == LSDJ_LINK_BAD);                       /* out of order */
    for (uint32_t off = 0; off < SIZE; off += LSDJ_LINK_CHUNK) assert(chunk(other, off, 2) == LSDJ_LINK_OK);
    assert(chunk(other, SIZE - LSDJ_LINK_CHUNK, 3) == LSDJ_LINK_OK);      /* the last one again */
    assert(req(LSDJ_LINK_COMMIT, 0, 0, 4) == LSDJ_LINK_OK && !paused && resets == 1 && !memcmp(flash, other, SIZE));
    /* Bad crc: the stored songs come back */
    memcpy(ram, other, SIZE);
    assert(begin(SIZE, 12345, 10) == LSDJ_LINK_OK);
    for (uint32_t off = 0; off < SIZE; off += LSDJ_LINK_CHUNK) chunk(song, off, 11);
    assert(req(LSDJ_LINK_COMMIT, 0, 0, 12) == LSDJ_LINK_CRC && !memcmp(ram, other, SIZE) && !paused);
    /* Flash failing at BEGIN: nothing starts */
    fail_store = 1; assert(begin(SIZE, 1, 20) == LSDJ_LINK_FLASH && !paused && !st.importing); fail_store = 0;
    /* A page that goes away: aborted after the timeout */
    assert(begin(SIZE, 1, 100) == LSDJ_LINK_OK); chunk(song, 0, 101); assert(ram[0] == song[0]);
    lsdj_link_poll(&st, &io, 101 + LSDJ_LINK_TIMEOUT_MS / 2); assert(st.importing);
    lsdj_link_poll(&st, &io, 102 + LSDJ_LINK_TIMEOUT_MS); assert(!st.importing && !paused && !memcmp(ram, other, SIZE));

    /* Settings */
    assert(req(LSDJ_LINK_SETTINGS_GET, 0, 0, 0) == LSDJ_LINK_OK && rd32(0) == 0x5A000000u);
    { uint8_t b[4]; le32(b, 0x5A000041u); assert(req(LSDJ_LINK_SETTINGS_SET, b, 4, 0) == LSDJ_LINK_OK && settings == 0x5A000041u);
      le32(b, 0x12345678u); assert(req(LSDJ_LINK_SETTINGS_SET, b, 4, 0) == LSDJ_LINK_BAD && settings == 0x5A000041u); }
    /* Effects */
    { uint8_t b[68]; for (int i = 0; i < 68; i++) b[i] = (uint8_t)i; b[42] = 0xF2;
      assert(req(LSDJ_LINK_FX_SET, b, 68, 0) == LSDJ_LINK_OK);
      assert(req(LSDJ_LINK_FX_GET, 0, 0, 0) == LSDJ_LINK_OK);
      for (int i = 0; i < 68; i++) assert(rd(i) == b[i]);
      b[42] = 0; assert(req(LSDJ_LINK_FX_SET, b, 68, 0) == LSDJ_LINK_BAD);
      /* 11 words (a page from before alpha 66): the first 11 replaced, words 11..16 kept */
      uint8_t o[44]; for (int i = 0; i < 44; i++) o[i] = (uint8_t)(0x80 + i); o[42] = 0xF2;
      assert(req(LSDJ_LINK_FX_SET, o, 44, 0) == LSDJ_LINK_OK);
      assert(req(LSDJ_LINK_FX_GET, 0, 0, 0) == LSDJ_LINK_OK);
      for (int i = 0; i < 44; i++) assert(rd(i) == o[i]);
      for (int i = 44; i < 68; i++) assert(rd(i) == b[i]);
      assert(req(LSDJ_LINK_FX_SET, b, 60, 0) == LSDJ_LINK_BAD);   /* neither 11 nor 17 words */
      b[42] = 0xF2; assert(req(LSDJ_LINK_FX_SET, b, 68, 0) == LSDJ_LINK_OK); }
    /* Custom theme */
    { uint8_t b[16]; for (int i = 0; i < 16; i++) b[i] = (uint8_t)(0xF0 + i);
      assert(req(LSDJ_LINK_THEME_SET, b, 16, 0) == LSDJ_LINK_OK && theme[3] == (uint16_t)(0xF6 | 0xF7 << 8));
      assert(req(LSDJ_LINK_THEME_GET, 0, 0, 0) == LSDJ_LINK_OK && rd16(14) == (0xFE | 0xFF << 8)); }
    /* Store, live */
    assert(req(LSDJ_LINK_STORE, 0, 0, 0) == LSDJ_LINK_OK && config_stores == 1);
    assert(req(LSDJ_LINK_LIVE, 0, 0, 0) == LSDJ_LINK_OK);
    assert(rd(0) == 2 && rd(1) == 3 && rd16(2) == 170 && rd(4) == 5 && rd(5) == 1 && rd(6) == 0xF && rd(7) == 0 && rd(7 + 42) == 0xF2);
    assert(rd(7 + 4 * LSDJ_LINK_FX_WORDS) == 0x82 && rn == 6u + 2u * (8u + 4u * LSDJ_LINK_FX_WORDS + 19u) + 1u);   /* battery: 2 bars, USB */
    /* 0.9.98: phrase rows, song rows, SYNC, SEQ, page volume after the battery */
    { const unsigned o = 8 + 4 * LSDJ_LINK_FX_WORDS;
      assert(rd(o) == 3 && rd(o + 3) == 15 && rd(o + 4) == 0x10 && rd(o + 7) == 0x13 && rd(o + 8) == 3 && rd(o + 9) == 1 && rd(o + 10) == 100);
      assert(rd(o + 11) == 0 && rd(o + 14) == 3 && rd(o + 15) == 4 && rd(o + 18) == 7);   /* dev.12: places in the chains, their phrases */
      /* a board that leaves them: 0xFF (unknown), same length */
      uint8_t q[4] = {0x7d, 'G', 'S', LSDJ_LINK_LIVE};
      rn = lsdj_link_handle(&st, &io_old, q, 4, 0, reply);
      assert(reply[5] == LSDJ_LINK_OK && rn == 6u + 2u * (o + 19u) + 1u);
      for (unsigned i = 0; i < 19; i++) assert(rd(o + i) == 0xFF); }
    assert(req(LSDJ_LINK_OP_21, 0, 0, 0) == LSDJ_LINK_BAD);   /* Bluetooth status until FM-1_993: gone */
    { uint8_t b[4] = {0x01, 0x80, 0x02, 0x4D};
      assert(req(LSDJ_LINK_MIDI_SET, b, 4, 0) == LSDJ_LINK_OK && midi_word == 0x4D028001u);
      assert(req(LSDJ_LINK_MIDI_GET, 0, 0, 0) == LSDJ_LINK_OK && rd(0) == 0x01 && rd(3) == 0x4D);
      uint8_t bad[4] = {0, 0, 0, 0x5A}; assert(req(LSDJ_LINK_MIDI_SET, bad, 4, 0) == LSDJ_LINK_BAD); }
    /* PAD_SET (0.9.97): one byte, the buttons held; older firmware answers status 1 */
    { uint8_t b[1] = {1 | 8 | 64};
      assert(req(LSDJ_LINK_PAD_SET, b, 1, 0) == LSDJ_LINK_OK && pad_now == 73);
      b[0] = 0; assert(req(LSDJ_LINK_PAD_SET, b, 1, 0) == LSDJ_LINK_OK && pad_now == 0);
      b[0] = 0xFF; assert(req(LSDJ_LINK_PAD_SET, b, 1, 0) == LSDJ_LINK_OK && pad_now == 255);
      assert(req(LSDJ_LINK_PAD_SET, 0, 0, 0) == LSDJ_LINK_BAD && pad_now == 255);   /* no byte */
      uint8_t q[6] = {0x7d, 'G', 'S', LSDJ_LINK_PAD_SET, 1, 0};
      rn = lsdj_link_handle(&st, &io_old, q, 6, 0, reply); assert(reply[5] == LSDJ_LINK_BAD); }
    /* REVERB_GET / REVERB_SET (0.9.97); older firmware answers status 1 */
    { uint8_t b[4] = {100, 90, 30, 1};
      assert(req(LSDJ_LINK_REVERB_GET, 0, 0, 0) == LSDJ_LINK_OK && rd32(0) == 0x00404000u);
      assert(req(LSDJ_LINK_REVERB_SET, b, 4, 0) == LSDJ_LINK_OK && rv_word == 0x011E5A64u);
      assert(req(LSDJ_LINK_REVERB_GET, 0, 0, 0) == LSDJ_LINK_OK && rd32(0) == 0x011E5A64u);
      uint8_t bad[4] = {100, 90, 30, 2}; assert(req(LSDJ_LINK_REVERB_SET, bad, 4, 0) == LSDJ_LINK_BAD && rv_word == 0x011E5A64u);
      assert(req(LSDJ_LINK_REVERB_SET, b, 3, 0) == LSDJ_LINK_BAD && req(LSDJ_LINK_REVERB_GET, b, 1, 0) == LSDJ_LINK_BAD);
      uint8_t q[4] = {0x7d, 'G', 'S', LSDJ_LINK_REVERB_GET};
      rn = lsdj_link_handle(&st, &io_old, q, 4, 0, reply); assert(reply[5] == LSDJ_LINK_BAD); }
    /* REVERB_SENDS_GET / _SET (0.9.97-dev.7): a byte per channel, each 0..127; older firmware answers status 1 */
    { uint8_t b[4] = {5, 127, 0, 64};
      assert(req(LSDJ_LINK_REVERB_SENDS_GET, 0, 0, 0) == LSDJ_LINK_OK && rd32(0) == 0);
      assert(req(LSDJ_LINK_REVERB_SENDS_SET, b, 4, 0) == LSDJ_LINK_OK && rvs_word == 0x40007F05u);
      assert(req(LSDJ_LINK_REVERB_SENDS_GET, 0, 0, 0) == LSDJ_LINK_OK && rd32(0) == 0x40007F05u);
      uint8_t bad[4] = {5, 128, 0, 0}; assert(req(LSDJ_LINK_REVERB_SENDS_SET, bad, 4, 0) == LSDJ_LINK_BAD && rvs_word == 0x40007F05u);
      uint8_t q[4] = {0x7d, 'G', 'S', LSDJ_LINK_REVERB_SENDS_GET};
      rn = lsdj_link_handle(&st, &io_old, q, 4, 0, reply); assert(reply[5] == LSDJ_LINK_BAD); }
    /* VOLUME_SET, SEQ_SET, SONG_ROWS (0.9.98, the DJ layout); older firmware answers status 1 */
    { uint8_t b[1] = {64};
      assert(req(LSDJ_LINK_VOLUME_SET, b, 1, 0) == LSDJ_LINK_OK && level == 64);
      b[0] = 0; assert(req(LSDJ_LINK_VOLUME_SET, b, 1, 0) == LSDJ_LINK_OK && level == 0);
      b[0] = 128; assert(req(LSDJ_LINK_VOLUME_SET, b, 1, 0) == LSDJ_LINK_BAD && level == 0);
      assert(req(LSDJ_LINK_VOLUME_SET, 0, 0, 0) == LSDJ_LINK_BAD);
      b[0] = 1; assert(req(LSDJ_LINK_SEQ_SET, b, 1, 0) == LSDJ_LINK_OK && seq_live == 1);
      b[0] = 0; assert(req(LSDJ_LINK_SEQ_SET, b, 1, 0) == LSDJ_LINK_OK && seq_live == 0);
      b[0] = 2; assert(req(LSDJ_LINK_SEQ_SET, b, 1, 0) == LSDJ_LINK_BAD && seq_live == 0);
      seq_known = 0; b[0] = 1; assert(req(LSDJ_LINK_SEQ_SET, b, 1, 0) == LSDJ_LINK_BAD && seq_live == 0); seq_known = 1;
      /* SYNC_SET (0.9.98-dev.2): KEYBD or MIDI; status 2 while LSDj plays; status 1 for another value, none, or old firmware */
      b[0] = 5; assert(req(LSDJ_LINK_SYNC_SET, b, 1, 0) == LSDJ_LINK_OK && sync_now == 5);
      b[0] = 3; assert(req(LSDJ_LINK_SYNC_SET, b, 1, 0) == LSDJ_LINK_OK && sync_now == 3);
      b[0] = 1; assert(req(LSDJ_LINK_SYNC_SET, b, 1, 0) == LSDJ_LINK_BAD && sync_now == 3);
      assert(req(LSDJ_LINK_SYNC_SET, 0, 0, 0) == LSDJ_LINK_BAD);
      sync_playing = 1; b[0] = 5; assert(req(LSDJ_LINK_SYNC_SET, b, 1, 0) == LSDJ_LINK_STATE && sync_now == 3); sync_playing = 0;
      { uint8_t q[5] = {0x7d, 'G', 'S', LSDJ_LINK_SYNC_SET, 5};
        rn = lsdj_link_handle(&st, &io_old, q, 5, 0, reply); assert(reply[5] == LSDJ_LINK_BAD); }
      /* DJ_DECK (0.9.98-dev.4): 0..3; status 1 for another value, none, or old firmware */
      for (uint8_t v = 0; v <= 3; v++) { b[0] = v; assert(req(LSDJ_LINK_DJ_DECK, b, 1, 0) == LSDJ_LINK_OK && dj_now == v && rn == 7); }
      b[0] = 4; assert(req(LSDJ_LINK_DJ_DECK, b, 1, 0) == LSDJ_LINK_BAD && dj_now == 3);
      assert(req(LSDJ_LINK_DJ_DECK, 0, 0, 0) == LSDJ_LINK_BAD);
      { uint8_t q[6] = {0x7d, 'G', 'S', LSDJ_LINK_DJ_DECK, 1, 0};
        rn = lsdj_link_handle(&st, &io_old, q, 6, 0, reply); assert(reply[5] == LSDJ_LINK_BAD); }
      /* DJ_KEY, sent never asked: F0 7D 'G' 'S' 34 00 key-pair F7 */
      { uint8_t m[9]; assert(LSDJ_LINK_DJ_DECK == 0x33 && LSDJ_LINK_DJ_KEY == 0x34);
        for (uint8_t k = 0; k < 2; k++) {
          assert(lsdj_link_dj_key(k, m) == 9);
          assert(m[0] == 0xf0 && m[1] == 0x7d && m[2] == 'G' && m[3] == 'S' && m[4] == 0x34 && m[5] == 0 && m[6] == k && m[7] == 0 && m[8] == 0xf7);
        } }
      for (unsigned i = 0; i < sizeof songtab; i++) songtab[i] = (uint8_t)(i * 7);
      b[0] = 0x20; assert(req(LSDJ_LINK_SONG_ROWS, b, 1, 0) == LSDJ_LINK_OK && rn == 6u + 2u * (1u + 4u * LSDJ_LINK_SONG_WINDOW) + 1u);
      assert(rd(0) == 0x20 && rd(1) == (uint8_t)(0x80 * 7) && rd(1 + 63) == (uint8_t)((0x80 + 63) * 7));
      b[0] = 0xF8; assert(req(LSDJ_LINK_SONG_ROWS, b, 1, 0) == LSDJ_LINK_OK);   /* rows past 0xFF: empty */
      assert(rd(1 + 31) == (uint8_t)((0xF8 * 4 + 31) * 7) && rd(1 + 32) == 0xFF && rd(64) == 0xFF);
      for (unsigned op = LSDJ_LINK_VOLUME_SET; op <= LSDJ_LINK_SONG_ROWS; op++) {
        uint8_t q[6] = {0x7d, 'G', 'S', (uint8_t)op, 1, 0};
        rn = lsdj_link_handle(&st, &io_old, q, 6, 0, reply); assert(reply[5] == LSDJ_LINK_BAD); } }
    /* FEAT_GET / FEAT_SET: the feature switches (FM-1_979); older firmware answers status 1 */
    { uint8_t b[4] = {0x03, 0x02, 0x00, 0x46};
      assert(req(LSDJ_LINK_FEAT_GET, 0, 0, 0) == LSDJ_LINK_OK && rd32(0) == 0x460001C6u);
      assert(req(LSDJ_LINK_FEAT_SET, b, 4, 0) == LSDJ_LINK_OK && feat_word == 0x46000203u);
      assert(req(LSDJ_LINK_FEAT_GET, 0, 0, 0) == LSDJ_LINK_OK && rd32(0) == 0x46000203u);
      uint8_t bad[4] = {0, 0, 0, 0x4D}; assert(req(LSDJ_LINK_FEAT_SET, bad, 4, 0) == LSDJ_LINK_BAD && feat_word == 0x46000203u);
      assert(req(LSDJ_LINK_FEAT_SET, b, 3, 0) == LSDJ_LINK_BAD && req(LSDJ_LINK_FEAT_GET, b, 1, 0) == LSDJ_LINK_BAD);
      uint8_t q[4 + 8] = {0x7d, 'G', 'S', LSDJ_LINK_FEAT_GET};
      rn = lsdj_link_handle(&st, &io_old, q, 4, 0, reply); assert(reply[5] == LSDJ_LINK_BAD);
      q[3] = LSDJ_LINK_FEAT_SET; for (int i = 0; i < 4; i++) { q[4 + 2 * i] = b[i] & 127; q[5 + 2 * i] = b[i] >> 7; }
      rn = lsdj_link_handle(&st, &io_old, q, 12, 0, reply); assert(reply[5] == LSDJ_LINK_BAD); }
    /* MUTE_SET: the web page's channel buttons and freeze */
    { uint8_t m[2] = {5, 1}; assert(req(LSDJ_LINK_MUTE_SET, m, 2, 0) == LSDJ_LINK_OK && mute_now == 5 && freeze_now == 1);
      uint8_t bad[2] = {16, 0}; assert(req(LSDJ_LINK_MUTE_SET, bad, 2, 0) == LSDJ_LINK_BAD && mute_now == 5);
      assert(req(LSDJ_LINK_MUTE_SET, m, 1, 0) == LSDJ_LINK_BAD); }
    /* SCREEN_INFO / SCREEN_ROW: the picture, band hashes, rows as colours + 4-bit indices */
    { for (unsigned i = 0; i < LSDJ_LINK_SCREEN_W * LSDJ_LINK_SCREEN_H; i++) pic[i] = (uint16_t)(0x1000u * ((i / 7u) % 4u) + 0x0FFFu);
      assert(req(LSDJ_LINK_SCREEN_INFO, 0, 0, 0) == LSDJ_LINK_OK && rn == 6u + 2u * (4u + 2u * LSDJ_LINK_SCREEN_BANDS) + 1u && rd32(0) == 4242);
      uint16_t h[LSDJ_LINK_SCREEN_BANDS]; for (unsigned b = 0; b < LSDJ_LINK_SCREEN_BANDS; b++) h[b] = (uint16_t)rd16(4 + 2 * b);
      pic[5 * 8 * LSDJ_LINK_SCREEN_W + 3 * LSDJ_LINK_SCREEN_W + 77] ^= 0x0101u;   /* one pixel in band 5 */
      assert(req(LSDJ_LINK_SCREEN_INFO, 0, 0, 0) == LSDJ_LINK_OK);
      for (unsigned b = 0; b < LSDJ_LINK_SCREEN_BANDS; b++) assert((rd16(4 + 2 * b) == h[b]) == (b != 5));
      for (unsigned y = 0; y < LSDJ_LINK_SCREEN_H; y++) {
          uint8_t a = (uint8_t)y; assert(req(LSDJ_LINK_SCREEN_ROW, &a, 1, 0) == LSDJ_LINK_OK && rd(0) == y);
          unsigned np = rd(1); assert(np >= 1 && np <= 16 && rn == 6u + 2u * (2u + 2u * np + 80u) + 1u);
          for (unsigned x = 0; x < LSDJ_LINK_SCREEN_W; x++) {
              unsigned k = (rd(2 + 2 * np + x / 2) >> (4 * (x & 1))) & 15u;
              assert(k < np && rd16(2 + 2 * k) == pic[y * LSDJ_LINK_SCREEN_W + x]);
          }
      }
      for (unsigned x = 0; x < LSDJ_LINK_SCREEN_W; x++) pic[x] = (uint16_t)((x % 16u) * 0x111u);   /* 16 colours: still fine */
      { uint8_t a = 0; assert(req(LSDJ_LINK_SCREEN_ROW, &a, 1, 0) == LSDJ_LINK_OK && rd(1) == 16); }
      pic[16] = 0xBEEF; pic[17] = 0xBEEF;   /* 17: status 2, the page skips the row */
      { uint8_t a = 0; assert(req(LSDJ_LINK_SCREEN_ROW, &a, 1, 0) == LSDJ_LINK_STATE); }
      { uint8_t a = 144; assert(req(LSDJ_LINK_SCREEN_ROW, &a, 1, 0) == LSDJ_LINK_BAD); }
      assert(req(LSDJ_LINK_SCREEN_ROW, 0, 0, 0) == LSDJ_LINK_BAD && req(LSDJ_LINK_SCREEN_INFO, (const uint8_t[1]){0}, 1, 0) == LSDJ_LINK_BAD);
      uint8_t q[6] = {0x7d, 'G', 'S', LSDJ_LINK_SCREEN_INFO};   /* firmware before FM-1_983 */
      rn = lsdj_link_handle(&st, &io_old, q, 4, 0, reply); assert(reply[5] == LSDJ_LINK_BAD);
      q[3] = LSDJ_LINK_SCREEN_ROW; rn = lsdj_link_handle(&st, &io_old, q, 6, 0, reply); assert(reply[5] == LSDJ_LINK_BAD); }
    /* SCREEN_SYNC / SCREEN_PIXELS (FM-1_985): the bands that differ, then their rows packed */
    { for (unsigned i = 0; i < LSDJ_LINK_SCREEN_W * LSDJ_LINK_SCREEN_H; i++) pic[i] = (uint16_t)(0x0841u * ((i * 7u / 5u) % 4u));
      uint8_t q[5 + 2 * LSDJ_LINK_SCREEN_BANDS] = {0}; le32(q, 0x3FFFFu); q[sizeof q - 1] = 200;   /* all forced: the page's first look */
      assert(req(LSDJ_LINK_SCREEN_SYNC, q, sizeof q, 0) == LSDJ_LINK_OK && rn == 6u + 2u * (4u + 2u * LSDJ_LINK_SCREEN_BANDS + 4u) + 1u);
      assert(rd32(0) == 4242 && rd32(4 + 2 * LSDJ_LINK_SCREEN_BANDS) == 0x3FFFFu && stream_bands == 0x3FFFFu && stream_round == 200);
      le32(q, 0); for (unsigned b = 0; b < LSDJ_LINK_SCREEN_BANDS; b++) { q[4 + 2 * b] = (uint8_t)rd(4 + 2 * b); q[5 + 2 * b] = (uint8_t)rd(5 + 2 * b); }
      assert(req(LSDJ_LINK_SCREEN_SYNC, q, sizeof q, 0) == LSDJ_LINK_OK && rd32(4 + 2 * LSDJ_LINK_SCREEN_BANDS) == 0 && stream_bands == 0);   /* the same: nothing */
      pic[17 * 8 * LSDJ_LINK_SCREEN_W + 7 * LSDJ_LINK_SCREEN_W + 159] = 0xF800u;   /* the last pixel: band 17 only */
      le32(q, 1u << 2);   /* and band 2 forced */
      assert(req(LSDJ_LINK_SCREEN_SYNC, q, sizeof q, 0) == LSDJ_LINK_OK && stream_bands == (1u << 17 | 1u << 2));
      /* rows: 4 colours = 2 bits a pixel (57 bytes + 7), one colour = no indices, 16 colours */
      uint8_t m[LSDJ_LINK_REPLY_MAX]; uint16_t px[LSDJ_LINK_SCREEN_W]; unsigned status;
      uint32_t most = 0;
      for (unsigned y = 0; y < LSDJ_LINK_SCREEN_H; y++) {
          uint32_t n = lsdj_link_screen_pixels(scaled(), y, 99, m);
          assert(unpixels(m, n, px, &status) == (int)y && status == 0 && !memcmp(px, pic + y * LSDJ_LINK_SCREEN_W, sizeof px));
          if (n > most) most = n;
      }
      assert(most == 7u + (8u + 4u + 5u * 16u + 160u * 3u + 6u) / 7u + 1u);   /* row 143: 5 colours, 3 bits */
      assert(lsdj_link_screen_pixels(scaled(), 0, 99 | 128, m) == 7u + (8u + 4u + 4u * 16u + 320u + 6u) / 7u + 1u);
      for (unsigned x = 0; x < LSDJ_LINK_SCREEN_W; x++) pic[3 * LSDJ_LINK_SCREEN_W + x] = 0x1234u;
      { uint32_t n = lsdj_link_screen_pixels(scaled(), 3, 99 | 128, m); assert(n == 7u + 4u + 1u && unpixels(m, n, px, &status) == 3 && px[99] == 0x1234u); }
      for (unsigned x = 0; x < LSDJ_LINK_SCREEN_W; x++) pic[4 * LSDJ_LINK_SCREEN_W + x] = (uint16_t)((x * 3u % 16u) * 0x1111u);
      { uint32_t n = lsdj_link_screen_pixels(scaled(), 4, 99 | 128, m); assert(n == 7u + (8u + 4u + 256u + 640u + 6u) / 7u + 1u && n <= 138u);
        assert(unpixels(m, n, px, &status) == 4 && status == 0 && !memcmp(px, pic + 4 * LSDJ_LINK_SCREEN_W, sizeof px)); }
      pic[4 * LSDJ_LINK_SCREEN_W + 5] = 0xBEEF;   /* 17 colours: status 2, the row only */
      { uint32_t n = lsdj_link_screen_pixels(scaled(), 4, 99 | 128, m); assert(unpixels(m, n, px, &status) == 4 && status == 2 && n == 7u + 2u + 1u); }
      { uint32_t n = lsdj_link_screen_pixels(scaled(), 143, 99 | 128, m); assert(unpixels(m, n, px, &status) == 143); }   /* row > 127: 8 bits */
      /* refused: a link that cannot stream, wrong length, firmware before FM-1_985 */
      stream_ok = 0; stream_bands = 77; assert(req(LSDJ_LINK_SCREEN_SYNC, q, sizeof q, 0) == LSDJ_LINK_BAD && rn == 7 && stream_bands == 77); stream_ok = 1;
      assert(req(LSDJ_LINK_SCREEN_SYNC, q, sizeof q - 1, 0) == LSDJ_LINK_BAD && req(LSDJ_LINK_SCREEN_SYNC, 0, 0, 0) == LSDJ_LINK_BAD);
      lsdj_link_io_t io984 = io; io984.screen_stream = 0;
      uint8_t w[4 + 2 * sizeof q] = {0x7d, 'G', 'S', LSDJ_LINK_SCREEN_SYNC};
      for (unsigned i = 0; i < sizeof q; i++) { w[4 + 2 * i] = q[i] & 127; w[5 + 2 * i] = q[i] >> 7; }
      rn = lsdj_link_handle(&st, &io984, w, sizeof w, 0, reply); assert(reply[5] == LSDJ_LINK_BAD);
      rn = lsdj_link_handle(&st, &io_old, w, sizeof w, 0, reply); assert(reply[5] == LSDJ_LINK_BAD);
      w[3] = LSDJ_LINK_SCREEN_PIXELS; rn = lsdj_link_handle(&st, &io, w, 4, 0, reply); assert(reply[5] == LSDJ_LINK_BAD); }   /* never asked */
    /* FM-1_990 push: SCREEN_SYNC's force bit 31 reaches the stream; each new picture's SCREEN_FRAME */
    { uint8_t q[5 + 2 * LSDJ_LINK_SCREEN_BANDS] = {0}; le32(q, LSDJ_LINK_PUSH | 1u); q[sizeof q - 1] = 5;
      assert(req(LSDJ_LINK_SCREEN_SYNC, q, sizeof q, 0) == LSDJ_LINK_OK && (stream_bands & LSDJ_LINK_PUSH) && (stream_bands & 1u));
      assert(rd32(4 + 2 * LSDJ_LINK_SCREEN_BANDS) & 1u && !(rd32(4 + 2 * LSDJ_LINK_SCREEN_BANDS) & LSDJ_LINK_PUSH));   /* the reply: bands only */
      lsdj_link_push_t p = {0}; uint8_t m[LSDJ_LINK_REPLY_MAX]; uint32_t bands; uint16_t h[LSDJ_LINK_SCREEN_BANDS];
      assert(!lsdj_link_push_frame(&p, scaled(), 5, 0, m, &bands, h) && !bands);                 /* not pushing */
      lsdj_link_push_start(&p, scaled(), 5, 126, 1000);
      assert(p.on && p.round == 126 && !lsdj_link_push_frame(&p, scaled(), 5, 1100, m, &bands, h));   /* the same picture */
      assert(!lsdj_link_push_frame(&p, scaled(), 6, 1100, m, &bands, h) && p.shown == 6);       /* new, unchanged: nothing */
      pic[9 * 8 * LSDJ_LINK_SCREEN_W + 3 * LSDJ_LINK_SCREEN_W + 3] ^= 0xFFFFu;                   /* band 9 changes */
      uint32_t n = lsdj_link_push_frame(&p, scaled(), 70000, 1200, m, &bands, h);
      assert(bands == 1u << 9 && n == 7u + (32u + 18u + 16u * LSDJ_LINK_SCREEN_BANDS + 6u) / 7u + 1u && n <= 60u);
      assert(m[0] == 0xF0 && m[4] == LSDJ_LINK_SCREEN_FRAME && m[5] == 0 && m[6] == 127 && m[n - 1] == 0xF7);
      { uint32_t acc = 0, bits = 0, i = 7; uint32_t v[4 + LSDJ_LINK_SCREEN_BANDS]; const unsigned w[4] = {16, 16, 16, 2};
        for (unsigned f = 0; f < 4u + LSDJ_LINK_SCREEN_BANDS; f++) {
            unsigned wd = f < 4 ? w[f] : 16u;
            while (bits < wd) { assert(m[i] < 128); acc |= (uint32_t)m[i++] << bits; bits += 7; }
            v[f] = acc & ((1u << wd) - 1u); acc >>= wd; bits -= wd; }
        assert(i == n - 1u && (v[0] | v[1] << 16) == 70000u && (v[2] | v[3] << 16) == 1u << 9);
        for (unsigned b = 0; b < LSDJ_LINK_SCREEN_BANDS; b++) assert(v[4 + b] == lsdj_link_band_hash(scaled(), b)); }
      assert(lsdj_link_push_sent(&p, 70000, bands, h) == 127 && p.hash[9] == h[9] && p.shown == 70000);
      assert(!lsdj_link_push_frame(&p, scaled(), 70001, 1300, m, &bands, h));                   /* sent: the page has it */
      pic[0] ^= 0xFFFFu;
      assert(lsdj_link_push_frame(&p, scaled(), 70002, 1300, m, &bands, h) && bands == 1u && m[6] == 0);   /* round wraps */
      assert(lsdj_link_push_sent(&p, 70002, bands, h) == 0);
      pic[0] ^= 0xFFFFu;
      assert(!lsdj_link_push_frame(&p, scaled(), 70003, 1000 + LSDJ_LINK_PUSH_MS + 1, m, &bands, h) && !p.on); }   /* not renewed */
    /* Tagged requests (0.9.98-dev.3): the reply echoes the tag after the status, the data as untagged */
    { uint8_t q[4 + 1 + 8], untagged[LSDJ_LINK_REPLY_MAX]; uint32_t un;
      assert(req(LSDJ_LINK_READ, (const uint8_t[4]){0, 1, 0, 0}, 4, 0) == LSDJ_LINK_OK);   /* off 256 */
      memcpy(untagged, reply, rn); un = rn;
      q[0] = 0x7d; q[1] = 'G'; q[2] = 'S'; q[3] = LSDJ_LINK_READ | LSDJ_LINK_TAGGED; q[4] = 0x5A;
      const uint8_t off[4] = {0, 1, 0, 0};
      for (int i = 0; i < 4; i++) { q[5 + 2 * i] = off[i] & 127; q[6 + 2 * i] = off[i] >> 7; }
      rn = lsdj_link_handle(&st, &io, q, sizeof q, 0, reply);
      assert(rn == un + 1 && rn <= LSDJ_LINK_REPLY_MAX && reply[4] == (LSDJ_LINK_READ | LSDJ_LINK_TAGGED) && reply[5] == LSDJ_LINK_OK && reply[6] == 0x5A);
      assert(!memcmp(reply + 7, untagged + 6, un - 6));
      for (uint32_t i = 1; i < rn - 1; i++) assert(reply[i] < 128);
      /* a tagged request with bad data: still tagged, status 1 */
      q[3] = LSDJ_LINK_INFO | LSDJ_LINK_TAGGED; q[4] = 7;
      rn = lsdj_link_handle(&st, &io, q, 7, 0, reply);
      assert(reply[5] == LSDJ_LINK_BAD && reply[6] == 7 && reply[rn - 1] == 0xf7);
      /* no tag at all: status 1, nothing else */
      rn = lsdj_link_handle(&st, &io, q, 4, 0, reply);
      assert(rn == 7 && reply[5] == LSDJ_LINK_BAD && reply[6] == 0xf7); }
    /* Presets (0.9.98-dev.6) */
    {
        uint8_t b[1 + LSDJ_LINK_PRESET] = {0};
        memset(ppage, 0xFF, sizeof ppage);   /* erased: none */
        assert(LSDJ_LINK_PRESET_LIST == 0x35 && LSDJ_LINK_PRESET_SAVE == 0x39 && LSDJ_LINK_PRESET == LSDJ_PRESET_BYTES);
        assert(req(LSDJ_LINK_PRESET_LIST, 0, 0, 0) == LSDJ_LINK_OK && rn == 6u + 2u * (1u + 8u * 13u) + 1u && rd(0) == 0xFF);
        for (unsigned i = 0; i < 8; i++) assert(rd(1 + 13 * i) == 0);
        b[0] = 3; assert(req(LSDJ_LINK_PRESET_LOAD, b, 1, 0) == LSDJ_LINK_STATE && loaded_slot == -1);   /* empty */
        assert(req(LSDJ_LINK_PRESET_GET, b, 1, 0) == LSDJ_LINK_OK && rn == 6u + 2u * 128u + 1u);
        for (unsigned i = 0; i < 128; i++) assert(rd(i) == 0);
        /* SAVE: with a name, and without */
        { uint8_t q[13] = {2, 'D', 'U', 'B', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' '};
          assert(req(LSDJ_LINK_PRESET_SAVE, q, 13, 0) == LSDJ_LINK_OK && saved_slot == 2 && !strncmp(saved_name, "DUB", 3)); }
        b[0] = 5; assert(req(LSDJ_LINK_PRESET_SAVE, b, 1, 0) == LSDJ_LINK_OK && saved_slot == 5 && !saved_name[0]);
        assert(req(LSDJ_LINK_PRESET_SAVE, b, 2, 0) == LSDJ_LINK_BAD);
        b[0] = 8; assert(req(LSDJ_LINK_PRESET_SAVE, b, 1, 0) == LSDJ_LINK_BAD);
        assert(req(LSDJ_LINK_PRESET_LIST, 0, 0, 0) == LSDJ_LINK_OK && rd(1 + 13 * 2) == 1 && rd(2 + 13 * 2) == 'D' && rd(1 + 13 * 5) == 1 && rd(2 + 13 * 5) == 'P');
        /* GET -> PUT elsewhere -> the same bytes; LOAD */
        b[0] = 2; assert(req(LSDJ_LINK_PRESET_GET, b, 1, 0) == LSDJ_LINK_OK && rd(0) == LSDJ_PRESET_USED && rd32(LSDJ_PS_FX) == 0xABCDu);
        for (unsigned i = 0; i < 128; i++) b[1 + i] = (uint8_t)rd(i);
        b[0] = 7; assert(req(LSDJ_LINK_PRESET_PUT, b, sizeof b, 0) == LSDJ_LINK_OK && !memcmp(lsdj_preset_slot(ppage, 7), b + 1, 128));
        assert(req(LSDJ_LINK_PRESET_LOAD, b, 1, 0) == LSDJ_LINK_OK && loaded_slot == 7);
        /* refusals: bad slot, short, not well formed; zeros empty the slot */
        b[0] = 8; assert(req(LSDJ_LINK_PRESET_PUT, b, sizeof b, 0) == LSDJ_LINK_BAD);
        b[0] = 7; assert(req(LSDJ_LINK_PRESET_PUT, b, 100, 0) == LSDJ_LINK_BAD);
        b[1 + LSDJ_PS_NFX] = 3; assert(req(LSDJ_LINK_PRESET_PUT, b, sizeof b, 0) == LSDJ_LINK_BAD && lsdj_preset_used(ppage, 7));
        memset(b + 1, 0, 128); assert(req(LSDJ_LINK_PRESET_PUT, b, sizeof b, 0) == LSDJ_LINK_OK && !lsdj_preset_used(ppage, 7));
        b[0] = 9; assert(req(LSDJ_LINK_PRESET_GET, b, 1, 0) == LSDJ_LINK_BAD && req(LSDJ_LINK_PRESET_LIST, b, 1, 0) == LSDJ_LINK_BAD);
        /* during a song import: status 2 */
        assert(begin(SIZE, 0, 0) == LSDJ_LINK_OK);
        b[0] = 2; assert(req(LSDJ_LINK_PRESET_LOAD, b, 1, 0) == LSDJ_LINK_STATE && req(LSDJ_LINK_PRESET_SAVE, b, 1, 0) == LSDJ_LINK_STATE);
        assert(req(LSDJ_LINK_ABORT, 0, 0, 0) == LSDJ_LINK_OK);
        /* firmware without presets: status 1, flag clear */
        { uint8_t q[5] = {0x7d, 'G', 'S', LSDJ_LINK_PRESET_LIST, 0};
          rn = lsdj_link_handle(&st, &io_old, q, 4, 0, reply); assert(reply[5] == LSDJ_LINK_BAD);
          q[3] = LSDJ_LINK_INFO; rn = lsdj_link_handle(&st, &io_old, q, 4, 0, reply); assert(reply[5] == LSDJ_LINK_OK && !(rd(34) & LSDJ_LINK_FLAG_PRESETS)); }
    }
    /* 0.9.98-dev.6, the fast LSDj swap: ops 0x08..0x0B go to io->slot (bytes unpacked, reply packed); while busy
       only INFO and the slot ops; tagged too; INFO's flag bit 2; firmware without it: status 1, flag clear */
    {
        lsdj_link_io_t ios = io; ios.slot = io_slot; ios.busy = io_busy;
        uint8_t q[4 + 2 * 140] = {0x7d, 'G', 'S', LSDJ_LINK_SLOT_INFO, 3, 0};
        assert(lsdj_link_slot_frame(q, 4) && !lsdj_link_slot_frame((const uint8_t[4]){0x7d, 'G', 'S', LSDJ_LINK_INFO}, 4));
        rn = lsdj_link_handle(&st, &ios, q, 6, 0, reply);
        assert(reply[5] == LSDJ_LINK_OK && slot_op == 0 && slot_dn == 1 && slot_d[0] == 3);
        assert(rn == 7 + 2 * 3 && rd(0) == 0xAB && rd(1) == 0 && rd(2) == 0x80);   /* the reply bytes, as pairs */
        q[3] = LSDJ_LINK_SLOT_WRITE;   /* 130 bytes: sector, part, 128 */
        for (unsigned i = 0; i < 130; i++) { q[4 + 2 * i] = (uint8_t)(i & 127); q[5 + 2 * i] = (uint8_t)(i >> 7); }
        rn = lsdj_link_handle(&st, &ios, q, 4 + 260, 0, reply);
        assert(reply[5] == LSDJ_LINK_OK && slot_op == 2 && slot_dn == 130 && slot_d[129] == 129);
        rn = lsdj_link_handle(&st, &ios, q, 4 + 261, 0, reply); assert(reply[5] == LSDJ_LINK_BAD);   /* odd length */
        rn = lsdj_link_handle(&st, &ios, q, 4 + 2 * 133, 0, reply); assert(reply[5] == LSDJ_LINK_BAD);   /* too long */
        q[3] = LSDJ_LINK_SLOT_END; slot_status = LSDJ_LINK_CRC;
        rn = lsdj_link_handle(&st, &ios, q, 4, 0, reply); assert(reply[5] == LSDJ_LINK_CRC && slot_op == 3 && slot_dn == 0);
        slot_status = LSDJ_LINK_OK;
        q[3] = LSDJ_LINK_SLOT_BEGIN | LSDJ_LINK_TAGGED; q[4] = 77;   /* tagged */
        assert(lsdj_link_slot_frame(q, 5));
        rn = lsdj_link_handle(&st, &ios, q, 5, 0, reply); assert(reply[5] == LSDJ_LINK_OK && reply[6] == 77 && slot_op == 1);
        /* busy: the rest answer 2, INFO and the slot ops still work */
        swap_running = 1;
        q[3] = LSDJ_LINK_SETTINGS_GET; rn = lsdj_link_handle(&st, &ios, q, 4, 0, reply); assert(reply[5] == LSDJ_LINK_STATE);
        q[3] = LSDJ_LINK_PRESET_LIST; rn = lsdj_link_handle(&st, &ios, q, 4, 0, reply); assert(reply[5] == LSDJ_LINK_STATE);
        q[3] = LSDJ_LINK_BEGIN; rn = lsdj_link_handle(&st, &ios, q, 4, 0, reply); assert(reply[5] == LSDJ_LINK_STATE);
        q[3] = LSDJ_LINK_INFO; rn = lsdj_link_handle(&st, &ios, q, 4, 0, reply);
        assert(reply[5] == LSDJ_LINK_OK && (rd(34) & LSDJ_LINK_FLAG_SWAP) && (rd(34) & LSDJ_LINK_FLAG_PRESETS));
        q[3] = LSDJ_LINK_SLOT_END; rn = lsdj_link_handle(&st, &ios, q, 4, 0, reply); assert(reply[5] == LSDJ_LINK_OK);
        swap_running = 0;
        /* during a song import: the slot ops answer 2 */
        assert(begin(SIZE, 0, 0) == LSDJ_LINK_OK);
        slot_op = 99; rn = lsdj_link_handle(&st, &ios, q, 4, 0, reply); assert(reply[5] == LSDJ_LINK_STATE && slot_op == 99);
        assert(req(LSDJ_LINK_ABORT, 0, 0, 0) == LSDJ_LINK_OK);
        /* without: status 1, flag clear */
        q[3] = LSDJ_LINK_SLOT_INFO; q[4] = 0; q[5] = 0;
        rn = lsdj_link_handle(&st, &io, q, 6, 0, reply); assert(reply[5] == LSDJ_LINK_BAD);
        assert(req(LSDJ_LINK_INFO, 0, 0, 0) == LSDJ_LINK_OK && !(rd(34) & LSDJ_LINK_FLAG_SWAP));
    }
    /* Junk */
    assert(req(0x7E, 0, 0, 0) == LSDJ_LINK_BAD);
    assert(req(LSDJ_LINK_INFO, (const uint8_t[1]){1}, 1, 0) == LSDJ_LINK_BAD);
    { uint8_t q[4] = {0x7d, 'G', 'D', 1}; assert(!lsdj_link_match(q, 4)); }
    /* READ_STREAM: status 1 without a stream (and no INFO flag); with one: started, its total, the flag; refused
       while songs come in; bad lengths and a what past 1: status 1 */
    { uint8_t b[9] = {0}; le32(b + 1, 0); le32(b + 5, SIZE);
      assert(req(LSDJ_LINK_READ_STREAM, b, 9, 0) == LSDJ_LINK_BAD);
      io_s = io; io_s.stream = io_rstream;
      uint8_t q[4 + 18] = {0x7d, 'G', 'S', LSDJ_LINK_INFO};
      rn = lsdj_link_handle(&st, &io_s, q, 4, 0, reply); assert(reply[5] == 0 && (rd(34) & LSDJ_LINK_FLAG_STREAM));
      b[0] = 1; le32(b + 1, 240); le32(b + 5, 1000);
      q[3] = LSDJ_LINK_READ_STREAM; for (int i = 0; i < 9; i++) { q[4 + 2 * i] = b[i] & 127; q[5 + 2 * i] = b[i] >> 7; }
      rn = lsdj_link_handle(&st, &io_s, q, 22, 0, reply);
      assert(reply[5] == 0 && rd32(0) == 4096u && st_what == 1 && st_off == 240 && st_len == 1000);
      q[4] = 2;   /* what 2 */
      rn = lsdj_link_handle(&st, &io_s, q, 22, 0, reply); assert(reply[5] == LSDJ_LINK_BAD);
      q[4] = 1; rn = lsdj_link_handle(&st, &io_s, q, 20, 0, reply); assert(reply[5] == LSDJ_LINK_BAD);   /* short */
      st.importing = 1; rn = lsdj_link_handle(&st, &io_s, q, 22, 0, reply); assert(reply[5] == LSDJ_LINK_STATE); st.importing = 0; }
    /* IDENTIFY (0.9.98-dev.19): number 1..99, seconds 0..60; status 1 for others, a short request, or old firmware */
    {
      lsdj_link_io_t ioi = io; ioi.identify = io_ident;
      uint8_t q[8] = {0x7d, 'G', 'S', LSDJ_LINK_IDENTIFY, 0, 0, 0, 0};
      const struct { uint8_t no, s; int ok; } c[] = {{1, 10, 1}, {2, 0, 1}, {99, 60, 1}, {0, 10, 0}, {100, 10, 0}, {3, 61, 0}, {12, 200, 0}};
      assert(LSDJ_LINK_IDENTIFY == 0x3C);
      for (unsigned i = 0; i < sizeof c / sizeof c[0]; i++) {
        ident_no = ident_s = 0xFF; q[4] = c[i].no & 127; q[5] = c[i].no >> 7; q[6] = c[i].s & 127; q[7] = c[i].s >> 7;
        rn = lsdj_link_handle(&st, &ioi, q, 8, 0, reply);
        assert(reply[5] == (c[i].ok ? LSDJ_LINK_OK : LSDJ_LINK_BAD));
        assert(c[i].ok ? ident_no == c[i].no && ident_s == c[i].s : ident_no == 0xFF);
      }
      rn = lsdj_link_handle(&st, &ioi, q, 6, 0, reply); assert(reply[5] == LSDJ_LINK_BAD);   /* short */
      q[4] = 1; q[5] = 0; q[6] = 5; q[7] = 0;
      rn = lsdj_link_handle(&st, &io, q, 8, 0, reply); assert(reply[5] == LSDJ_LINK_BAD); }   /* (none: older firmware) */
    /* RESTART (0.9.98-dev.19): why, then 11 words, read only; status 1 with arguments, or on older firmware */
    { lsdj_link_io_t ior = io; ior.restart = io_restart;
      uint8_t q[6] = {0x7d, 'G', 'S', LSDJ_LINK_RESTART, 0, 0};
      assert(LSDJ_LINK_RESTART == 0x3D && LSDJ_LINK_RESTART_WORDS == 12u);   /* (11 before dev.21: + CPU1 now) */
      rn = lsdj_link_handle(&st, &ior, q, 4, 0, reply);
      assert(reply[5] == LSDJ_LINK_OK && rn == 6u + 2u * (1u + 4u * 12u) + 1u && reply[rn - 1] == 0xf7 && rd(0) == 1);
      for (uint32_t i = 0; i < 12; i++) { uint32_t v = rd(1 + 4 * i) | rd(2 + 4 * i) << 8 | rd(3 + 4 * i) << 16 | rd(4 + 4 * i) << 24; assert(v == 0x02000000u + i * 0x01010101u); }
      rn = lsdj_link_handle(&st, &ior, q, 6, 0, reply); assert(reply[5] == LSDJ_LINK_BAD);   /* an argument */
      rn = lsdj_link_handle(&st, &io, q, 4, 0, reply); assert(reply[5] == LSDJ_LINK_BAD); }   /* (none: older firmware) */
    /* TEST (0.9.98-dev.20 HANG, dev.21 CORE / CHIP; dev builds): only those four letters; a release (NULL) refuses */
    { lsdj_link_io_t ioh = io; ioh.test = io_test;
      uint8_t q[12] = {0x7d, 'G', 'S', LSDJ_LINK_TEST, 'H', 0, 'A', 0, 'N', 0, 'G', 0};
      assert(LSDJ_LINK_TEST == 0x3E);
      rn = lsdj_link_handle(&st, &io, q, 12, 0, reply); assert(reply[5] == LSDJ_LINK_BAD && hangs == 0);   /* a release */
      q[10] = 'X'; rn = lsdj_link_handle(&st, &ioh, q, 12, 0, reply); assert(reply[5] == LSDJ_LINK_BAD && hangs == 0);
      rn = lsdj_link_handle(&st, &ioh, q, 10, 0, reply); assert(reply[5] == LSDJ_LINK_BAD && hangs == 0);   /* short */
      q[10] = 'G'; rn = lsdj_link_handle(&st, &ioh, q, 12, 0, reply); assert(reply[5] == LSDJ_LINK_OK && hangs == 1);
      uint8_t core[12] = {0x7d, 'G', 'S', LSDJ_LINK_TEST, 'C', 0, 'O', 0, 'R', 0, 'E', 0}, chip[12] = {0x7d, 'G', 'S', LSDJ_LINK_TEST, 'C', 0, 'H', 0, 'I', 0, 'P', 0};
      rn = lsdj_link_handle(&st, &ioh, core, 12, 0, reply); assert(reply[5] == LSDJ_LINK_OK && tested[1] == 1 && tested[2] == 0);
      rn = lsdj_link_handle(&st, &ioh, chip, 12, 0, reply); assert(reply[5] == LSDJ_LINK_OK && tested[1] == 1 && tested[2] == 1);
      rn = lsdj_link_handle(&st, &io, chip, 12, 0, reply); assert(reply[5] == LSDJ_LINK_BAD && tested[2] == 1); }   /* a release */
    /* LAST_RESTART (0.9.98-dev.22): 6 words when one is kept; status 1 when none, with an argument, or older firmware */
    { lsdj_link_io_t iol = io; iol.last_restart = io_last;
      uint8_t q[6] = {0x7d, 'G', 'S', LSDJ_LINK_LAST_RESTART, 0, 0};
      assert(LSDJ_LINK_LAST_RESTART == 0x3F && LSDJ_LINK_LAST_WORDS == 6u);
      kept_has = 0; rn = lsdj_link_handle(&st, &iol, q, 4, 0, reply); assert(reply[5] == LSDJ_LINK_BAD);   /* none kept */
      kept_has = 1; rn = lsdj_link_handle(&st, &iol, q, 4, 0, reply);
      assert(reply[5] == LSDJ_LINK_OK && rn == 6u + 2u * (4u * 6u) + 1u);
      for (uint32_t i = 0; i < 6; i++) { uint32_t v = rd(4 * i) | rd(1 + 4 * i) << 8 | rd(2 + 4 * i) << 16 | rd(3 + 4 * i) << 24; assert(v == 0x52030101u + i); }
      rn = lsdj_link_handle(&st, &iol, q, 6, 0, reply); assert(reply[5] == LSDJ_LINK_BAD);   /* an argument */
      rn = lsdj_link_handle(&st, &io, q, 4, 0, reply); assert(reply[5] == LSDJ_LINK_BAD); }   /* older firmware */
    puts("PASS: web link: info, song export/import (crc, flash, order, timeout), settings, effects, theme, store, live, screen, screen sync, screen push, DJ ops (volume, SEQ, song rows, SYNC, DJ_DECK, DJ_KEY), presets, the swap's ops, READ_STREAM, IDENTIFY, RESTART (+ CPU1), TEST (HANG, CORE, CHIP), LAST_RESTART");
    return 0;
}
