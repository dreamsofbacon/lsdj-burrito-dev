/* SPDX-License-Identifier: GPL-3.0-only */
/* Host test for firmware/lsdj_usbrate.h: the FM-1 renders 256 frames at 750000 / 17 Hz; a host whose clock is
   -150, 0 or +150 ppm off takes 44.1 frames a ms (44 / 45, as usb.c uac_packet, with its +-1 safety net outside
   96..160). Over 10 simulated minutes: the ring never runs dry or over, the safety net never acts after the first
   seconds, the fill settles near the middle, and a 1 kHz tone comes out at 1 kHz in the host's time (within 2 ppm
   of where its clock says it is), so a song's tempo lands on the DAW's grid. Also the interpolator: a tone through
   it comes back with its shape (error under -70 dB). */
#include <assert.h>
#include <math.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "lsdj_usbrate.h"
#ifndef M_PI
#define M_PI 3.14159265358979323846
#endif

#define N 512u
static uint32_t ring[N];

static void run(double ppm) {
    lsdj_ur_t u; lsdj_ur_init(&u, 128);
    const double fs = 750000.0 / 17.0, host_ms = 0.001 * (1.0 + ppm * 1e-6);   /* a host ms, in FM-1 seconds */
    double t = 0, next_render = 0, next_pkt = 0, ph = 0;
    uint32_t w = 104, r = 0, acc = 0;           /* primed with 104 frames of silence, as usb.c */
    int32_t fill_min = 104;                     /* usb.c uac.fill_min: the fill when the last render started */
    long adj = 0, dry = 0, over = 0, renders = 0;
    int16_t in[512];
    /* the output's zero crossings (rising), in host samples, over the last 5 minutes */
    long hs = 0, first = -1, last = -1, cycles = 0; int prev = 0; int32_t fmin = 1 << 30, fmax = -(1 << 30);
    while (t < 600.0) {
        if (next_render <= next_pkt) {
            t = next_render; next_render += 256.0 / fs;
            int32_t fill = (int32_t)(w - r); fill_min = fill;
            for (int i = 0; i < 256; i++) { int16_t v = (int16_t)(16000.0 * sin(ph)); ph += 2 * M_PI * 1000.0 / fs; in[2 * i] = v; in[2 * i + 1] = (int16_t)-v; }
            if (N - (w - r) < 260u) { over++; continue; }
            w += lsdj_ur_block(&u, fill, in, 256, ring, N - 1u, w);
            renders++;
            if (t > 60) { if (fill < fmin) fmin = fill; if (fill > fmax) fmax = fill; }
        } else {
            t = next_pkt; next_pkt += host_ms;
            uint32_t n = 44; acc += 100; if (acc >= 1000) { acc -= 1000; n++; }

            if (fill_min > 160) { n++; if (t > 30) adj++; } else if (fill_min < 96) { n--; if (t > 30) adj++; }   /* (usb.c uac_packet: its net on fill_min, 96..160) */
            for (uint32_t i = 0; i < n; i++) {
                if (r == w) { dry++; continue; }
                int16_t v = (int16_t)(ring[r & (N - 1u)] & 0xFFFF); r++;
                if (t > 300) { int up = v > 0; if (up && !prev) { if (first < 0) first = hs; else cycles++; last = hs; } prev = up; }
                hs++;
            }
        }
    }
    double f = cycles * 44100.0 / (double)(last - first);                 /* Hz in the host's samples */
    double want = 1000.0 * (1.0 + ppm * 1e-6);                             /* 1 kHz real, in host seconds (a host ms is 1 + ppm FM-1 ms) */
    double err = (f / want - 1.0) * 1e6;
    printf("host %+5.0f ppm: fill %d..%d, step %u (nominal %u), tone %.4f Hz (%+.2f ppm), dry %ld, over %ld, net %ld\n",
           ppm, fmin, fmax, u.step, LSDJ_UR_NOM, f, err, dry, over, adj);
    assert(!dry && !over && !adj && fabs(err) < 2.0 && fmin > 64 && fmax < 200);
}

int main(void) {
    assert(fabs(LSDJ_UR_NOM - 268435456.0 * 7500.0 / 7497.0) < 1.0);
    /* the interpolator alone, at the fixed step (its place sweeps 1.6 times round in 4096 frames): a tone against the
       exact tone at the output's times. Output j is at input j x step - 4 (it plays between l[3] and l[4]). */
    static const double tones[3][2] = {{3000, -60}, {10000, -40}, {12000, -30}};
    for (int f = 0; f < 3; f++) {
        lsdj_ur_t u; lsdj_ur_init(&u, 0); u.primed = 1; u.ef = 0;
        static int16_t in[2 * 4096]; static uint32_t out[8192]; double fs = 750000.0 / 17.0, hz = tones[f][0];
        for (int i = 0; i < 4096; i++) in[2 * i] = in[2 * i + 1] = (int16_t)(20000.0 * sin(2 * M_PI * hz * i / fs));
        uint32_t k = lsdj_ur_block(&u, 0, in, 4096, out, 8191u, 0);
        double e2 = 0, s2 = 0;
        for (uint32_t j = 100; j < k - 10; j++) {
            double pos = j * (double)LSDJ_UR_NOM / LSDJ_UR_ONE - 4.0, want = 20000.0 * sin(2 * M_PI * hz * pos / fs);
            double got = (int16_t)(out[j] & 0xFFFF); e2 += (got - want) * (got - want); s2 += want * want;
        }
        printf("interpolator: %5.0f Hz error %.1f dB\n", hz, 10 * log10(e2 / s2));
        assert(10 * log10(e2 / s2) < tones[f][1]);
    }
    run(0); run(-150); run(150);
    puts("PASS usb rate: the host's own 44.1 kHz at -150 / 0 / +150 ppm, ring steady, safety net idle, tone exact");
    return 0;
}
