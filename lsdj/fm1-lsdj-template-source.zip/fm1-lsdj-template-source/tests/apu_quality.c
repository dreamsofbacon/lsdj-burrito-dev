/* SPDX-License-Identifier: GPL-3.0-only */
/* Host test: the Game Boy sound core (build/minigb_apu.c, tools/prepare_apu.py + tools/apu_quality.py) sounds like a
   DMG (0.9.98-dev.27; Colin: "nowhere near as good as an original, FPGA or even PC emulators"):
   - aliasing: a high pulse and a wave note, 16384 samples through a Hann window: the energy away from the note's
     harmonics (and DC), in dB under the whole. MiniGB point-sampled each channel (its box filter's weight was an
     integer division, always 0), and the harmonics past 22 kHz folded back as tones not in the music: about -13 dB
     here. A box (the average over each sample) gave about -23 dB, the triangle (tools/apu_quality.py) about -28.
   - the WAV volume (NR32): 50 % and 25 % play at the DMG's 7/15 and 3/15 of 100 % (its shift of the 4-bit level);
     MiniGB applied it twice (25 % and about 6 %).
   - the output stage: a 12.5 % pulse (DAC 0 .. volume, then the high-pass) settles round zero: no DC.
   Prints each figure; ARGS "old" only prints (for a before / after with an older build/minigb_apu.c).
   Build: gcc -std=c99 -O2 tests/apu_quality.c build/minigb_apu.c -Ivendor/peanut-gb -Isrc \
          -DMINIGB_APU_AUDIO_FORMAT_S16SYS -DAUDIO_SAMPLE_RATE=44100 -lm */
#include <math.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdint.h>
#include <stdbool.h>
#include "minigb_apu.h"

void minigb_apu_split(int16_t *out);
void minigb_apu_render(struct minigb_apu_ctx *ctx, audio_sample_t *stream, unsigned frames);

#define RATE 44100.0
#ifndef M_PI
#define M_PI 3.14159265358979323846
#endif
#define N 16384u
#define SETTLE 8820u   /* 0.2 s */
static struct minigb_apu_ctx A;
static int16_t split[(N + SETTLE) * 5u];
static audio_sample_t mix[(N + SETTLE) * 2u];
static double sig[N];
static int fails;

static void w(uint16_t a, uint8_t v) { minigb_apu_audio_write(&A, a, v); }
static void start(void) {
    minigb_apu_audio_init(&A); minigb_apu_split(split);
    w(0xFF26, 0x80); w(0xFF24, 0x77); w(0xFF25, 0xFF);
}
static void pulse(unsigned x, uint8_t duty) {
    start(); w(0xFF10, 0); w(0xFF11, duty); w(0xFF12, 0xF0); w(0xFF13, (uint8_t)x); w(0xFF14, (uint8_t)(0x80 | x >> 8));
}
static void wave(unsigned x, const uint8_t *ram, uint8_t nr32) {
    start(); w(0xFF1A, 0);
    for (unsigned i = 0; i < 16; i++) w((uint16_t)(0xFF30 + i), ram[i]);
    w(0xFF1A, 0x80); w(0xFF1C, nr32); w(0xFF1D, (uint8_t)x); w(0xFF1E, (uint8_t)(0x80 | x >> 8));
}
/* channel ch's own output (the split), N samples after SETTLE, into sig */
static void take(unsigned ch) {
    minigb_apu_render(&A, mix, N + SETTLE);
    for (unsigned i = 0; i < N; i++) sig[i] = split[(SETTLE + i) * 5u + ch];
}

/* in-place radix-2 FFT */
static void fft(double *re, double *im, unsigned n) {
    for (unsigned i = 1, j = 0; i < n; i++) {
        unsigned b = n >> 1;
        for (; j & b; b >>= 1) j ^= b;
        j ^= b;
        if (i < j) { double t = re[i]; re[i] = re[j]; re[j] = t; t = im[i]; im[i] = im[j]; im[j] = t; }
    }
    for (unsigned len = 2; len <= n; len <<= 1) {
        double a = -2 * M_PI / len, wr = cos(a), wi = sin(a);
        for (unsigned i = 0; i < n; i += len) {
            double cr = 1, ci = 0;
            for (unsigned k = 0; k < len / 2; k++) {
                unsigned p = i + k, q = p + len / 2;
                double tr = re[q] * cr - im[q] * ci, ti = re[q] * ci + im[q] * cr;
                re[q] = re[p] - tr; im[q] = im[p] - ti; re[p] += tr; im[p] += ti;
                double nr = cr * wr - ci * wi; ci = cr * wi + ci * wr; cr = nr;
            }
        }
    }
}
/* dB of the energy more than 4 bins from every harmonic of f0 (and DC), under the whole */
static double alias_db(double f0) {
    static double re[N], im[N];
    for (unsigned i = 0; i < N; i++) { re[i] = sig[i] * (0.5 - 0.5 * cos(2 * M_PI * i / N)); im[i] = 0; }
    fft(re, im, N);
    double all = 0, off = 0, bin = RATE / N;
    for (unsigned k = 1; k < N / 2; k++) {
        double e = re[k] * re[k] + im[k] * im[k], f = k * bin, h = fmod(f, f0);
        all += e;
        if (fmin(h, f0 - h) > 4 * bin) off += e;
    }
    return 10 * log10(off / all + 1e-30);
}
static double peak_to_peak(void) {
    double lo = 1e9, hi = -1e9;
    for (unsigned i = 0; i < N; i++) { if (sig[i] < lo) lo = sig[i]; if (sig[i] > hi) hi = sig[i]; }
    return hi - lo;
}
static void check(bool ok, const char *what) { if (!ok) { printf("FAIL %s\n", what); fails++; } }

int main(int argc, char **argv) {
    bool old = argc > 1 && !strcmp(argv[1], "old");
    static const uint8_t saw[16] = {0x01, 0x23, 0x45, 0x67, 0x89, 0xAB, 0xCD, 0xEF, 0x01, 0x23, 0x45, 0x67, 0x89, 0xAB, 0xCD, 0xEF};
    static const uint8_t sq[16] = {0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0, 0, 0, 0, 0, 0, 0, 0};

    /* 1. aliasing: pulse C7 (x 1985, 2080 Hz, 50 %), pulse C6 at 12.5 % (x 1923, 1049 Hz), a saw on the wave (x 1985: 2 cycles
          of 16 steps in its 32: 2080 Hz) */
    pulse(1985, 0x80); take(0); double a1 = alias_db(131072.0 / 63);
    pulse(1923, 0x00); take(0); double a2 = alias_db(131072.0 / 125);
    wave(1985, saw, 0x20); take(2); double a3 = alias_db(2 * 65536.0 / 63);
    printf("aliasing (energy off the harmonics): pulse C7 %.1f dB, pulse C6 12.5 %% %.1f dB, wave saw C7 %.1f dB\n", a1, a2, a3);

    /* 2. the WAV volume */
    wave(1797, sq, 0x20); take(2); double v100 = peak_to_peak();
    wave(1797, sq, 0x40); take(2); double v50 = peak_to_peak();
    wave(1797, sq, 0x60); take(2); double v25 = peak_to_peak();
    printf("wave volume: 50 %% at %.3f of 100 %% (DMG 0.467), 25 %% at %.3f (DMG 0.200)\n", v50 / v100, v25 / v100);

    /* 3. no DC: a 12.5 % pulse (x 1797, 522 Hz) */
    pulse(1797, 0x00); take(0);
    double mean = 0; for (unsigned i = 0; i < N; i++) mean += sig[i];
    mean /= N; double pp = peak_to_peak();
    printf("12.5 %% pulse: mean %.1f of peak to peak %.0f (%.2f %%)\n", mean, pp, 100 * fabs(mean) / pp);

    if (old) return 0;
    check(a1 < -26 && a2 < -26 && a3 < -26, "aliasing: less than -26 dB off the harmonics (MiniGB: about -13)");
    check(fabs(v50 / v100 - 7.0 / 15) < 0.02 && fabs(v25 / v100 - 3.0 / 15) < 0.02, "the WAV volume: the DMG's 7/15 and 3/15");
    check(fabs(mean) / pp < 0.005, "no DC after the output stage");
    if (fails) return 1;
    puts("PASS apu quality: aliasing under -26 dB (pulse, wave; MiniGB about -13), the WAV volume once (7/15, 3/15), no DC (the DMG's high-pass)");
    return 0;
}
