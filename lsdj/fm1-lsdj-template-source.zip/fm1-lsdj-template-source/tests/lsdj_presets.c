/* SPDX-License-Identifier: GPL-3.0-only */
/* Host test for firmware/lsdj_presets.h: the page (erased = none, the head, 8 slots of 128 bytes), a preset kept
   and read back, names cleaned up, the link's raw slots checked, the list lines, the feature switches a preset
   brings, and the glide (amounts slide, choices jump, endpoints exact, stops when someone else turns a knob). */
#include <assert.h>
#include <stdio.h>
#include <string.h>
#include "lsdj_presets.h"
#include "lsdj_overlay.h"   /* lsdj_ov_chars: what the list's font can draw */

static uint8_t page[LSDJ_PRESETS_PAGE];
typedef char params_bytes[sizeof(lsdj_fx_params_t) == 4 * FXP_CH_COUNT + FXM_COUNT + 1 + 4 * FXQ_COUNT + 2 + FXR_COUNT + 4 ? 1 : -1];
typedef char page_size[LSDJ_PRESETS_PAGE == 1040u && LSDJ_PS_END <= LSDJ_PRESET_BYTES ? 1 : -1];

static lsdj_preset_t sample(unsigned seed) {
    lsdj_preset_t p; memset(&p, 0, sizeof p);
    strcpy(p.name, "dub echo");
    for (unsigned k = 0; k < LSDJ_PRESET_FX; k++) p.fx[k] = 0x01020304u * (k + seed);
    p.settings = 0x5A000000u | seed; p.midi = 0x4D000000u | seed; p.feat = 0x460001CEu;
    for (unsigned k = 0; k < 8; k++) p.theme[k] = (uint16_t)(0x1111u * k + seed);
    return p;
}

int main(void) {
    char l[20];
    /* erased: no presets */
    memset(page, 0xFF, sizeof page);
    assert(!lsdj_presets_ok(page) && lsdj_presets_current(page) == LSDJ_PRESET_NONE);
    for (unsigned i = 0; i < LSDJ_PRESETS; i++) { lsdj_preset_t p; assert(!lsdj_preset_used(page, i) && !lsdj_preset_get(page, i, &p)); }
    /* kept and read back; the others stay empty */
    lsdj_preset_t a = sample(3), b;
    lsdj_preset_put(page, 2, &a);
    assert(lsdj_presets_ok(page) && lsdj_preset_used(page, 2) && !lsdj_preset_used(page, 1) && !lsdj_preset_used(page, 3));
    assert(lsdj_preset_get(page, 2, &b) && !strcmp(b.name, "DUB ECHO"));
    assert(!memcmp(a.fx, b.fx, sizeof a.fx) && a.settings == b.settings && a.midi == b.midi && a.feat == b.feat && !memcmp(a.theme, b.theme, sizeof a.theme));
    assert(lsdj_preset_raw_ok(lsdj_preset_slot(page, 2)) && lsdj_preset_raw_ok(lsdj_preset_slot(page, 0)));
    /* the current slot */
    assert(lsdj_presets_current(page) == LSDJ_PRESET_NONE);
    lsdj_presets_set_current(page, 2); assert(lsdj_presets_current(page) == 2);
    /* names: cleaned up, empty -> "PRESET n", 12 at most */
    strcpy(a.name, "a~b"); lsdj_preset_put(page, 0, &a); lsdj_preset_get(page, 0, &b); assert(!strcmp(b.name, "A B"));
    strcpy(a.name, "   "); lsdj_preset_put(page, 4, &a); lsdj_preset_get(page, 4, &b); assert(!strcmp(b.name, "PRESET 5"));
    strcpy(a.name, "ABCDEFGHIJKL"); lsdj_preset_put(page, 7, &a); lsdj_preset_get(page, 7, &b); assert(!strcmp(b.name, "ABCDEFGHIJKL"));
    /* raw slots from the link: refusals; an all-zero slot clears it (and the current mark) */
    uint8_t raw[LSDJ_PRESET_BYTES]; memcpy(raw, lsdj_preset_slot(page, 2), sizeof raw);
    raw[LSDJ_PS_NFX] = 17; assert(!lsdj_preset_raw_ok(raw)); raw[LSDJ_PS_NFX] = 19;
    raw[LSDJ_PS_NAME] = 'a'; assert(!lsdj_preset_raw_ok(raw)); raw[LSDJ_PS_NAME] = 'D';
    raw[127] = 1; assert(!lsdj_preset_raw_ok(raw)); raw[127] = 0;
    memset(raw + LSDJ_PS_NAME, ' ', LSDJ_PRESET_NAME); assert(!lsdj_preset_raw_ok(raw));
    memset(raw, 0, sizeof raw); assert(lsdj_preset_raw_ok(raw)); raw[5] = 1; assert(!lsdj_preset_raw_ok(raw)); raw[5] = 0;
    lsdj_preset_put_raw(page, 2, raw); assert(!lsdj_preset_used(page, 2) && lsdj_presets_current(page) == LSDJ_PRESET_NONE);
    lsdj_preset_put_raw(page, 2, lsdj_preset_slot(page, 7)); assert(lsdj_preset_get(page, 2, &b) && !strcmp(b.name, "ABCDEFGHIJKL"));
    /* the raw slot onto an erased page starts it */
    { static uint8_t p2[LSDJ_PRESETS_PAGE]; memset(p2, 0xFF, sizeof p2); lsdj_preset_put_raw(p2, 5, lsdj_preset_slot(page, 2));
      assert(lsdj_presets_ok(p2) && lsdj_preset_used(p2, 5) && !lsdj_preset_used(p2, 4)); }
    /* list lines fit LSDj's font and 19 columns */
    for (unsigned i = 0; i < LSDJ_PRESETS; i++) {
        lsdj_preset_line(page, i, l); assert(strlen(l) <= 19u);
        for (const char *c = l; *c; c++) assert(strchr(lsdj_ov_chars, *c));
    }
    lsdj_preset_line(page, 7, l); assert(!strcmp(l, "8 C5  ABCDEFGHIJKL"));
    lsdj_preset_line(page, 1, l); assert(!strcmp(l, "2 D4  -"));
    /* the keys: the white keys C4 .. C5 (F3 = 0) */
    assert(lsdj_preset_key[0] == 7 && lsdj_preset_key[7] == 19);
    /* feature switches: the device's own stay */
    {
        lsdj_feat_t now, pre; lsdj_feat_defaults(&now); lsdj_feat_defaults(&pre);
        pre.v[LSDJ_FEAT_WRAP] = 1; pre.v[LSDJ_FEAT_AUTOSAVE] = 3; pre.v[LSDJ_FEAT_RATE] = 2; pre.v[LSDJ_FEAT_GLIDE] = 7; pre.v[LSDJ_FEAT_BATTERY] = 0;
        pre.v[LSDJ_FEAT_THEME] = 4;
        lsdj_preset_feat_merge(&now, &pre);
        assert(now.v[LSDJ_FEAT_WRAP] == 1 && now.v[LSDJ_FEAT_THEME] == 4);
        assert(now.v[LSDJ_FEAT_AUTOSAVE] == 1 && now.v[LSDJ_FEAT_RATE] == 0 && now.v[LSDJ_FEAT_GLIDE] == 1 && now.v[LSDJ_FEAT_BATTERY] == 1);
    }
    /* glide */
    {
        lsdj_fx_params_t now, to; memset(&now, 0, sizeof now); memset(&to, 0, sizeof to);
        now.ch[0][FXP_CUTOFF] = 0; to.ch[0][FXP_CUTOFF] = 100;
        now.ch[1][FXP_TYPE] = 1; to.ch[1][FXP_TYPE] = 3;
        now.m[FXM_FEEDBACK] = 120; to.m[FXM_FEEDBACK] = 20;
        now.q[2][FXQ_LFO_SHAPE] = 0; to.q[2][FXQ_LFO_SHAPE] = 4;
        now.r[FXR_MIX] = 10; to.r[FXR_MIX] = 11;
        lsdj_glide_t g;
        lsdj_glide_start(&g, &now, &to, 1000, 1000);
        assert(g.on && now.ch[1][FXP_TYPE] == 3 && now.q[2][FXQ_LFO_SHAPE] == 4);   /* choices at once */
        assert(now.ch[0][FXP_CUTOFF] == 0 && now.m[FXM_FEEDBACK] == 120);             /* amounts from where they were */
        assert(lsdj_glide_step(&g, &now, 1500) && now.ch[0][FXP_CUTOFF] == 50 && now.m[FXM_FEEDBACK] == 70);
        assert(lsdj_glide_step(&g, &now, 1750) && now.ch[0][FXP_CUTOFF] == 75);
        assert(lsdj_glide_step(&g, &now, 2000) && !g.on && !memcmp(&now, &to, sizeof now));   /* exactly there */
        assert(!lsdj_glide_step(&g, &now, 2100));
        /* someone else turns a knob: the glide stops where it is */
        memset(&now, 0, sizeof now);
        lsdj_glide_start(&g, &now, &to, 0, 1000);
        assert(lsdj_glide_step(&g, &now, 100));
        now.ch[3][FXP_DRIVE] = 9; uint8_t cut = now.ch[0][FXP_CUTOFF];
        assert(!lsdj_glide_step(&g, &now, 200) && !g.on && now.ch[0][FXP_CUTOFF] == cut && now.ch[3][FXP_DRIVE] == 9);
        /* OFF: at once; nothing to slide: not on */
        memset(&now, 0, sizeof now);
        lsdj_glide_start(&g, &now, &to, 0, 0); assert(!g.on && !memcmp(&now, &to, sizeof now));
        lsdj_glide_start(&g, &now, &to, 0, 500); assert(!g.on);
        /* SYNC changes: the echo time jumps with it */
        memset(&now, 0, sizeof now); now.m[FXM_TIME] = 100; to.m[FXM_SYNC] = 1; to.m[FXM_TIME] = 5;
        lsdj_glide_start(&g, &now, &to, 0, 1000); assert(now.m[FXM_SYNC] == 1 && now.m[FXM_TIME] == 5);
        assert(lsdj_glide_step(&g, &now, 500) && now.m[FXM_TIME] == 5);
    }
    puts("PASS: presets: erased page, slots kept and read back, names, link slots checked, list lines, kept switches, glide (slide, choices, ends, stops, sync)");
    return 0;
}
