/* SPDX-License-Identifier: GPL-3.0-only */
/* Host test for firmware/lsdj_clock.h: a DAC at 750000 / 17 Hz (44,117.647) and a host whose USB frames run 30 ppm
   slow, simulated over 10 minutes with the 32-bit timer wrapping (every 179 s), half-buffer interrupts (256 frames)
   and the frame number read every 10 ms (11 bits, wrapping), now and then misread as 0: the rates come out within
   0.05 Hz. */
#include <assert.h>
#include <stdio.h>
#include <string.h>
#include "lsdj_clock.h"

int main(void) {
    lsdj_clk_t c; memset(&c, 0, sizeof c);
    char l1[20], l2[20];
    lsdj_clk_lines(&c, l1, l2);
    assert(!strcmp(l1, "AUDIO --") && !strcmp(l2, "USB   -- (NO HOST)"));
    const double dac = 750000.0 / 17.0, host = 1000.0 * (1.0 - 30e-6);   /* frames a second (FM-1 time) */
    const double start = 4294000000.0;                                    /* the timer about to wrap */
    double next_irq = 0, next_poll = 0;
    uint64_t frames = 0;
    for (double t = 0; t < 600.0; ) {                                     /* seconds of FM-1 time */
        if (next_irq <= next_poll) {
            t = next_irq; frames += 256; next_irq += 256.0 / dac;
            lsdj_clk_dac(&c, (uint32_t)(uint64_t)(start + t * LSDJ_CLK_HZ), frames);
        } else {
            t = next_poll; next_poll += 0.0005;                           /* usb_poll at 2 kHz; the number every 10 ms */
            static unsigned k;
            uint16_t fr = (uint16_t)((uint64_t)(t * host) & 0x7FFu);
            if (k % 7919u == 3u) fr = 0;                                  /* now and then a bad read (the SIE's 0) */
            if (++k % 20u == 0u) lsdj_clk_usb(&c, (uint32_t)(uint64_t)(start + t * LSDJ_CLK_HZ), fr);
            else lsdj_clk_usb(&c, (uint32_t)(uint64_t)(start + t * LSDJ_CLK_HZ), c.frame);
        }
    }
    double d = lsdj_clk_dac_mhz(&c) / 1000.0, h = lsdj_clk_host_mhz(&c) / 1000.0;
    printf("dac %.3f Hz (true %.3f), in host seconds %.3f Hz (true %.3f)\n", d, dac, h, dac / (host / 1000.0));
    assert(d > dac - 0.02 && d < dac + 0.02);
    assert(h > dac / (host / 1000.0) - 0.05 && h < dac / (host / 1000.0) + 0.05);
    lsdj_clk_lines(&c, l1, l2);
    printf("meter: \"%s\" / \"%s\"\n", l1, l2);
    assert(!strncmp(l1, "AUDIO 44117.6", 13) && strlen(l1) <= 19 && !strncmp(l2, "USB   4411", 10) && strlen(l2) <= 19);
    lsdj_clk_usb_lost(&c); lsdj_clk_lines(&c, l1, l2); assert(!strcmp(l2, "USB   -- (NO HOST)"));
    puts("PASS clock: DAC rate and its rate in host seconds within 0.05 Hz over 10 minutes, timer and frame wraps, meter lines");
    return 0;
}
