/* SPDX-License-Identifier: GPL-3.0-only */
/* Host test for firmware/lsdj_stopwhy.h (0.9.98-dev.28): why LSDj last stopped, and the clock around it. */
#include <assert.h>
#include <stdio.h>
#include "lsdj_stopwhy.h"

static lsdj_why_t w;
static uint32_t t;
/* ms of play at 120 BPM (a tick each 21 ms), one frame each 16 ms, the clock on or not */
static void play(uint32_t ms, int playing, int clock) {
    for (uint32_t end = t + ms; t < end; t++) {
        if (clock && t % 21u == 0) lsdj_why_tick(&w, t);
        if (t % 16u == 0) lsdj_why_frame(&w, playing, t);
    }
}

int main(void) {
    lsdj_why_init(&w); t = 1000;
    assert(w.why == LSDJ_WHY_NONE);
    play(500, 0, 0);                          /* stopped, no clock: nothing */
    assert(w.why == LSDJ_WHY_NONE);

    /* a MIDI Stop: the clock steady to the end */
    play(2000, 1, 1);
    lsdj_why_cause(&w, LSDJ_WHY_MIDI_STOP, t);
    play(100, 0, 1);
    assert(w.why == LSDJ_WHY_MIDI_STOP && w.gap_at <= 21u + 16u && w.gap_max <= 22u);
    uint32_t at = w.at_ms; assert(at > t - 100u && at <= t);

    /* the clock went quiet 3 s, then the quiet stop */
    play(2000, 1, 1);
    play(3000, 1, 0);
    lsdj_why_cause(&w, LSDJ_WHY_QUIET, t);
    play(50, 0, 0);
    assert(w.why == LSDJ_WHY_QUIET && w.gap_at >= 3000u && w.gap_at < 3100u);

    /* a frozen page: a 1.2 s gap in the clock while it played, then LSDj stopped with nothing marked */
    play(1000, 1, 1);
    play(1200, 1, 0);
    play(500, 1, 1);
    play(100, 0, 1);
    assert(w.why == LSDJ_WHY_SELF && w.gap_max >= 1200u && w.gap_max < 1300u && w.gap_at < 40u);

    /* a gap before the play started is not counted; an old cause (2 s ago) explains nothing */
    play(2000, 0, 0);
    lsdj_why_cause(&w, LSDJ_WHY_BUTTON, t);
    play(10, 0, 1);
    play(2000, 1, 1);
    play(100, 0, 1);
    assert(w.why == LSDJ_WHY_SELF && w.gap_max <= 22u);

    /* a button on the FM-1, just before */
    play(1000, 1, 1);
    lsdj_why_cause(&w, LSDJ_WHY_BUTTON, t);
    play(100, 0, 1);
    assert(w.why == LSDJ_WHY_BUTTON);

    /* no clock ever (KEYBD / LSDJ sync): the gap at the stop unknown */
    lsdj_why_init(&w);
    play(1000, 1, 0); play(100, 0, 0);
    assert(w.why == LSDJ_WHY_SELF && w.gap_at == 0xFFFFFFFFu && lsdj_why_ms16(w.gap_at) == 65535u);
    puts("PASS lsdj_stopwhy: MIDI Stop, a quiet clock, LSDj by itself with the clock's longest gap, an old cause ignored, a button, no clock");
    return 0;
}
