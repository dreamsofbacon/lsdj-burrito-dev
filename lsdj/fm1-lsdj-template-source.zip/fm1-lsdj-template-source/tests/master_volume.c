/* SPDX-License-Identifier: GPL-3.0-only */
/* The MASTER curve and the web page's volume (VOLUME_SET: the DJ crossfader), as the audio interrupt applies them. */
#include <assert.h>
#include <stdio.h>
#include <stdlib.h>
#include "master_volume.h"
int main(void){
    assert(gb_master_gain(0)==0&&gb_master_gain(1023)==4088);
    /* USB AUDIO: FULL follows the page's volume alone: 127 leaves the sound untouched, 0 silences it, in between in step */
    assert(gb_page_gain(127)==4096&&gb_page_gain(255)==4096&&gb_page_gain(0)==0);
    for(unsigned k=1;k<128;k++)assert(gb_page_gain(k)>gb_page_gain(k-1));
    assert(gb_master_s16(32767,gb_page_gain(127))==32767&&gb_master_s16(-32768,gb_page_gain(127))==-32768);
    assert(gb_master_s16(20000,gb_page_gain(0))==0&&abs(gb_master_s16(20000,gb_page_gain(64))-10078)<=2);
    /* the ramp over a block (board.c gb_audio_irq): from full to 0 and back never overshoots */
    for(int from=0;from<=4096;from+=4096)for(int to=0;to<=4096;to+=4096)for(int i=0;i<256;i++){
        int g=from+(to-from)*(i+1)/256;assert(g>=0&&g<=4096);}
    puts("master_volume: PASS (MASTER curve, the page's volume on the USB sound: 127 full, 0 silent, ramped)");
    return 0;
}
